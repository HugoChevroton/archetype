--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.8
-- Dumped by pg_dump version 9.5.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE IF EXISTS ONLY public.reversion_revision DROP CONSTRAINT IF EXISTS user_id_refs_id_d4f35b51;
ALTER TABLE IF EXISTS ONLY public.generic_rating DROP CONSTRAINT IF EXISTS user_id_refs_id_9436ba96;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS user_id_refs_id_4dc23c39;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS user_id_refs_id_40c41112;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost DROP CONSTRAINT IF EXISTS user_id_refs_id_01a962b8;
ALTER TABLE IF EXISTS ONLY public.digipal_repository DROP CONSTRAINT IF EXISTS type_id_refs_id_ff4831cd;
ALTER TABLE IF EXISTS ONLY public.digipal_place DROP CONSTRAINT IF EXISTS type_id_refs_id_d2523b9f;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontent DROP CONSTRAINT IF EXISTS type_id_refs_id_a5bf2f2b;
ALTER TABLE IF EXISTS ONLY public.digipal_itempart DROP CONSTRAINT IF EXISTS type_id_refs_id_301eaa90;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost_related_posts DROP CONSTRAINT IF EXISTS to_blogpost_id_refs_id_6404941b;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontent_languages DROP CONSTRAINT IF EXISTS textcontent_id_1918d79e96327ff8_fk_digipal_text_textcontent_id;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontent DROP CONSTRAINT IF EXISTS text_id_refs_id_fbcfc7e4;
ALTER TABLE IF EXISTS ONLY public.digipal_cataloguenumber DROP CONSTRAINT IF EXISTS text_id_refs_id_c26c0737;
ALTER TABLE IF EXISTS ONLY public.digipal_description DROP CONSTRAINT IF EXISTS text_id_refs_id_1647dd70;
ALTER TABLE IF EXISTS ONLY public.digipal_textitempart DROP CONSTRAINT IF EXISTS text_id_refs_id_14d015c5;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxml DROP CONSTRAINT IF EXISTS text_content_id_refs_id_0a2712f3;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS stewart_record_id_refs_id_4645050e;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxml DROP CONSTRAINT IF EXISTS status_id_refs_id_bf6b5564;
ALTER TABLE IF EXISTS ONLY public.digipal_annotation DROP CONSTRAINT IF EXISTS status_id_refs_id_4ab46c62;
ALTER TABLE IF EXISTS ONLY public.digipal_cataloguenumber DROP CONSTRAINT IF EXISTS source_id_refs_id_a81c37fa;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxmlcopy DROP CONSTRAINT IF EXISTS source_id_refs_id_9b9df92b;
ALTER TABLE IF EXISTS ONLY public.digipal_description DROP CONSTRAINT IF EXISTS source_id_refs_id_5f9dc652;
ALTER TABLE IF EXISTS ONLY public.digipal_handdescription DROP CONSTRAINT IF EXISTS source_id_refs_id_055bdab2;
ALTER TABLE IF EXISTS ONLY public.digipal_itempartauthenticity DROP CONSTRAINT IF EXISTS source_id_refs_id_0116674a;
ALTER TABLE IF EXISTS ONLY public.core_sitepermission_sites DROP CONSTRAINT IF EXISTS sitepermission_id_refs_id_7dccdcbd;
ALTER TABLE IF EXISTS ONLY public.generic_keyword DROP CONSTRAINT IF EXISTS site_id_refs_id_f6393455;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost DROP CONSTRAINT IF EXISTS site_id_refs_id_ac21095f;
ALTER TABLE IF EXISTS ONLY public.blog_blogcategory DROP CONSTRAINT IF EXISTS site_id_refs_id_93afc60f;
ALTER TABLE IF EXISTS ONLY public.core_sitepermission_sites DROP CONSTRAINT IF EXISTS site_id_refs_id_91a6d9d4;
ALTER TABLE IF EXISTS ONLY public.pages_page DROP CONSTRAINT IF EXISTS site_id_refs_id_70c9ac77;
ALTER TABLE IF EXISTS ONLY public.django_redirect DROP CONSTRAINT IF EXISTS site_id_refs_id_390e2add;
ALTER TABLE IF EXISTS ONLY public.conf_setting DROP CONSTRAINT IF EXISTS site_id_refs_id_29e7e142;
ALTER TABLE IF EXISTS ONLY public.digipal_scribe DROP CONSTRAINT IF EXISTS scriptorium_id_refs_id_33a3d7e6;
ALTER TABLE IF EXISTS ONLY public.digipal_scriptcomponent_features DROP CONSTRAINT IF EXISTS scriptcomponent_id_refs_id_559cb110;
ALTER TABLE IF EXISTS ONLY public.digipal_scriptcomponent DROP CONSTRAINT IF EXISTS script_id_refs_id_c361aad4;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS script_id_refs_id_47908c8f;
ALTER TABLE IF EXISTS ONLY public.digipal_script_allographs DROP CONSTRAINT IF EXISTS script_id_refs_id_08f60255;
ALTER TABLE IF EXISTS ONLY public.digipal_idiograph DROP CONSTRAINT IF EXISTS scribe_id_refs_id_f6c56783;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS scribe_id_refs_id_79d30693;
ALTER TABLE IF EXISTS ONLY public.reversion_version DROP CONSTRAINT IF EXISTS revision_id_refs_id_a685e913;
ALTER TABLE IF EXISTS ONLY public.digipal_owner DROP CONSTRAINT IF EXISTS repository_id_refs_id_f008e82f;
ALTER TABLE IF EXISTS ONLY public.digipal_currentitem DROP CONSTRAINT IF EXISTS repository_id_refs_id_2413f631;
ALTER TABLE IF EXISTS ONLY public.generic_threadedcomment DROP CONSTRAINT IF EXISTS replied_to_id_refs_comment_ptr_id_83bd8e31;
ALTER TABLE IF EXISTS ONLY public.digipal_place DROP CONSTRAINT IF EXISTS region_id_refs_id_236ab299;
ALTER TABLE IF EXISTS ONLY public.digipal_institution DROP CONSTRAINT IF EXISTS reformer_id_refs_id_8c37de08;
ALTER TABLE IF EXISTS ONLY public.digipal_dateevidence DROP CONSTRAINT IF EXISTS reference_id_refs_id_92934927;
ALTER TABLE IF EXISTS ONLY public.digipal_placeevidence DROP CONSTRAINT IF EXISTS reference_id_refs_id_60bd43d2;
ALTER TABLE IF EXISTS ONLY public.twitter_tweet DROP CONSTRAINT IF EXISTS query_id_refs_id_b81595a6;
ALTER TABLE IF EXISTS ONLY public.digipal_repository DROP CONSTRAINT IF EXISTS place_id_refs_id_c93d046c;
ALTER TABLE IF EXISTS ONLY public.digipal_itemorigin DROP CONSTRAINT IF EXISTS place_id_refs_id_b2af8090;
ALTER TABLE IF EXISTS ONLY public.digipal_placeevidence DROP CONSTRAINT IF EXISTS place_id_refs_id_9fc785e4;
ALTER TABLE IF EXISTS ONLY public.digipal_institution DROP CONSTRAINT IF EXISTS place_id_refs_id_75faa36d;
ALTER TABLE IF EXISTS ONLY public.digipal_owner DROP CONSTRAINT IF EXISTS person_id_refs_id_6645bde2;
ALTER TABLE IF EXISTS ONLY public.digipal_institution DROP CONSTRAINT IF EXISTS patron_id_refs_id_8c37de08;
ALTER TABLE IF EXISTS ONLY public.digipal_repository DROP CONSTRAINT IF EXISTS part_of_id_refs_id_b3e8a0fd;
ALTER TABLE IF EXISTS ONLY public.pages_page DROP CONSTRAINT IF EXISTS parent_id_refs_id_68963b8e;
ALTER TABLE IF EXISTS ONLY public.forms_form DROP CONSTRAINT IF EXISTS page_ptr_id_refs_id_fe19b67b;
ALTER TABLE IF EXISTS ONLY public.galleries_gallery DROP CONSTRAINT IF EXISTS page_ptr_id_refs_id_75804475;
ALTER TABLE IF EXISTS ONLY public.pages_richtextpage DROP CONSTRAINT IF EXISTS page_ptr_id_refs_id_558d29bc;
ALTER TABLE IF EXISTS ONLY public.pages_link DROP CONSTRAINT IF EXISTS page_ptr_id_refs_id_2adddb0b;
ALTER TABLE IF EXISTS ONLY public.digipal_annotation DROP CONSTRAINT IF EXISTS page_id_refs_id_c3112308;
ALTER TABLE IF EXISTS ONLY public.digipal_ontograph DROP CONSTRAINT IF EXISTS ontograph_type_id_refs_id_f6076036;
ALTER TABLE IF EXISTS ONLY public.digipal_character DROP CONSTRAINT IF EXISTS ontograph_id_refs_id_9ff9b479;
ALTER TABLE IF EXISTS ONLY public.digipal_repository DROP CONSTRAINT IF EXISTS media_permission_id_refs_id_988b7016;
ALTER TABLE IF EXISTS ONLY public.digipal_image DROP CONSTRAINT IF EXISTS media_permission_id_refs_id_63c78590;
ALTER TABLE IF EXISTS ONLY public.digipal_proportion DROP CONSTRAINT IF EXISTS measurement_id_refs_id_0b86812d;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS latin_style_id_refs_id_dc87ffc0;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxml DROP CONSTRAINT IF EXISTS last_image_id_refs_id_b97ce151;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem DROP CONSTRAINT IF EXISTS language_id_refs_id_d9b95295;
ALTER TABLE IF EXISTS ONLY public.generic_assignedkeyword DROP CONSTRAINT IF EXISTS keyword_id_refs_id_aa70ce50;
ALTER TABLE IF EXISTS ONLY public.digipal_itempartitem DROP CONSTRAINT IF EXISTS item_part_id_refs_id_fc23f075;
ALTER TABLE IF EXISTS ONLY public.digipal_image DROP CONSTRAINT IF EXISTS item_part_id_refs_id_fbcb2f2a;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontent DROP CONSTRAINT IF EXISTS item_part_id_refs_id_f7500fa8;
ALTER TABLE IF EXISTS ONLY public.digipal_layout DROP CONSTRAINT IF EXISTS item_part_id_refs_id_df31da3a;
ALTER TABLE IF EXISTS ONLY public.digipal_itempartauthenticity DROP CONSTRAINT IF EXISTS item_part_id_refs_id_a78e0a58;
ALTER TABLE IF EXISTS ONLY public.digipal_textitempart DROP CONSTRAINT IF EXISTS item_part_id_refs_id_9a800fdb;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS item_part_id_refs_id_46f1b452;
ALTER TABLE IF EXISTS ONLY public.digipal_text_entryhand DROP CONSTRAINT IF EXISTS item_part_id_refs_id_069b1ab1;
ALTER TABLE IF EXISTS ONLY public.digipal_institution DROP CONSTRAINT IF EXISTS institution_type_id_refs_id_e427ce6d;
ALTER TABLE IF EXISTS ONLY public.digipal_owner DROP CONSTRAINT IF EXISTS institution_id_refs_id_aa4fbf78;
ALTER TABLE IF EXISTS ONLY public.digipal_itemorigin DROP CONSTRAINT IF EXISTS institution_id_refs_id_11d30948;
ALTER TABLE IF EXISTS ONLY public.digipal_idiographcomponent_features DROP CONSTRAINT IF EXISTS idiographcomponent_id_refs_id_80c117cd;
ALTER TABLE IF EXISTS ONLY public.digipal_idiographcomponent DROP CONSTRAINT IF EXISTS idiograph_id_refs_id_d6a7b061;
ALTER TABLE IF EXISTS ONLY public.digipal_graph DROP CONSTRAINT IF EXISTS idiograph_id_refs_id_63eed7df;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem_owners DROP CONSTRAINT IF EXISTS historicalitem_id_727ffcaab0ea8a5_fk_digipal_historicalitem_id;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem_categories DROP CONSTRAINT IF EXISTS historicalitem_id_2b89ff0d2714727_fk_digipal_historicalitem_id;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem DROP CONSTRAINT IF EXISTS historical_item_type_id_refs_id_c252ca51;
ALTER TABLE IF EXISTS ONLY public.digipal_archive DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_f9e6be89;
ALTER TABLE IF EXISTS ONLY public.digipal_dateevidence DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_ec058d19;
ALTER TABLE IF EXISTS ONLY public.digipal_itemorigin DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_ea707902;
ALTER TABLE IF EXISTS ONLY public.digipal_description DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_985172ba;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitemdate DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_853c259e;
ALTER TABLE IF EXISTS ONLY public.digipal_placeevidence DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_78501f52;
ALTER TABLE IF EXISTS ONLY public.digipal_collation DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_702ef28e;
ALTER TABLE IF EXISTS ONLY public.digipal_decoration DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_35828167;
ALTER TABLE IF EXISTS ONLY public.digipal_itempartitem DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_2caf0d88;
ALTER TABLE IF EXISTS ONLY public.digipal_layout DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_1fd35616;
ALTER TABLE IF EXISTS ONLY public.digipal_cataloguenumber DROP CONSTRAINT IF EXISTS historical_item_id_refs_id_09daf554;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem DROP CONSTRAINT IF EXISTS historical_item_format_id_refs_id_c59b43f2;
ALTER TABLE IF EXISTS ONLY public.digipal_place DROP CONSTRAINT IF EXISTS historical_county_id_refs_id_e974f51a;
ALTER TABLE IF EXISTS ONLY public.digipal_graph DROP CONSTRAINT IF EXISTS hand_id_refs_id_c5becd57;
ALTER TABLE IF EXISTS ONLY public.digipal_dateevidence DROP CONSTRAINT IF EXISTS hand_id_refs_id_74ab93ac;
ALTER TABLE IF EXISTS ONLY public.digipal_placeevidence DROP CONSTRAINT IF EXISTS hand_id_refs_id_2b787667;
ALTER TABLE IF EXISTS ONLY public.digipal_handdescription DROP CONSTRAINT IF EXISTS hand_id_refs_id_1ec58cd8;
ALTER TABLE IF EXISTS ONLY public.digipal_proportion DROP CONSTRAINT IF EXISTS hand_id_refs_id_0b1eb4ea;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem DROP CONSTRAINT IF EXISTS hair_id_refs_id_59f229d8;
ALTER TABLE IF EXISTS ONLY public.digipal_layout DROP CONSTRAINT IF EXISTS hair_arrangement_id_refs_id_3df6772a;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS group_id_refs_id_f4b32aac;
ALTER TABLE IF EXISTS ONLY public.digipal_graph DROP CONSTRAINT IF EXISTS group_id_refs_id_44358118;
ALTER TABLE IF EXISTS ONLY public.digipal_itempart DROP CONSTRAINT IF EXISTS group_id_refs_id_254c519a;
ALTER TABLE IF EXISTS ONLY public.digipal_graphcomponent_features DROP CONSTRAINT IF EXISTS graphcomponent_id_refs_id_515ec053;
ALTER TABLE IF EXISTS ONLY public.digipal_annotation DROP CONSTRAINT IF EXISTS graph_id_refs_id_97441f79;
ALTER TABLE IF EXISTS ONLY public.digipal_graphcomponent DROP CONSTRAINT IF EXISTS graph_id_refs_id_2580039d;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS glossed_text_id_refs_id_5154f4bc;
ALTER TABLE IF EXISTS ONLY public.galleries_galleryimage DROP CONSTRAINT IF EXISTS gallery_id_refs_page_ptr_id_d6457fc6;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost_related_posts DROP CONSTRAINT IF EXISTS from_blogpost_id_refs_id_6404941b;
ALTER TABLE IF EXISTS ONLY public.digipal_institution DROP CONSTRAINT IF EXISTS founder_id_refs_id_8c37de08;
ALTER TABLE IF EXISTS ONLY public.forms_field DROP CONSTRAINT IF EXISTS form_id_refs_page_ptr_id_5a752766;
ALTER TABLE IF EXISTS ONLY public.forms_formentry DROP CONSTRAINT IF EXISTS form_id_refs_page_ptr_id_4d605921;
ALTER TABLE IF EXISTS ONLY public.digipal_character DROP CONSTRAINT IF EXISTS form_id_refs_id_18bef2f6;
ALTER TABLE IF EXISTS ONLY public.digipal_idiographcomponent_features DROP CONSTRAINT IF EXISTS feature_id_refs_id_e6a54604;
ALTER TABLE IF EXISTS ONLY public.digipal_scriptcomponent_features DROP CONSTRAINT IF EXISTS feature_id_refs_id_87eb1d7a;
ALTER TABLE IF EXISTS ONLY public.digipal_aspect_features DROP CONSTRAINT IF EXISTS feature_id_refs_id_755946d3;
ALTER TABLE IF EXISTS ONLY public.digipal_graphcomponent_features DROP CONSTRAINT IF EXISTS feature_id_refs_id_7248d1b3;
ALTER TABLE IF EXISTS ONLY public.digipal_component_features DROP CONSTRAINT IF EXISTS feature_id_refs_id_3457eb6a;
ALTER TABLE IF EXISTS ONLY public.forms_fieldentry DROP CONSTRAINT IF EXISTS entry_id_refs_id_e329b086;
ALTER TABLE IF EXISTS ONLY public.django_comments DROP CONSTRAINT IF EXISTS django_comments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.django_comments DROP CONSTRAINT IF EXISTS django_comments_site_id_fkey;
ALTER TABLE IF EXISTS ONLY public.django_comments DROP CONSTRAINT IF EXISTS django_comments_content_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.django_comment_flags DROP CONSTRAINT IF EXISTS django_comment_flags_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.django_comment_flags DROP CONSTRAINT IF EXISTS django_comment_flags_comment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_content_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_languages DROP CONSTRAINT IF EXISTS digipal_text_langua_text_id_53f058584d7ac0ef_fk_digipal_text_id;
ALTER TABLE IF EXISTS ONLY public.digipal_text_categories DROP CONSTRAINT IF EXISTS digipal_text_catego_text_id_39cdb86ac033ae6d_fk_digipal_text_id;
ALTER TABLE IF EXISTS ONLY public.digipal_text_languages DROP CONSTRAINT IF EXISTS digipal_tex_language_id_73d4dcda2df2edc0_fk_digipal_language_id;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontent_languages DROP CONSTRAINT IF EXISTS digipal_tex_language_id_70323cef070fdcb3_fk_digipal_language_id;
ALTER TABLE IF EXISTS ONLY public.digipal_text_categories DROP CONSTRAINT IF EXISTS digipal_tex_category_id_52b32d954c6b0918_fk_digipal_category_id;
ALTER TABLE IF EXISTS ONLY public.digipal_scribe_reference DROP CONSTRAINT IF EXISTS digipal_scribe__scribe_id_57dd0c849aa6521f_fk_digipal_scribe_id;
ALTER TABLE IF EXISTS ONLY public.digipal_scribe_reference DROP CONSTRAINT IF EXISTS digipal_s_reference_id_514ba25d1687703d_fk_digipal_reference_id;
ALTER TABLE IF EXISTS ONLY public.digipal_itempart_owners DROP CONSTRAINT IF EXISTS digipal_itempart_ow_owner_id_74969a49036dab_fk_digipal_owner_id;
ALTER TABLE IF EXISTS ONLY public.digipal_itempart_owners DROP CONSTRAINT IF EXISTS digipal_ite_itempart_id_33e6e8354509f8dd_fk_digipal_itempart_id;
ALTER TABLE IF EXISTS ONLY public.digipal_idiograph_aspects DROP CONSTRAINT IF EXISTS digipal_idiogra_aspect_id_45390694190c31a7_fk_digipal_aspect_id;
ALTER TABLE IF EXISTS ONLY public.digipal_idiograph_aspects DROP CONSTRAINT IF EXISTS digipal_i_idiograph_id_2c3215c58c22fe03_fk_digipal_idiograph_id;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem_owners DROP CONSTRAINT IF EXISTS digipal_historica_owner_id_23ce7f02f1badad6_fk_digipal_owner_id;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem_categories DROP CONSTRAINT IF EXISTS digipal_hist_category_id_4194d8a4ba44eaa_fk_digipal_category_id;
ALTER TABLE IF EXISTS ONLY public.digipal_hand_images DROP CONSTRAINT IF EXISTS digipal_hand_images_hand_id_671b7cfd266947f5_fk_digipal_hand_id;
ALTER TABLE IF EXISTS ONLY public.digipal_hand_images DROP CONSTRAINT IF EXISTS digipal_hand_imag_image_id_6c1445fe889c9bf6_fk_digipal_image_id;
ALTER TABLE IF EXISTS ONLY public.digipal_graph_aspects DROP CONSTRAINT IF EXISTS digipal_graph_asp_graph_id_3cd5a48f03f7908b_fk_digipal_graph_id;
ALTER TABLE IF EXISTS ONLY public.digipal_graph_aspects DROP CONSTRAINT IF EXISTS digipal_graph_as_aspect_id_d565c199db5dbfa_fk_digipal_aspect_id;
ALTER TABLE IF EXISTS ONLY public.digipal_currentitem_owners DROP CONSTRAINT IF EXISTS digipal_currentit_owner_id_18d9e4f9dfde684e_fk_digipal_owner_id;
ALTER TABLE IF EXISTS ONLY public.digipal_character_components DROP CONSTRAINT IF EXISTS digipal_c_component_id_5c2b93e63528063d_fk_digipal_component_id;
ALTER TABLE IF EXISTS ONLY public.digipal_character_components DROP CONSTRAINT IF EXISTS digipal_c_character_id_421a3a206316eea3_fk_digipal_character_id;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet_hands DROP CONSTRAINT IF EXISTS digipal_alphabet_ha_hand_id_3f5df15f509bddda_fk_digipal_hand_id;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet_hands DROP CONSTRAINT IF EXISTS digipal_alp_alphabet_id_588d04dc3a11a174_fk_digipal_alphabet_id;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet_ontographs DROP CONSTRAINT IF EXISTS digipal_alp_alphabet_id_5556a119f9c15c6e_fk_digipal_alphabet_id;
ALTER TABLE IF EXISTS ONLY public.digipal_allograph_aspects DROP CONSTRAINT IF EXISTS digipal_allogra_aspect_id_5f1bd1c41c2c6dca_fk_digipal_aspect_id;
ALTER TABLE IF EXISTS ONLY public.digipal_allographcomponent_features DROP CONSTRAINT IF EXISTS digipal_allog_feature_id_230c2364d0c73288_fk_digipal_feature_id;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet_ontographs DROP CONSTRAINT IF EXISTS digipal_a_ontograph_id_1d0cd4ace8644f2e_fk_digipal_ontograph_id;
ALTER TABLE IF EXISTS ONLY public.digipal_allograph_aspects DROP CONSTRAINT IF EXISTS digipal_a_allograph_id_542fa868475bf703_fk_digipal_allograph_id;
ALTER TABLE IF EXISTS ONLY public.digipal_currentitem_owners DROP CONSTRAINT IF EXISTS digip_currentitem_id_3666c8ecafb6bb97_fk_digipal_currentitem_id;
ALTER TABLE IF EXISTS ONLY public.digipal_dateevidence DROP CONSTRAINT IF EXISTS date_id_refs_id_6278e8c5;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitemdate DROP CONSTRAINT IF EXISTS date_id_refs_id_2452bccb;
ALTER TABLE IF EXISTS ONLY public.digipal_itempart DROP CONSTRAINT IF EXISTS current_item_id_refs_id_0c135812;
ALTER TABLE IF EXISTS ONLY public.digipal_place DROP CONSTRAINT IF EXISTS current_county_id_refs_id_e974f51a;
ALTER TABLE IF EXISTS ONLY public.core_sitepermission DROP CONSTRAINT IF EXISTS core_sitepermission_user_id_d964e296aed9970_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.reversion_version DROP CONSTRAINT IF EXISTS content_type_id_refs_id_f5dce86c;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS content_type_id_refs_id_d043b34a;
ALTER TABLE IF EXISTS ONLY public.generic_assignedkeyword DROP CONSTRAINT IF EXISTS content_type_id_refs_id_c36d959c;
ALTER TABLE IF EXISTS ONLY public.generic_rating DROP CONSTRAINT IF EXISTS content_type_id_refs_id_1c638e93;
ALTER TABLE IF EXISTS ONLY public.digipal_archive DROP CONSTRAINT IF EXISTS content_type_id_refs_id_0a48a334;
ALTER TABLE IF EXISTS ONLY public.digipal_scriptcomponent DROP CONSTRAINT IF EXISTS component_id_refs_id_bf195524;
ALTER TABLE IF EXISTS ONLY public.digipal_graphcomponent DROP CONSTRAINT IF EXISTS component_id_refs_id_76111977;
ALTER TABLE IF EXISTS ONLY public.digipal_idiographcomponent DROP CONSTRAINT IF EXISTS component_id_refs_id_15daa9d1;
ALTER TABLE IF EXISTS ONLY public.digipal_component_features DROP CONSTRAINT IF EXISTS component_id_refs_id_14a98178;
ALTER TABLE IF EXISTS ONLY public.digipal_allographcomponent DROP CONSTRAINT IF EXISTS component_id_refs_id_10d1fa92;
ALTER TABLE IF EXISTS ONLY public.generic_threadedcomment DROP CONSTRAINT IF EXISTS comment_ptr_id_refs_id_d4c241e5;
ALTER TABLE IF EXISTS ONLY public.digipal_allograph DROP CONSTRAINT IF EXISTS character_id_refs_id_d12e219a;
ALTER TABLE IF EXISTS ONLY public.digipal_itempartauthenticity DROP CONSTRAINT IF EXISTS category_id_refs_id_47dac8d7;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost_categories DROP CONSTRAINT IF EXISTS blogpost_id_refs_id_6a2ad936;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost_categories DROP CONSTRAINT IF EXISTS blogcategory_id_refs_id_91693b1c;
ALTER TABLE IF EXISTS ONLY public.digipal_annotation DROP CONSTRAINT IF EXISTS before_id_refs_id_a195d453;
ALTER TABLE IF EXISTS ONLY public.digipal_annotation DROP CONSTRAINT IF EXISTS author_id_refs_id_91c5a886;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS assigned_place_id_refs_id_5d22b62d;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS assigned_date_id_refs_id_12312e8f;
ALTER TABLE IF EXISTS ONLY public.digipal_aspect_features DROP CONSTRAINT IF EXISTS aspect_id_refs_id_418bf40d;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS appearance_id_refs_id_d4a1da4e;
ALTER TABLE IF EXISTS ONLY public.digipal_image DROP CONSTRAINT IF EXISTS annotation_status_id_refs_id_4aa83520;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textannotation DROP CONSTRAINT IF EXISTS annotation_id_refs_id_3e2f18b6;
ALTER TABLE IF EXISTS ONLY public.digipal_idiograph DROP CONSTRAINT IF EXISTS allograph_id_refs_id_f02d3abf;
ALTER TABLE IF EXISTS ONLY public.digipal_script_allographs DROP CONSTRAINT IF EXISTS allograph_id_refs_id_e85ec36c;
ALTER TABLE IF EXISTS ONLY public.digipal_allographcomponent DROP CONSTRAINT IF EXISTS allograph_id_refs_id_e75127c7;
ALTER TABLE IF EXISTS ONLY public.digipal_annotation DROP CONSTRAINT IF EXISTS after_id_refs_id_a195d453;
ALTER TABLE IF EXISTS ONLY public.digipal_allographcomponent_features DROP CONSTRAINT IF EXISTS "D8272c0c845536cc87a3d483d63b21f6";
DROP INDEX IF EXISTS public.twitter_tweet_query_id;
DROP INDEX IF EXISTS public.reversion_version_revision_id;
DROP INDEX IF EXISTS public.reversion_version_object_id_int;
DROP INDEX IF EXISTS public.reversion_version_content_type_id;
DROP INDEX IF EXISTS public.reversion_revision_user_id;
DROP INDEX IF EXISTS public.reversion_revision_manager_slug_like;
DROP INDEX IF EXISTS public.reversion_revision_manager_slug;
DROP INDEX IF EXISTS public.reversion_revision_date_created;
DROP INDEX IF EXISTS public.pages_page_site_id;
DROP INDEX IF EXISTS public.pages_page_publish_date_4b581dded15f4cdf_uniq;
DROP INDEX IF EXISTS public.pages_page_parent_id;
DROP INDEX IF EXISTS public.generic_threadedcomment_replied_to_id;
DROP INDEX IF EXISTS public.generic_rating_user_id;
DROP INDEX IF EXISTS public.generic_rating_content_type_id;
DROP INDEX IF EXISTS public.generic_keyword_site_id;
DROP INDEX IF EXISTS public.generic_assignedkeyword_keyword_id;
DROP INDEX IF EXISTS public.generic_assignedkeyword_content_type_id;
DROP INDEX IF EXISTS public.galleries_galleryimage_gallery_id;
DROP INDEX IF EXISTS public.forms_formentry_form_id;
DROP INDEX IF EXISTS public.forms_fieldentry_entry_id;
DROP INDEX IF EXISTS public.forms_field_form_id;
DROP INDEX IF EXISTS public.django_session_session_key_like;
DROP INDEX IF EXISTS public.django_session_expire_date;
DROP INDEX IF EXISTS public.django_redirect_site_id;
DROP INDEX IF EXISTS public.django_redirect_old_path_like;
DROP INDEX IF EXISTS public.django_redirect_old_path;
DROP INDEX IF EXISTS public.django_comments_user_id;
DROP INDEX IF EXISTS public.django_comments_submit_date_12b4e916a37b5c82_uniq;
DROP INDEX IF EXISTS public.django_comments_site_id;
DROP INDEX IF EXISTS public.django_comments_content_type_id;
DROP INDEX IF EXISTS public.django_comment_flags_user_id;
DROP INDEX IF EXISTS public.django_comment_flags_flag_like;
DROP INDEX IF EXISTS public.django_comment_flags_flag;
DROP INDEX IF EXISTS public.django_comment_flags_comment_id;
DROP INDEX IF EXISTS public.django_admin_log_user_id;
DROP INDEX IF EXISTS public.django_admin_log_content_type_id;
DROP INDEX IF EXISTS public.digipal_textitempart_text_id;
DROP INDEX IF EXISTS public.digipal_textitempart_item_part_id;
DROP INDEX IF EXISTS public.digipal_text_textcontentxmlstatus_slug_like;
DROP INDEX IF EXISTS public.digipal_text_textcontentxmlstatus_slug;
DROP INDEX IF EXISTS public.digipal_text_textcontentxmlstatus_name_like;
DROP INDEX IF EXISTS public.digipal_text_textcontentxmlcopy_source_id;
DROP INDEX IF EXISTS public.digipal_text_textcontentxml_text_content_id;
DROP INDEX IF EXISTS public.digipal_text_textcontentxml_status_id;
DROP INDEX IF EXISTS public.digipal_text_textcontentxml_last_image_id;
DROP INDEX IF EXISTS public.digipal_text_textcontenttype_slug_like;
DROP INDEX IF EXISTS public.digipal_text_textcontenttype_slug;
DROP INDEX IF EXISTS public.digipal_text_textcontenttype_name_like;
DROP INDEX IF EXISTS public.digipal_text_textcontent_type_id;
DROP INDEX IF EXISTS public.digipal_text_textcontent_text_id;
DROP INDEX IF EXISTS public.digipal_text_textcontent_languages_textcontent_id;
DROP INDEX IF EXISTS public.digipal_text_textcontent_languages_language_id;
DROP INDEX IF EXISTS public.digipal_text_textcontent_item_part_id;
DROP INDEX IF EXISTS public.digipal_text_textannotation_annotation_id;
DROP INDEX IF EXISTS public.digipal_text_languages_text_id;
DROP INDEX IF EXISTS public.digipal_text_languages_language_id;
DROP INDEX IF EXISTS public.digipal_text_entryhand_order;
DROP INDEX IF EXISTS public.digipal_text_entryhand_item_part_id;
DROP INDEX IF EXISTS public.digipal_text_entryhand_hand_label_like;
DROP INDEX IF EXISTS public.digipal_text_entryhand_hand_label;
DROP INDEX IF EXISTS public.digipal_text_entryhand_entry_number_like;
DROP INDEX IF EXISTS public.digipal_text_entryhand_entry_number;
DROP INDEX IF EXISTS public.digipal_text_entryhand_correction;
DROP INDEX IF EXISTS public.digipal_text_categories_text_id;
DROP INDEX IF EXISTS public.digipal_text_categories_category_id;
DROP INDEX IF EXISTS public.digipal_status_name_like;
DROP INDEX IF EXISTS public.digipal_source_name_like;
DROP INDEX IF EXISTS public.digipal_source_label_slug_like;
DROP INDEX IF EXISTS public.digipal_source_label_slug;
DROP INDEX IF EXISTS public.digipal_source_label_like;
DROP INDEX IF EXISTS public.digipal_scriptcomponent_script_id;
DROP INDEX IF EXISTS public.digipal_scriptcomponent_features_scriptcomponent_id;
DROP INDEX IF EXISTS public.digipal_scriptcomponent_features_feature_id;
DROP INDEX IF EXISTS public.digipal_scriptcomponent_component_id;
DROP INDEX IF EXISTS public.digipal_script_allographs_script_id;
DROP INDEX IF EXISTS public.digipal_script_allographs_allograph_id;
DROP INDEX IF EXISTS public.digipal_scribe_scriptorium_id;
DROP INDEX IF EXISTS public.digipal_scribe_reference_scribe_id;
DROP INDEX IF EXISTS public.digipal_scribe_reference_reference_id;
DROP INDEX IF EXISTS public.digipal_scribe_name_like;
DROP INDEX IF EXISTS public.digipal_repository_type_id;
DROP INDEX IF EXISTS public.digipal_repository_place_id;
DROP INDEX IF EXISTS public.digipal_repository_part_of_id;
DROP INDEX IF EXISTS public.digipal_repository_media_permission_id;
DROP INDEX IF EXISTS public.digipal_region_name_like;
DROP INDEX IF EXISTS public.digipal_proportion_measurement_id;
DROP INDEX IF EXISTS public.digipal_proportion_hand_id;
DROP INDEX IF EXISTS public.digipal_placeevidence_reference_id;
DROP INDEX IF EXISTS public.digipal_placeevidence_place_id;
DROP INDEX IF EXISTS public.digipal_placeevidence_historical_item_id;
DROP INDEX IF EXISTS public.digipal_placeevidence_hand_id;
DROP INDEX IF EXISTS public.digipal_place_type_id;
DROP INDEX IF EXISTS public.digipal_place_region_id;
DROP INDEX IF EXISTS public.digipal_place_historical_county_id;
DROP INDEX IF EXISTS public.digipal_place_current_county_id;
DROP INDEX IF EXISTS public.digipal_person_name_like;
DROP INDEX IF EXISTS public.digipal_page_media_permission_id;
DROP INDEX IF EXISTS public.digipal_page_item_part_id;
DROP INDEX IF EXISTS public.digipal_owner_repository_id;
DROP INDEX IF EXISTS public.digipal_owner_person_id;
DROP INDEX IF EXISTS public.digipal_owner_institution_id;
DROP INDEX IF EXISTS public.digipal_ontographtype_name_like;
DROP INDEX IF EXISTS public.digipal_ontograph_ontograph_type_id;
DROP INDEX IF EXISTS public.digipal_layout_item_part_id;
DROP INDEX IF EXISTS public.digipal_layout_historical_item_id;
DROP INDEX IF EXISTS public.digipal_layout_hair_arrangement_id;
DROP INDEX IF EXISTS public.digipal_language_name_like;
DROP INDEX IF EXISTS public.digipal_itemparttype_name_like;
DROP INDEX IF EXISTS public.digipal_itempartitem_item_part_id;
DROP INDEX IF EXISTS public.digipal_itempartitem_historical_item_id;
DROP INDEX IF EXISTS public.digipal_itempartauthenticity_source_id;
DROP INDEX IF EXISTS public.digipal_itempartauthenticity_item_part_id;
DROP INDEX IF EXISTS public.digipal_itempartauthenticity_category_id;
DROP INDEX IF EXISTS public.digipal_itempart_type_id;
DROP INDEX IF EXISTS public.digipal_itempart_owners_owner_id;
DROP INDEX IF EXISTS public.digipal_itempart_owners_itempart_id;
DROP INDEX IF EXISTS public.digipal_itempart_group_id;
DROP INDEX IF EXISTS public.digipal_itempart_current_item_id;
DROP INDEX IF EXISTS public.digipal_itemorigin_place_id;
DROP INDEX IF EXISTS public.digipal_itemorigin_institution_id;
DROP INDEX IF EXISTS public.digipal_itemorigin_historical_item_id;
DROP INDEX IF EXISTS public.digipal_institution_reformer_id;
DROP INDEX IF EXISTS public.digipal_institution_place_id;
DROP INDEX IF EXISTS public.digipal_institution_patron_id;
DROP INDEX IF EXISTS public.digipal_institution_institution_type_id;
DROP INDEX IF EXISTS public.digipal_institution_founder_id;
DROP INDEX IF EXISTS public.digipal_imageannotationstatus_name_like;
DROP INDEX IF EXISTS public.digipal_image_annotation_status_id;
DROP INDEX IF EXISTS public.digipal_idiographcomponent_idiograph_id;
DROP INDEX IF EXISTS public.digipal_idiographcomponent_features_idiographcomponent_id;
DROP INDEX IF EXISTS public.digipal_idiographcomponent_features_feature_id;
DROP INDEX IF EXISTS public.digipal_idiographcomponent_component_id;
DROP INDEX IF EXISTS public.digipal_idiograph_scribe_id;
DROP INDEX IF EXISTS public.digipal_idiograph_aspects_idiograph_id;
DROP INDEX IF EXISTS public.digipal_idiograph_aspects_aspect_id;
DROP INDEX IF EXISTS public.digipal_idiograph_allograph_id;
DROP INDEX IF EXISTS public.digipal_historicalitemdate_historical_item_id;
DROP INDEX IF EXISTS public.digipal_historicalitemdate_date_id;
DROP INDEX IF EXISTS public.digipal_historicalitem_owners_owner_id;
DROP INDEX IF EXISTS public.digipal_historicalitem_owners_historicalitem_id;
DROP INDEX IF EXISTS public.digipal_historicalitem_language_id;
DROP INDEX IF EXISTS public.digipal_historicalitem_historical_item_type_id;
DROP INDEX IF EXISTS public.digipal_historicalitem_historical_item_format_id;
DROP INDEX IF EXISTS public.digipal_historicalitem_hair_id;
DROP INDEX IF EXISTS public.digipal_historicalitem_categories_historicalitem_id;
DROP INDEX IF EXISTS public.digipal_historicalitem_categories_category_id;
DROP INDEX IF EXISTS public.digipal_handdescription_source_id;
DROP INDEX IF EXISTS public.digipal_handdescription_hand_id;
DROP INDEX IF EXISTS public.digipal_hand_stewart_record_id;
DROP INDEX IF EXISTS public.digipal_hand_script_id;
DROP INDEX IF EXISTS public.digipal_hand_scribe_id;
DROP INDEX IF EXISTS public.digipal_hand_pages_page_id;
DROP INDEX IF EXISTS public.digipal_hand_pages_hand_id;
DROP INDEX IF EXISTS public.digipal_hand_latin_style_id;
DROP INDEX IF EXISTS public.digipal_hand_item_part_id;
DROP INDEX IF EXISTS public.digipal_hand_glossed_text_id;
DROP INDEX IF EXISTS public.digipal_hand_assigned_place_id;
DROP INDEX IF EXISTS public.digipal_hand_assigned_date_id;
DROP INDEX IF EXISTS public.digipal_hand_appearance_id;
DROP INDEX IF EXISTS public.digipal_hair_label_like;
DROP INDEX IF EXISTS public.digipal_graphcomponent_graph_id;
DROP INDEX IF EXISTS public.digipal_graphcomponent_features_graphcomponent_id;
DROP INDEX IF EXISTS public.digipal_graphcomponent_features_feature_id;
DROP INDEX IF EXISTS public.digipal_graphcomponent_component_id;
DROP INDEX IF EXISTS public.digipal_graph_idiograph_id;
DROP INDEX IF EXISTS public.digipal_graph_hand_id;
DROP INDEX IF EXISTS public.digipal_graph_group_id;
DROP INDEX IF EXISTS public.digipal_graph_aspects_graph_id;
DROP INDEX IF EXISTS public.digipal_graph_aspects_aspect_id;
DROP INDEX IF EXISTS public.digipal_format_name_like;
DROP INDEX IF EXISTS public.digipal_feature_name_like;
DROP INDEX IF EXISTS public.digipal_description_text_id;
DROP INDEX IF EXISTS public.digipal_description_source_id;
DROP INDEX IF EXISTS public.digipal_description_historical_item_id;
DROP INDEX IF EXISTS public.digipal_decoration_historical_item_id;
DROP INDEX IF EXISTS public.digipal_dateevidence_reference_id;
DROP INDEX IF EXISTS public.digipal_dateevidence_historical_item_id;
DROP INDEX IF EXISTS public.digipal_dateevidence_hand_id;
DROP INDEX IF EXISTS public.digipal_dateevidence_date_id;
DROP INDEX IF EXISTS public.digipal_currentitem_repository_id;
DROP INDEX IF EXISTS public.digipal_currentitem_owners_owner_id;
DROP INDEX IF EXISTS public.digipal_currentitem_owners_currentitem_id;
DROP INDEX IF EXISTS public.digipal_county_name_like;
DROP INDEX IF EXISTS public.digipal_component_name_like;
DROP INDEX IF EXISTS public.digipal_component_features_feature_id;
DROP INDEX IF EXISTS public.digipal_component_features_component_id;
DROP INDEX IF EXISTS public.digipal_collation_historical_item_id;
DROP INDEX IF EXISTS public.digipal_characterform_name_like;
DROP INDEX IF EXISTS public.digipal_character_unicode_point_like;
DROP INDEX IF EXISTS public.digipal_character_ontograph_id;
DROP INDEX IF EXISTS public.digipal_character_name_like;
DROP INDEX IF EXISTS public.digipal_character_form_id;
DROP INDEX IF EXISTS public.digipal_character_components_component_id;
DROP INDEX IF EXISTS public.digipal_character_components_character_id;
DROP INDEX IF EXISTS public.digipal_category_name_like;
DROP INDEX IF EXISTS public.digipal_cataloguenumber_text_id;
DROP INDEX IF EXISTS public.digipal_cataloguenumber_source_id;
DROP INDEX IF EXISTS public.digipal_cataloguenumber_number_slug_like;
DROP INDEX IF EXISTS public.digipal_cataloguenumber_number_slug;
DROP INDEX IF EXISTS public.digipal_cataloguenumber_historical_item_id;
DROP INDEX IF EXISTS public.digipal_authenticitycategory_slug_like;
DROP INDEX IF EXISTS public.digipal_authenticitycategory_slug;
DROP INDEX IF EXISTS public.digipal_authenticitycategory_name_like;
DROP INDEX IF EXISTS public.digipal_aspect_name_like;
DROP INDEX IF EXISTS public.digipal_aspect_features_feature_id;
DROP INDEX IF EXISTS public.digipal_aspect_features_aspect_id;
DROP INDEX IF EXISTS public.digipal_archive_historical_item_id;
DROP INDEX IF EXISTS public.digipal_archive_content_type_id;
DROP INDEX IF EXISTS public.digipal_apitransform_title_like;
DROP INDEX IF EXISTS public.digipal_apitransform_slug_like;
DROP INDEX IF EXISTS public.digipal_annotation_type_like;
DROP INDEX IF EXISTS public.digipal_annotation_type;
DROP INDEX IF EXISTS public.digipal_annotation_status_id;
DROP INDEX IF EXISTS public.digipal_annotation_page_id;
DROP INDEX IF EXISTS public.digipal_annotation_clientid_like;
DROP INDEX IF EXISTS public.digipal_annotation_clientid;
DROP INDEX IF EXISTS public.digipal_annotation_before_id;
DROP INDEX IF EXISTS public.digipal_annotation_author_id;
DROP INDEX IF EXISTS public.digipal_annotation_after_id;
DROP INDEX IF EXISTS public.digipal_alphabet_ontographs_ontograph_id;
DROP INDEX IF EXISTS public.digipal_alphabet_ontographs_alphabet_id;
DROP INDEX IF EXISTS public.digipal_alphabet_name_like;
DROP INDEX IF EXISTS public.digipal_alphabet_hands_hand_id;
DROP INDEX IF EXISTS public.digipal_alphabet_hands_alphabet_id;
DROP INDEX IF EXISTS public.digipal_allographcomponent_features_feature_id;
DROP INDEX IF EXISTS public.digipal_allographcomponent_features_allographcomponent_id;
DROP INDEX IF EXISTS public.digipal_allographcomponent_component_id;
DROP INDEX IF EXISTS public.digipal_allographcomponent_allograph_id;
DROP INDEX IF EXISTS public.digipal_allograph_character_id;
DROP INDEX IF EXISTS public.digipal_allograph_aspects_aspect_id;
DROP INDEX IF EXISTS public.digipal_allograph_aspects_allograph_id;
DROP INDEX IF EXISTS public.core_sitepermission_sites_sitepermission_id;
DROP INDEX IF EXISTS public.core_sitepermission_sites_site_id;
DROP INDEX IF EXISTS public.conf_setting_site_id;
DROP INDEX IF EXISTS public.blog_blogpost_user_id;
DROP INDEX IF EXISTS public.blog_blogpost_site_id;
DROP INDEX IF EXISTS public.blog_blogpost_related_posts_to_blogpost_id;
DROP INDEX IF EXISTS public.blog_blogpost_related_posts_from_blogpost_id;
DROP INDEX IF EXISTS public.blog_blogpost_publish_date_1015da2554a8e97f_uniq;
DROP INDEX IF EXISTS public.blog_blogpost_categories_blogpost_id;
DROP INDEX IF EXISTS public.blog_blogpost_categories_blogcategory_id;
DROP INDEX IF EXISTS public.blog_blogcategory_site_id;
DROP INDEX IF EXISTS public.auth_user_username_like;
DROP INDEX IF EXISTS public.auth_user_user_permissions_user_id;
DROP INDEX IF EXISTS public.auth_user_user_permissions_permission_id;
DROP INDEX IF EXISTS public.auth_user_groups_user_id;
DROP INDEX IF EXISTS public.auth_user_groups_group_id;
DROP INDEX IF EXISTS public.auth_permission_content_type_id;
DROP INDEX IF EXISTS public.auth_group_permissions_permission_id;
DROP INDEX IF EXISTS public.auth_group_permissions_group_id;
DROP INDEX IF EXISTS public.auth_group_name_like;
ALTER TABLE IF EXISTS ONLY public.twitter_tweet DROP CONSTRAINT IF EXISTS twitter_tweet_pkey;
ALTER TABLE IF EXISTS ONLY public.twitter_query DROP CONSTRAINT IF EXISTS twitter_query_pkey;
ALTER TABLE IF EXISTS ONLY public.south_migrationhistory DROP CONSTRAINT IF EXISTS south_migrationhistory_pkey;
ALTER TABLE IF EXISTS ONLY public.reversion_version DROP CONSTRAINT IF EXISTS reversion_version_pkey;
ALTER TABLE IF EXISTS ONLY public.reversion_revision DROP CONSTRAINT IF EXISTS reversion_revision_pkey;
ALTER TABLE IF EXISTS ONLY public.pages_page DROP CONSTRAINT IF EXISTS pages_page_pkey;
ALTER TABLE IF EXISTS ONLY public.pages_link DROP CONSTRAINT IF EXISTS pages_link_pkey;
ALTER TABLE IF EXISTS ONLY public.pages_richtextpage DROP CONSTRAINT IF EXISTS pages_contentpage_pkey;
ALTER TABLE IF EXISTS ONLY public.generic_threadedcomment DROP CONSTRAINT IF EXISTS generic_threadedcomment_pkey;
ALTER TABLE IF EXISTS ONLY public.generic_rating DROP CONSTRAINT IF EXISTS generic_rating_pkey;
ALTER TABLE IF EXISTS ONLY public.generic_keyword DROP CONSTRAINT IF EXISTS generic_keyword_pkey;
ALTER TABLE IF EXISTS ONLY public.generic_assignedkeyword DROP CONSTRAINT IF EXISTS generic_assignedkeyword_pkey;
ALTER TABLE IF EXISTS ONLY public.galleries_galleryimage DROP CONSTRAINT IF EXISTS galleries_galleryimage_pkey;
ALTER TABLE IF EXISTS ONLY public.galleries_gallery DROP CONSTRAINT IF EXISTS galleries_gallery_pkey;
ALTER TABLE IF EXISTS ONLY public.forms_formentry DROP CONSTRAINT IF EXISTS forms_formentry_pkey;
ALTER TABLE IF EXISTS ONLY public.forms_form DROP CONSTRAINT IF EXISTS forms_form_pkey;
ALTER TABLE IF EXISTS ONLY public.forms_fieldentry DROP CONSTRAINT IF EXISTS forms_fieldentry_pkey;
ALTER TABLE IF EXISTS ONLY public.forms_field DROP CONSTRAINT IF EXISTS forms_field_pkey;
ALTER TABLE IF EXISTS ONLY public.django_site DROP CONSTRAINT IF EXISTS django_site_pkey;
ALTER TABLE IF EXISTS ONLY public.django_session DROP CONSTRAINT IF EXISTS django_session_pkey;
ALTER TABLE IF EXISTS ONLY public.django_redirect DROP CONSTRAINT IF EXISTS django_redirect_site_id_old_path_key;
ALTER TABLE IF EXISTS ONLY public.django_redirect DROP CONSTRAINT IF EXISTS django_redirect_pkey;
ALTER TABLE IF EXISTS ONLY public.django_migrations DROP CONSTRAINT IF EXISTS django_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_app_label_model_key;
ALTER TABLE IF EXISTS ONLY public.django_comments DROP CONSTRAINT IF EXISTS django_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.django_comment_flags DROP CONSTRAINT IF EXISTS django_comment_flags_user_id_comment_id_flag_key;
ALTER TABLE IF EXISTS ONLY public.django_comment_flags DROP CONSTRAINT IF EXISTS django_comment_flags_pkey;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_textitempart DROP CONSTRAINT IF EXISTS digipal_textitempart_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_textitempart DROP CONSTRAINT IF EXISTS digipal_textitempart_item_part_id_54a67d5d6a0c9393_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textpattern DROP CONSTRAINT IF EXISTS digipal_text_textpattern_title_key;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textpattern DROP CONSTRAINT IF EXISTS digipal_text_textpattern_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textpattern DROP CONSTRAINT IF EXISTS digipal_text_textpattern_key_key;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxmlstatus DROP CONSTRAINT IF EXISTS digipal_text_textcontentxmlstatus_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxmlstatus DROP CONSTRAINT IF EXISTS digipal_text_textcontentxmlstatus_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxmlcopy DROP CONSTRAINT IF EXISTS digipal_text_textcontentxmlcopy_source_id_112d7bdb8b83fa28_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxmlcopy DROP CONSTRAINT IF EXISTS digipal_text_textcontentxmlcopy_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxml DROP CONSTRAINT IF EXISTS digipal_text_textcontentxml_text_content_id_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontentxml DROP CONSTRAINT IF EXISTS digipal_text_textcontentxml_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontenttype DROP CONSTRAINT IF EXISTS digipal_text_textcontenttype_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontenttype DROP CONSTRAINT IF EXISTS digipal_text_textcontenttype_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontent DROP CONSTRAINT IF EXISTS digipal_text_textcontent_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontent_languages DROP CONSTRAINT IF EXISTS digipal_text_textcontent_languages_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontent_languages DROP CONSTRAINT IF EXISTS digipal_text_textcontent_l_textcontent_id_7f15c6885917f53e_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textcontent DROP CONSTRAINT IF EXISTS digipal_text_textcontent_item_part_id_13494d9cc4c7cecd_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textannotation DROP CONSTRAINT IF EXISTS digipal_text_textannotation_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_textannotation DROP CONSTRAINT IF EXISTS digipal_text_textannotation_annotation_id_ace38c747c2b414_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text DROP CONSTRAINT IF EXISTS digipal_text_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text DROP CONSTRAINT IF EXISTS digipal_text_name_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text_languages DROP CONSTRAINT IF EXISTS digipal_text_languages_text_id_226c2b5c0566249f_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text_languages DROP CONSTRAINT IF EXISTS digipal_text_languages_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_entryhand DROP CONSTRAINT IF EXISTS digipal_text_entryhand_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_text_entryhand DROP CONSTRAINT IF EXISTS digipal_text_entryhand_item_part_id_7315d68a2369bb35_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text_categories DROP CONSTRAINT IF EXISTS digipal_text_categories_text_id_2f28f4b1877a5d69_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_text_categories DROP CONSTRAINT IF EXISTS digipal_text_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_stewartrecord DROP CONSTRAINT IF EXISTS digipal_stewartrecord_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_status DROP CONSTRAINT IF EXISTS digipal_status_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_status DROP CONSTRAINT IF EXISTS digipal_status_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_source DROP CONSTRAINT IF EXISTS digipal_source_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_source DROP CONSTRAINT IF EXISTS digipal_source_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_source DROP CONSTRAINT IF EXISTS digipal_source_label_key;
ALTER TABLE IF EXISTS ONLY public.digipal_scriptcomponent_features DROP CONSTRAINT IF EXISTS digipal_scriptcomponent_scriptcomponent_id_7a1a2f2734cd999_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_scriptcomponent DROP CONSTRAINT IF EXISTS digipal_scriptcomponent_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_scriptcomponent_features DROP CONSTRAINT IF EXISTS digipal_scriptcomponent_features_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_script DROP CONSTRAINT IF EXISTS digipal_script_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_script_allographs DROP CONSTRAINT IF EXISTS digipal_script_allographs_script_id_10f72c9e70e2519_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_script_allographs DROP CONSTRAINT IF EXISTS digipal_script_allographs_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_scribe_reference DROP CONSTRAINT IF EXISTS digipal_scribe_reference_scribe_id_4c0edc26647a0f9d_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_scribe_reference DROP CONSTRAINT IF EXISTS digipal_scribe_reference_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_scribe DROP CONSTRAINT IF EXISTS digipal_scribe_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_scribe DROP CONSTRAINT IF EXISTS digipal_scribe_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_requestlog DROP CONSTRAINT IF EXISTS digipal_requestlog_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_repository DROP CONSTRAINT IF EXISTS digipal_repository_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_region DROP CONSTRAINT IF EXISTS digipal_region_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_region DROP CONSTRAINT IF EXISTS digipal_region_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_reference DROP CONSTRAINT IF EXISTS digipal_reference_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_reference DROP CONSTRAINT IF EXISTS digipal_reference_name_100f1428066baa8c_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_proportion DROP CONSTRAINT IF EXISTS digipal_proportion_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_placetype DROP CONSTRAINT IF EXISTS digipal_placetype_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_placeevidence DROP CONSTRAINT IF EXISTS digipal_placeevidence_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_place DROP CONSTRAINT IF EXISTS digipal_place_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_person DROP CONSTRAINT IF EXISTS digipal_person_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_person DROP CONSTRAINT IF EXISTS digipal_person_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_image DROP CONSTRAINT IF EXISTS digipal_page_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_ownertype DROP CONSTRAINT IF EXISTS digipal_ownertype_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_owner DROP CONSTRAINT IF EXISTS digipal_owner_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_ontographtype DROP CONSTRAINT IF EXISTS digipal_ontographtype_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_ontographtype DROP CONSTRAINT IF EXISTS digipal_ontographtype_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_ontograph DROP CONSTRAINT IF EXISTS digipal_ontograph_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_ontograph DROP CONSTRAINT IF EXISTS digipal_ontograph_name_265c31552bc69539_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_mediapermission DROP CONSTRAINT IF EXISTS digipal_mediapermission_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_measurement DROP CONSTRAINT IF EXISTS digipal_measurement_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_layout DROP CONSTRAINT IF EXISTS digipal_layout_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_latinstyle DROP CONSTRAINT IF EXISTS digipal_latinstyle_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_language DROP CONSTRAINT IF EXISTS digipal_language_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_language DROP CONSTRAINT IF EXISTS digipal_language_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_keyval DROP CONSTRAINT IF EXISTS digipal_keyval_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_keyval DROP CONSTRAINT IF EXISTS digipal_keyval_key_key;
ALTER TABLE IF EXISTS ONLY public.digipal_itemparttype DROP CONSTRAINT IF EXISTS digipal_itemparttype_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_itemparttype DROP CONSTRAINT IF EXISTS digipal_itemparttype_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_itempartitem DROP CONSTRAINT IF EXISTS digipal_itempartitem_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_itempartauthenticity DROP CONSTRAINT IF EXISTS digipal_itempartauthenticity_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_itempartauthenticity DROP CONSTRAINT IF EXISTS digipal_itempartauthenticity_item_part_id_47f6a7c669f3f627_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_itempart DROP CONSTRAINT IF EXISTS digipal_itempart_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_itempart_owners DROP CONSTRAINT IF EXISTS digipal_itempart_owners_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_itempart_owners DROP CONSTRAINT IF EXISTS digipal_itempart_owners_itempart_id_5528c2aa9c73c8f5_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_itemorigin DROP CONSTRAINT IF EXISTS digipal_itemorigin_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_institutiontype DROP CONSTRAINT IF EXISTS digipal_institutiontype_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_institution DROP CONSTRAINT IF EXISTS digipal_institution_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_imageannotationstatus DROP CONSTRAINT IF EXISTS digipal_imageannotationstatus_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_imageannotationstatus DROP CONSTRAINT IF EXISTS digipal_imageannotationstatus_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_idiographcomponent DROP CONSTRAINT IF EXISTS digipal_idiographcomponent_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_idiographcomponent_features DROP CONSTRAINT IF EXISTS digipal_idiographcomponent_features_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_idiographcomponent_features DROP CONSTRAINT IF EXISTS digipal_idiographco_idiographcomponent_id_4f822faf06b23e49_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_idiograph DROP CONSTRAINT IF EXISTS digipal_idiograph_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_idiograph_aspects DROP CONSTRAINT IF EXISTS digipal_idiograph_aspects_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_idiograph_aspects DROP CONSTRAINT IF EXISTS digipal_idiograph_aspects_idiograph_id_37c29800229491b3_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitemtype DROP CONSTRAINT IF EXISTS digipal_historicalitemtype_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitemdate DROP CONSTRAINT IF EXISTS digipal_historicalitemdate_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem DROP CONSTRAINT IF EXISTS digipal_historicalitem_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem_owners DROP CONSTRAINT IF EXISTS digipal_historicalitem_owners_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem_categories DROP CONSTRAINT IF EXISTS digipal_historicalitem_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem_owners DROP CONSTRAINT IF EXISTS digipal_historicalitem__historicalitem_id_73e4288db86a7e89_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_historicalitem_categories DROP CONSTRAINT IF EXISTS digipal_historicalitem__historicalitem_id_4066e470403531ed_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_handdescription DROP CONSTRAINT IF EXISTS digipal_handdescription_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_hand DROP CONSTRAINT IF EXISTS digipal_hand_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_hand_images DROP CONSTRAINT IF EXISTS digipal_hand_pages_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_hand_images DROP CONSTRAINT IF EXISTS digipal_hand_pages_hand_id_751fe6cc4410dccb_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_hair DROP CONSTRAINT IF EXISTS digipal_hair_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_hair DROP CONSTRAINT IF EXISTS digipal_hair_label_key;
ALTER TABLE IF EXISTS ONLY public.digipal_graphcomponent DROP CONSTRAINT IF EXISTS digipal_graphcomponent_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_graphcomponent_features DROP CONSTRAINT IF EXISTS digipal_graphcomponent_features_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_graphcomponent_features DROP CONSTRAINT IF EXISTS digipal_graphcomponent__graphcomponent_id_10ac817652129971_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_graph DROP CONSTRAINT IF EXISTS digipal_graph_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_graph_aspects DROP CONSTRAINT IF EXISTS digipal_graph_aspects_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_graph_aspects DROP CONSTRAINT IF EXISTS digipal_graph_aspects_graph_id_5a6bee2136d62dbf_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_format DROP CONSTRAINT IF EXISTS digipal_format_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_format DROP CONSTRAINT IF EXISTS digipal_format_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_feature DROP CONSTRAINT IF EXISTS digipal_feature_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_feature DROP CONSTRAINT IF EXISTS digipal_feature_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_description DROP CONSTRAINT IF EXISTS digipal_description_source_id_52aa5e9c55e6ac65_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_description DROP CONSTRAINT IF EXISTS digipal_description_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_decoration DROP CONSTRAINT IF EXISTS digipal_decoration_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_dateevidence DROP CONSTRAINT IF EXISTS digipal_dateevidence_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_date DROP CONSTRAINT IF EXISTS digipal_date_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_currentitem DROP CONSTRAINT IF EXISTS digipal_currentitem_repository_id_26373c79ce7d91df_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_currentitem DROP CONSTRAINT IF EXISTS digipal_currentitem_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_currentitem_owners DROP CONSTRAINT IF EXISTS digipal_currentitem_owners_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_currentitem_owners DROP CONSTRAINT IF EXISTS digipal_currentitem_owners_currentitem_id_1caca3c5ef1809d3_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_county DROP CONSTRAINT IF EXISTS digipal_county_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_county DROP CONSTRAINT IF EXISTS digipal_county_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_component DROP CONSTRAINT IF EXISTS digipal_component_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_component DROP CONSTRAINT IF EXISTS digipal_component_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_component_features DROP CONSTRAINT IF EXISTS digipal_component_features_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_component_features DROP CONSTRAINT IF EXISTS digipal_component_features_component_id_21fedf5478617c03_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_collation DROP CONSTRAINT IF EXISTS digipal_collation_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_characterform DROP CONSTRAINT IF EXISTS digipal_characterform_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_characterform DROP CONSTRAINT IF EXISTS digipal_characterform_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_character DROP CONSTRAINT IF EXISTS digipal_character_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_character DROP CONSTRAINT IF EXISTS digipal_character_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_character_components DROP CONSTRAINT IF EXISTS digipal_character_components_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_character_components DROP CONSTRAINT IF EXISTS digipal_character_components_character_id_1b523e3f0bae4ccd_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_category DROP CONSTRAINT IF EXISTS digipal_category_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_category DROP CONSTRAINT IF EXISTS digipal_category_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_cataloguenumber DROP CONSTRAINT IF EXISTS digipal_cataloguenumber_source_id_5930e00c9cc7bb_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_cataloguenumber DROP CONSTRAINT IF EXISTS digipal_cataloguenumber_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_carouselitem DROP CONSTRAINT IF EXISTS digipal_carouselitem_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_authenticitycategory DROP CONSTRAINT IF EXISTS digipal_authenticitycategory_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_authenticitycategory DROP CONSTRAINT IF EXISTS digipal_authenticitycategory_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_aspect DROP CONSTRAINT IF EXISTS digipal_aspect_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_aspect DROP CONSTRAINT IF EXISTS digipal_aspect_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_aspect_features DROP CONSTRAINT IF EXISTS digipal_aspect_features_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_aspect_features DROP CONSTRAINT IF EXISTS digipal_aspect_features_aspect_id_45c6cbad27f58ba7_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_archive DROP CONSTRAINT IF EXISTS digipal_archive_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_appearance DROP CONSTRAINT IF EXISTS digipal_appearance_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_apitransform DROP CONSTRAINT IF EXISTS digipal_apitransform_title_key;
ALTER TABLE IF EXISTS ONLY public.digipal_apitransform DROP CONSTRAINT IF EXISTS digipal_apitransform_slug_key;
ALTER TABLE IF EXISTS ONLY public.digipal_apitransform DROP CONSTRAINT IF EXISTS digipal_apitransform_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_annotation DROP CONSTRAINT IF EXISTS digipal_annotation_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_annotation DROP CONSTRAINT IF EXISTS digipal_annotation_graph_id_key;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet DROP CONSTRAINT IF EXISTS digipal_alphabet_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet_ontographs DROP CONSTRAINT IF EXISTS digipal_alphabet_ontographs_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet_ontographs DROP CONSTRAINT IF EXISTS digipal_alphabet_ontographs_alphabet_id_554c9d224844bb33_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet DROP CONSTRAINT IF EXISTS digipal_alphabet_name_key;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet_hands DROP CONSTRAINT IF EXISTS digipal_alphabet_hands_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_alphabet_hands DROP CONSTRAINT IF EXISTS digipal_alphabet_hands_alphabet_id_662a1e1db928a377_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_allographcomponent DROP CONSTRAINT IF EXISTS digipal_allographcomponent_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_allographcomponent_features DROP CONSTRAINT IF EXISTS digipal_allographcomponent_features_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_allographcomponent_features DROP CONSTRAINT IF EXISTS digipal_allographco_allographcomponent_id_2fdd3c9bae0cc1f1_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_allograph DROP CONSTRAINT IF EXISTS digipal_allograph_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_allograph DROP CONSTRAINT IF EXISTS digipal_allograph_name_60798fd305198374_uniq;
ALTER TABLE IF EXISTS ONLY public.digipal_allograph_aspects DROP CONSTRAINT IF EXISTS digipal_allograph_aspects_pkey;
ALTER TABLE IF EXISTS ONLY public.digipal_allograph_aspects DROP CONSTRAINT IF EXISTS digipal_allograph_aspects_allograph_id_4b3207b4c61b3b49_uniq;
ALTER TABLE IF EXISTS ONLY public.core_sitepermission DROP CONSTRAINT IF EXISTS core_sitepermission_user_id_key;
ALTER TABLE IF EXISTS ONLY public.core_sitepermission_sites DROP CONSTRAINT IF EXISTS core_sitepermission_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.core_sitepermission_sites DROP CONSTRAINT IF EXISTS core_sitepermission_sit_sitepermission_id_31fc3b7b7e3badd5_uniq;
ALTER TABLE IF EXISTS ONLY public.core_sitepermission DROP CONSTRAINT IF EXISTS core_sitepermission_pkey;
ALTER TABLE IF EXISTS ONLY public.conf_setting DROP CONSTRAINT IF EXISTS conf_setting_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost_related_posts DROP CONSTRAINT IF EXISTS blog_blogpost_related_posts_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost_related_posts DROP CONSTRAINT IF EXISTS blog_blogpost_related_po_from_blogpost_id_3007eb9b6b16df8b_uniq;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost DROP CONSTRAINT IF EXISTS blog_blogpost_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost_categories DROP CONSTRAINT IF EXISTS blog_blogpost_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_blogpost_categories DROP CONSTRAINT IF EXISTS blog_blogpost_categories_blogpost_id_79f2a5569187bd14_uniq;
ALTER TABLE IF EXISTS ONLY public.blog_blogcategory DROP CONSTRAINT IF EXISTS blog_blogcategory_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_username_key;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_permission_id_key;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_group_id_key;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_codename_key;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_permission_id_key;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_name_key;
ALTER TABLE IF EXISTS public.twitter_tweet ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.twitter_query ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.south_migrationhistory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reversion_version ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reversion_revision ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pages_page ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.generic_rating ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.generic_keyword ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.generic_assignedkeyword ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.galleries_galleryimage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.forms_formentry ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.forms_fieldentry ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.forms_field ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.django_site ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.django_redirect ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.django_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.django_comment_flags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_textitempart ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_textpattern ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_textcontentxmlstatus ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_textcontentxmlcopy ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_textcontentxml ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_textcontenttype ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_textcontent_languages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_textcontent ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_textannotation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_languages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_entryhand ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_text ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_stewartrecord ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_source ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_scriptcomponent_features ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_scriptcomponent ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_script_allographs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_script ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_scribe_reference ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_scribe ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_requestlog ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_repository ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_region ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_reference ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_proportion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_placetype ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_placeevidence ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_place ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_person ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_ownertype ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_owner ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_ontographtype ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_ontograph ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_mediapermission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_measurement ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_layout ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_latinstyle ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_language ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_keyval ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_itemparttype ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_itempartitem ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_itempartauthenticity ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_itempart_owners ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_itempart ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_itemorigin ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_institutiontype ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_institution ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_imageannotationstatus ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_image ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_idiographcomponent_features ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_idiographcomponent ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_idiograph_aspects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_idiograph ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_historicalitemtype ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_historicalitemdate ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_historicalitem_owners ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_historicalitem_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_historicalitem ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_handdescription ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_hand_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_hand ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_hair ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_graphcomponent_features ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_graphcomponent ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_graph_aspects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_graph ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_format ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_feature ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_description ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_decoration ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_dateevidence ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_date ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_currentitem_owners ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_currentitem ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_county ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_component_features ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_component ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_collation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_characterform ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_character_components ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_character ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_category ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_cataloguenumber ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_carouselitem ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_authenticitycategory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_aspect_features ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_aspect ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_archive ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_appearance ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_apitransform ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_annotation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_alphabet_ontographs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_alphabet_hands ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_alphabet ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_allographcomponent_features ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_allographcomponent ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_allograph_aspects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.digipal_allograph ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.core_sitepermission_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.core_sitepermission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.conf_setting ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_blogpost_related_posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_blogpost_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_blogpost ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blog_blogcategory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.twitter_tweet_id_seq;
DROP TABLE IF EXISTS public.twitter_tweet;
DROP SEQUENCE IF EXISTS public.twitter_query_id_seq;
DROP TABLE IF EXISTS public.twitter_query;
DROP SEQUENCE IF EXISTS public.south_migrationhistory_id_seq;
DROP TABLE IF EXISTS public.south_migrationhistory;
DROP SEQUENCE IF EXISTS public.reversion_version_id_seq;
DROP TABLE IF EXISTS public.reversion_version;
DROP SEQUENCE IF EXISTS public.reversion_revision_id_seq;
DROP TABLE IF EXISTS public.reversion_revision;
DROP TABLE IF EXISTS public.pages_richtextpage;
DROP SEQUENCE IF EXISTS public.pages_page_id_seq;
DROP TABLE IF EXISTS public.pages_page;
DROP TABLE IF EXISTS public.pages_link;
DROP TABLE IF EXISTS public.generic_threadedcomment;
DROP SEQUENCE IF EXISTS public.generic_rating_id_seq;
DROP TABLE IF EXISTS public.generic_rating;
DROP SEQUENCE IF EXISTS public.generic_keyword_id_seq;
DROP TABLE IF EXISTS public.generic_keyword;
DROP SEQUENCE IF EXISTS public.generic_assignedkeyword_id_seq;
DROP TABLE IF EXISTS public.generic_assignedkeyword;
DROP SEQUENCE IF EXISTS public.galleries_galleryimage_id_seq;
DROP TABLE IF EXISTS public.galleries_galleryimage;
DROP TABLE IF EXISTS public.galleries_gallery;
DROP SEQUENCE IF EXISTS public.forms_formentry_id_seq;
DROP TABLE IF EXISTS public.forms_formentry;
DROP TABLE IF EXISTS public.forms_form;
DROP SEQUENCE IF EXISTS public.forms_fieldentry_id_seq;
DROP TABLE IF EXISTS public.forms_fieldentry;
DROP SEQUENCE IF EXISTS public.forms_field_id_seq;
DROP TABLE IF EXISTS public.forms_field;
DROP SEQUENCE IF EXISTS public.django_site_id_seq;
DROP TABLE IF EXISTS public.django_site;
DROP TABLE IF EXISTS public.django_session;
DROP SEQUENCE IF EXISTS public.django_redirect_id_seq;
DROP TABLE IF EXISTS public.django_redirect;
DROP SEQUENCE IF EXISTS public.django_migrations_id_seq;
DROP TABLE IF EXISTS public.django_migrations;
DROP SEQUENCE IF EXISTS public.django_content_type_id_seq;
DROP TABLE IF EXISTS public.django_content_type;
DROP SEQUENCE IF EXISTS public.django_comments_id_seq;
DROP TABLE IF EXISTS public.django_comments;
DROP SEQUENCE IF EXISTS public.django_comment_flags_id_seq;
DROP TABLE IF EXISTS public.django_comment_flags;
DROP SEQUENCE IF EXISTS public.django_admin_log_id_seq;
DROP TABLE IF EXISTS public.django_admin_log;
DROP SEQUENCE IF EXISTS public.digipal_textitempart_id_seq;
DROP TABLE IF EXISTS public.digipal_textitempart;
DROP SEQUENCE IF EXISTS public.digipal_text_textpattern_id_seq;
DROP TABLE IF EXISTS public.digipal_text_textpattern;
DROP SEQUENCE IF EXISTS public.digipal_text_textcontentxmlstatus_id_seq;
DROP TABLE IF EXISTS public.digipal_text_textcontentxmlstatus;
DROP SEQUENCE IF EXISTS public.digipal_text_textcontentxmlcopy_id_seq;
DROP TABLE IF EXISTS public.digipal_text_textcontentxmlcopy;
DROP SEQUENCE IF EXISTS public.digipal_text_textcontentxml_id_seq;
DROP TABLE IF EXISTS public.digipal_text_textcontentxml;
DROP SEQUENCE IF EXISTS public.digipal_text_textcontenttype_id_seq;
DROP TABLE IF EXISTS public.digipal_text_textcontenttype;
DROP SEQUENCE IF EXISTS public.digipal_text_textcontent_languages_id_seq;
DROP TABLE IF EXISTS public.digipal_text_textcontent_languages;
DROP SEQUENCE IF EXISTS public.digipal_text_textcontent_id_seq;
DROP TABLE IF EXISTS public.digipal_text_textcontent;
DROP SEQUENCE IF EXISTS public.digipal_text_textannotation_id_seq;
DROP TABLE IF EXISTS public.digipal_text_textannotation;
DROP SEQUENCE IF EXISTS public.digipal_text_languages_id_seq;
DROP TABLE IF EXISTS public.digipal_text_languages;
DROP SEQUENCE IF EXISTS public.digipal_text_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_text_entryhand_id_seq;
DROP TABLE IF EXISTS public.digipal_text_entryhand;
DROP SEQUENCE IF EXISTS public.digipal_text_categories_id_seq;
DROP TABLE IF EXISTS public.digipal_text_categories;
DROP TABLE IF EXISTS public.digipal_text;
DROP SEQUENCE IF EXISTS public.digipal_stewartrecord_id_seq;
DROP TABLE IF EXISTS public.digipal_stewartrecord;
DROP SEQUENCE IF EXISTS public.digipal_status_id_seq;
DROP TABLE IF EXISTS public.digipal_status;
DROP SEQUENCE IF EXISTS public.digipal_source_id_seq;
DROP TABLE IF EXISTS public.digipal_source;
DROP SEQUENCE IF EXISTS public.digipal_scriptcomponent_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_scriptcomponent_features_id_seq;
DROP TABLE IF EXISTS public.digipal_scriptcomponent_features;
DROP TABLE IF EXISTS public.digipal_scriptcomponent;
DROP SEQUENCE IF EXISTS public.digipal_script_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_script_allographs_id_seq;
DROP TABLE IF EXISTS public.digipal_script_allographs;
DROP TABLE IF EXISTS public.digipal_script;
DROP SEQUENCE IF EXISTS public.digipal_scribe_reference_id_seq;
DROP TABLE IF EXISTS public.digipal_scribe_reference;
DROP SEQUENCE IF EXISTS public.digipal_scribe_id_seq;
DROP TABLE IF EXISTS public.digipal_scribe;
DROP SEQUENCE IF EXISTS public.digipal_requestlog_id_seq;
DROP TABLE IF EXISTS public.digipal_requestlog;
DROP SEQUENCE IF EXISTS public.digipal_repository_id_seq;
DROP TABLE IF EXISTS public.digipal_repository;
DROP SEQUENCE IF EXISTS public.digipal_region_id_seq;
DROP TABLE IF EXISTS public.digipal_region;
DROP SEQUENCE IF EXISTS public.digipal_reference_id_seq;
DROP TABLE IF EXISTS public.digipal_reference;
DROP SEQUENCE IF EXISTS public.digipal_proportion_id_seq;
DROP TABLE IF EXISTS public.digipal_proportion;
DROP SEQUENCE IF EXISTS public.digipal_placetype_id_seq;
DROP TABLE IF EXISTS public.digipal_placetype;
DROP SEQUENCE IF EXISTS public.digipal_placeevidence_id_seq;
DROP TABLE IF EXISTS public.digipal_placeevidence;
DROP SEQUENCE IF EXISTS public.digipal_place_id_seq;
DROP TABLE IF EXISTS public.digipal_place;
DROP SEQUENCE IF EXISTS public.digipal_person_id_seq;
DROP TABLE IF EXISTS public.digipal_person;
DROP SEQUENCE IF EXISTS public.digipal_ownertype_id_seq;
DROP TABLE IF EXISTS public.digipal_ownertype;
DROP SEQUENCE IF EXISTS public.digipal_owner_id_seq;
DROP TABLE IF EXISTS public.digipal_owner;
DROP SEQUENCE IF EXISTS public.digipal_ontographtype_id_seq;
DROP TABLE IF EXISTS public.digipal_ontographtype;
DROP SEQUENCE IF EXISTS public.digipal_ontograph_id_seq;
DROP TABLE IF EXISTS public.digipal_ontograph;
DROP SEQUENCE IF EXISTS public.digipal_mediapermission_id_seq;
DROP TABLE IF EXISTS public.digipal_mediapermission;
DROP SEQUENCE IF EXISTS public.digipal_measurement_id_seq;
DROP TABLE IF EXISTS public.digipal_measurement;
DROP SEQUENCE IF EXISTS public.digipal_layout_id_seq;
DROP TABLE IF EXISTS public.digipal_layout;
DROP SEQUENCE IF EXISTS public.digipal_latinstyle_id_seq;
DROP TABLE IF EXISTS public.digipal_latinstyle;
DROP SEQUENCE IF EXISTS public.digipal_language_id_seq;
DROP TABLE IF EXISTS public.digipal_language;
DROP SEQUENCE IF EXISTS public.digipal_keyval_id_seq;
DROP TABLE IF EXISTS public.digipal_keyval;
DROP SEQUENCE IF EXISTS public.digipal_itemparttype_id_seq;
DROP TABLE IF EXISTS public.digipal_itemparttype;
DROP SEQUENCE IF EXISTS public.digipal_itempartitem_id_seq;
DROP TABLE IF EXISTS public.digipal_itempartitem;
DROP SEQUENCE IF EXISTS public.digipal_itempartauthenticity_id_seq;
DROP TABLE IF EXISTS public.digipal_itempartauthenticity;
DROP SEQUENCE IF EXISTS public.digipal_itempart_owners_id_seq;
DROP TABLE IF EXISTS public.digipal_itempart_owners;
DROP SEQUENCE IF EXISTS public.digipal_itempart_id_seq;
DROP TABLE IF EXISTS public.digipal_itempart;
DROP SEQUENCE IF EXISTS public.digipal_itemorigin_id_seq;
DROP TABLE IF EXISTS public.digipal_itemorigin;
DROP SEQUENCE IF EXISTS public.digipal_institutiontype_id_seq;
DROP TABLE IF EXISTS public.digipal_institutiontype;
DROP SEQUENCE IF EXISTS public.digipal_institution_id_seq;
DROP TABLE IF EXISTS public.digipal_institution;
DROP SEQUENCE IF EXISTS public.digipal_imageannotationstatus_id_seq;
DROP TABLE IF EXISTS public.digipal_imageannotationstatus;
DROP SEQUENCE IF EXISTS public.digipal_image_id_seq;
DROP TABLE IF EXISTS public.digipal_image;
DROP SEQUENCE IF EXISTS public.digipal_idiographcomponent_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_idiographcomponent_features_id_seq;
DROP TABLE IF EXISTS public.digipal_idiographcomponent_features;
DROP TABLE IF EXISTS public.digipal_idiographcomponent;
DROP SEQUENCE IF EXISTS public.digipal_idiograph_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_idiograph_aspects_id_seq;
DROP TABLE IF EXISTS public.digipal_idiograph_aspects;
DROP TABLE IF EXISTS public.digipal_idiograph;
DROP SEQUENCE IF EXISTS public.digipal_historicalitemtype_id_seq;
DROP TABLE IF EXISTS public.digipal_historicalitemtype;
DROP SEQUENCE IF EXISTS public.digipal_historicalitemdate_id_seq;
DROP TABLE IF EXISTS public.digipal_historicalitemdate;
DROP SEQUENCE IF EXISTS public.digipal_historicalitem_owners_id_seq;
DROP TABLE IF EXISTS public.digipal_historicalitem_owners;
DROP SEQUENCE IF EXISTS public.digipal_historicalitem_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_historicalitem_categories_id_seq;
DROP TABLE IF EXISTS public.digipal_historicalitem_categories;
DROP TABLE IF EXISTS public.digipal_historicalitem;
DROP SEQUENCE IF EXISTS public.digipal_handdescription_id_seq;
DROP TABLE IF EXISTS public.digipal_handdescription;
DROP SEQUENCE IF EXISTS public.digipal_hand_images_id_seq;
DROP TABLE IF EXISTS public.digipal_hand_images;
DROP SEQUENCE IF EXISTS public.digipal_hand_id_seq;
DROP TABLE IF EXISTS public.digipal_hand;
DROP SEQUENCE IF EXISTS public.digipal_hair_id_seq;
DROP TABLE IF EXISTS public.digipal_hair;
DROP SEQUENCE IF EXISTS public.digipal_graphcomponent_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_graphcomponent_features_id_seq;
DROP TABLE IF EXISTS public.digipal_graphcomponent_features;
DROP TABLE IF EXISTS public.digipal_graphcomponent;
DROP SEQUENCE IF EXISTS public.digipal_graph_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_graph_aspects_id_seq;
DROP TABLE IF EXISTS public.digipal_graph_aspects;
DROP TABLE IF EXISTS public.digipal_graph;
DROP SEQUENCE IF EXISTS public.digipal_format_id_seq;
DROP TABLE IF EXISTS public.digipal_format;
DROP SEQUENCE IF EXISTS public.digipal_feature_id_seq;
DROP TABLE IF EXISTS public.digipal_feature;
DROP SEQUENCE IF EXISTS public.digipal_description_id_seq;
DROP TABLE IF EXISTS public.digipal_description;
DROP SEQUENCE IF EXISTS public.digipal_decoration_id_seq;
DROP TABLE IF EXISTS public.digipal_decoration;
DROP SEQUENCE IF EXISTS public.digipal_dateevidence_id_seq;
DROP TABLE IF EXISTS public.digipal_dateevidence;
DROP SEQUENCE IF EXISTS public.digipal_date_id_seq;
DROP TABLE IF EXISTS public.digipal_date;
DROP SEQUENCE IF EXISTS public.digipal_currentitem_owners_id_seq;
DROP TABLE IF EXISTS public.digipal_currentitem_owners;
DROP SEQUENCE IF EXISTS public.digipal_currentitem_id_seq;
DROP TABLE IF EXISTS public.digipal_currentitem;
DROP SEQUENCE IF EXISTS public.digipal_county_id_seq;
DROP TABLE IF EXISTS public.digipal_county;
DROP SEQUENCE IF EXISTS public.digipal_component_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_component_features_id_seq;
DROP TABLE IF EXISTS public.digipal_component_features;
DROP TABLE IF EXISTS public.digipal_component;
DROP SEQUENCE IF EXISTS public.digipal_collation_id_seq;
DROP TABLE IF EXISTS public.digipal_collation;
DROP SEQUENCE IF EXISTS public.digipal_characterform_id_seq;
DROP TABLE IF EXISTS public.digipal_characterform;
DROP SEQUENCE IF EXISTS public.digipal_character_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_character_components_id_seq;
DROP TABLE IF EXISTS public.digipal_character_components;
DROP TABLE IF EXISTS public.digipal_character;
DROP SEQUENCE IF EXISTS public.digipal_category_id_seq;
DROP TABLE IF EXISTS public.digipal_category;
DROP SEQUENCE IF EXISTS public.digipal_cataloguenumber_id_seq;
DROP TABLE IF EXISTS public.digipal_cataloguenumber;
DROP SEQUENCE IF EXISTS public.digipal_carouselitem_id_seq;
DROP TABLE IF EXISTS public.digipal_carouselitem;
DROP SEQUENCE IF EXISTS public.digipal_authenticitycategory_id_seq;
DROP TABLE IF EXISTS public.digipal_authenticitycategory;
DROP SEQUENCE IF EXISTS public.digipal_aspect_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_aspect_features_id_seq;
DROP TABLE IF EXISTS public.digipal_aspect_features;
DROP TABLE IF EXISTS public.digipal_aspect;
DROP SEQUENCE IF EXISTS public.digipal_archive_id_seq;
DROP TABLE IF EXISTS public.digipal_archive;
DROP SEQUENCE IF EXISTS public.digipal_appearance_id_seq;
DROP TABLE IF EXISTS public.digipal_appearance;
DROP SEQUENCE IF EXISTS public.digipal_apitransform_id_seq;
DROP TABLE IF EXISTS public.digipal_apitransform;
DROP SEQUENCE IF EXISTS public.digipal_annotation_id_seq;
DROP TABLE IF EXISTS public.digipal_annotation;
DROP SEQUENCE IF EXISTS public.digipal_alphabet_ontographs_id_seq;
DROP TABLE IF EXISTS public.digipal_alphabet_ontographs;
DROP SEQUENCE IF EXISTS public.digipal_alphabet_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_alphabet_hands_id_seq;
DROP TABLE IF EXISTS public.digipal_alphabet_hands;
DROP TABLE IF EXISTS public.digipal_alphabet;
DROP SEQUENCE IF EXISTS public.digipal_allographcomponent_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_allographcomponent_features_id_seq;
DROP TABLE IF EXISTS public.digipal_allographcomponent_features;
DROP TABLE IF EXISTS public.digipal_allographcomponent;
DROP SEQUENCE IF EXISTS public.digipal_allograph_id_seq;
DROP SEQUENCE IF EXISTS public.digipal_allograph_aspects_id_seq;
DROP TABLE IF EXISTS public.digipal_allograph_aspects;
DROP TABLE IF EXISTS public.digipal_allograph;
DROP SEQUENCE IF EXISTS public.core_sitepermission_sites_id_seq;
DROP TABLE IF EXISTS public.core_sitepermission_sites;
DROP SEQUENCE IF EXISTS public.core_sitepermission_id_seq;
DROP TABLE IF EXISTS public.core_sitepermission;
DROP SEQUENCE IF EXISTS public.conf_setting_id_seq;
DROP TABLE IF EXISTS public.conf_setting;
DROP SEQUENCE IF EXISTS public.blog_blogpost_related_posts_id_seq;
DROP TABLE IF EXISTS public.blog_blogpost_related_posts;
DROP SEQUENCE IF EXISTS public.blog_blogpost_id_seq;
DROP SEQUENCE IF EXISTS public.blog_blogpost_categories_id_seq;
DROP TABLE IF EXISTS public.blog_blogpost_categories;
DROP TABLE IF EXISTS public.blog_blogpost;
DROP SEQUENCE IF EXISTS public.blog_blogcategory_id_seq;
DROP TABLE IF EXISTS public.blog_blogcategory;
DROP SEQUENCE IF EXISTS public.auth_user_user_permissions_id_seq;
DROP TABLE IF EXISTS public.auth_user_user_permissions;
DROP SEQUENCE IF EXISTS public.auth_user_id_seq;
DROP SEQUENCE IF EXISTS public.auth_user_groups_id_seq;
DROP TABLE IF EXISTS public.auth_user_groups;
DROP TABLE IF EXISTS public.auth_user;
DROP SEQUENCE IF EXISTS public.auth_permission_id_seq;
DROP TABLE IF EXISTS public.auth_permission;
DROP SEQUENCE IF EXISTS public.auth_group_permissions_id_seq;
DROP TABLE IF EXISTS public.auth_group_permissions;
DROP SEQUENCE IF EXISTS public.auth_group_id_seq;
DROP TABLE IF EXISTS public.auth_group;
DROP EXTENSION IF EXISTS plpgsql;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO app_digipal;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO app_digipal;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO app_digipal;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO app_digipal;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO app_digipal;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO app_digipal;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE auth_user OWNER TO app_digipal;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE auth_user_groups OWNER TO app_digipal;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_groups_id_seq OWNER TO app_digipal;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_id_seq OWNER TO app_digipal;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_user_user_permissions OWNER TO app_digipal;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_user_permissions_id_seq OWNER TO app_digipal;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: blog_blogcategory; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE blog_blogcategory (
    slug character varying(2000),
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE blog_blogcategory OWNER TO app_digipal;

--
-- Name: blog_blogcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE blog_blogcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_blogcategory_id_seq OWNER TO app_digipal;

--
-- Name: blog_blogcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE blog_blogcategory_id_seq OWNED BY blog_blogcategory.id;


--
-- Name: blog_blogpost; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE blog_blogpost (
    status integer NOT NULL,
    description text NOT NULL,
    title character varying(500) NOT NULL,
    short_url character varying(200),
    id integer NOT NULL,
    content text NOT NULL,
    expiry_date timestamp with time zone,
    publish_date timestamp with time zone,
    user_id integer NOT NULL,
    slug character varying(2000),
    comments_count integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    site_id integer NOT NULL,
    rating_average double precision NOT NULL,
    rating_count integer NOT NULL,
    allow_comments boolean NOT NULL,
    featured_image character varying(255),
    gen_description boolean NOT NULL,
    _meta_title character varying(500),
    in_sitemap boolean NOT NULL,
    rating_sum integer NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone
);


ALTER TABLE blog_blogpost OWNER TO app_digipal;

--
-- Name: blog_blogpost_categories; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE blog_blogpost_categories (
    id integer NOT NULL,
    blogpost_id integer NOT NULL,
    blogcategory_id integer NOT NULL
);


ALTER TABLE blog_blogpost_categories OWNER TO app_digipal;

--
-- Name: blog_blogpost_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE blog_blogpost_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_blogpost_categories_id_seq OWNER TO app_digipal;

--
-- Name: blog_blogpost_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE blog_blogpost_categories_id_seq OWNED BY blog_blogpost_categories.id;


--
-- Name: blog_blogpost_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE blog_blogpost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_blogpost_id_seq OWNER TO app_digipal;

--
-- Name: blog_blogpost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE blog_blogpost_id_seq OWNED BY blog_blogpost.id;


--
-- Name: blog_blogpost_related_posts; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE blog_blogpost_related_posts (
    id integer NOT NULL,
    from_blogpost_id integer NOT NULL,
    to_blogpost_id integer NOT NULL
);


ALTER TABLE blog_blogpost_related_posts OWNER TO app_digipal;

--
-- Name: blog_blogpost_related_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE blog_blogpost_related_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_blogpost_related_posts_id_seq OWNER TO app_digipal;

--
-- Name: blog_blogpost_related_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE blog_blogpost_related_posts_id_seq OWNED BY blog_blogpost_related_posts.id;


--
-- Name: conf_setting; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE conf_setting (
    id integer NOT NULL,
    value character varying(2000) NOT NULL,
    name character varying(50) NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE conf_setting OWNER TO app_digipal;

--
-- Name: conf_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE conf_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE conf_setting_id_seq OWNER TO app_digipal;

--
-- Name: conf_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE conf_setting_id_seq OWNED BY conf_setting.id;


--
-- Name: core_sitepermission; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE core_sitepermission (
    id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE core_sitepermission OWNER TO app_digipal;

--
-- Name: core_sitepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE core_sitepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_sitepermission_id_seq OWNER TO app_digipal;

--
-- Name: core_sitepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE core_sitepermission_id_seq OWNED BY core_sitepermission.id;


--
-- Name: core_sitepermission_sites; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE core_sitepermission_sites (
    id integer NOT NULL,
    sitepermission_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE core_sitepermission_sites OWNER TO app_digipal;

--
-- Name: core_sitepermission_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE core_sitepermission_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_sitepermission_sites_id_seq OWNER TO app_digipal;

--
-- Name: core_sitepermission_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE core_sitepermission_sites_id_seq OWNED BY core_sitepermission_sites.id;


--
-- Name: digipal_allograph; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_allograph (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    character_id integer NOT NULL,
    "default" boolean NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    hidden boolean NOT NULL
);


ALTER TABLE digipal_allograph OWNER TO app_digipal;

--
-- Name: digipal_allograph_aspects; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_allograph_aspects (
    id integer NOT NULL,
    allograph_id integer NOT NULL,
    aspect_id integer NOT NULL
);


ALTER TABLE digipal_allograph_aspects OWNER TO app_digipal;

--
-- Name: digipal_allograph_aspects_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_allograph_aspects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_allograph_aspects_id_seq OWNER TO app_digipal;

--
-- Name: digipal_allograph_aspects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_allograph_aspects_id_seq OWNED BY digipal_allograph_aspects.id;


--
-- Name: digipal_allograph_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_allograph_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_allograph_id_seq OWNER TO app_digipal;

--
-- Name: digipal_allograph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_allograph_id_seq OWNED BY digipal_allograph.id;


--
-- Name: digipal_allographcomponent; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_allographcomponent (
    id integer NOT NULL,
    allograph_id integer NOT NULL,
    component_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_allographcomponent OWNER TO app_digipal;

--
-- Name: digipal_allographcomponent_features; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_allographcomponent_features (
    id integer NOT NULL,
    allographcomponent_id integer NOT NULL,
    feature_id integer NOT NULL
);


ALTER TABLE digipal_allographcomponent_features OWNER TO app_digipal;

--
-- Name: digipal_allographcomponent_features_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_allographcomponent_features_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_allographcomponent_features_id_seq OWNER TO app_digipal;

--
-- Name: digipal_allographcomponent_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_allographcomponent_features_id_seq OWNED BY digipal_allographcomponent_features.id;


--
-- Name: digipal_allographcomponent_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_allographcomponent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_allographcomponent_id_seq OWNER TO app_digipal;

--
-- Name: digipal_allographcomponent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_allographcomponent_id_seq OWNED BY digipal_allographcomponent.id;


--
-- Name: digipal_alphabet; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_alphabet (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_alphabet OWNER TO app_digipal;

--
-- Name: digipal_alphabet_hands; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_alphabet_hands (
    id integer NOT NULL,
    alphabet_id integer NOT NULL,
    hand_id integer NOT NULL
);


ALTER TABLE digipal_alphabet_hands OWNER TO app_digipal;

--
-- Name: digipal_alphabet_hands_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_alphabet_hands_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_alphabet_hands_id_seq OWNER TO app_digipal;

--
-- Name: digipal_alphabet_hands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_alphabet_hands_id_seq OWNED BY digipal_alphabet_hands.id;


--
-- Name: digipal_alphabet_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_alphabet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_alphabet_id_seq OWNER TO app_digipal;

--
-- Name: digipal_alphabet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_alphabet_id_seq OWNED BY digipal_alphabet.id;


--
-- Name: digipal_alphabet_ontographs; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_alphabet_ontographs (
    id integer NOT NULL,
    alphabet_id integer NOT NULL,
    ontograph_id integer NOT NULL
);


ALTER TABLE digipal_alphabet_ontographs OWNER TO app_digipal;

--
-- Name: digipal_alphabet_ontographs_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_alphabet_ontographs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_alphabet_ontographs_id_seq OWNER TO app_digipal;

--
-- Name: digipal_alphabet_ontographs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_alphabet_ontographs_id_seq OWNED BY digipal_alphabet_ontographs.id;


--
-- Name: digipal_annotation; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_annotation (
    id integer NOT NULL,
    image_id integer NOT NULL,
    cutout character varying(256),
    status_id integer,
    before_id integer,
    graph_id integer,
    after_id integer,
    vector_id text NOT NULL,
    geo_json text NOT NULL,
    display_note text,
    internal_note text,
    author_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    rotation double precision NOT NULL,
    holes character varying(1000),
    clientid character varying(24),
    type character varying(15)
);


ALTER TABLE digipal_annotation OWNER TO app_digipal;

--
-- Name: digipal_annotation_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_annotation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_annotation_id_seq OWNER TO app_digipal;

--
-- Name: digipal_annotation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_annotation_id_seq OWNED BY digipal_annotation.id;


--
-- Name: digipal_apitransform; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_apitransform (
    id integer NOT NULL,
    title character varying(30) NOT NULL,
    slug character varying(30) NOT NULL,
    template text,
    description text,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    mimetype character varying(30) NOT NULL,
    sample_request character varying(200),
    webpage boolean NOT NULL
);


ALTER TABLE digipal_apitransform OWNER TO app_digipal;

--
-- Name: digipal_apitransform_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_apitransform_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_apitransform_id_seq OWNER TO app_digipal;

--
-- Name: digipal_apitransform_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_apitransform_id_seq OWNED BY digipal_apitransform.id;


--
-- Name: digipal_appearance; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_appearance (
    id integer NOT NULL,
    legacy_id integer,
    text character varying(128) NOT NULL,
    sort_order integer NOT NULL,
    description character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_appearance OWNER TO app_digipal;

--
-- Name: digipal_appearance_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_appearance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_appearance_id_seq OWNER TO app_digipal;

--
-- Name: digipal_appearance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_appearance_id_seq OWNED BY digipal_appearance.id;


--
-- Name: digipal_archive; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_archive (
    id integer NOT NULL,
    legacy_id integer,
    content_type_id integer NOT NULL,
    object_id integer NOT NULL,
    historical_item_id integer NOT NULL,
    dubitable boolean,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    CONSTRAINT digipal_archive_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE digipal_archive OWNER TO app_digipal;

--
-- Name: digipal_archive_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_archive_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_archive_id_seq OWNER TO app_digipal;

--
-- Name: digipal_archive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_archive_id_seq OWNED BY digipal_archive.id;


--
-- Name: digipal_aspect; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_aspect (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_aspect OWNER TO app_digipal;

--
-- Name: digipal_aspect_features; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_aspect_features (
    id integer NOT NULL,
    aspect_id integer NOT NULL,
    feature_id integer NOT NULL
);


ALTER TABLE digipal_aspect_features OWNER TO app_digipal;

--
-- Name: digipal_aspect_features_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_aspect_features_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_aspect_features_id_seq OWNER TO app_digipal;

--
-- Name: digipal_aspect_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_aspect_features_id_seq OWNED BY digipal_aspect_features.id;


--
-- Name: digipal_aspect_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_aspect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_aspect_id_seq OWNER TO app_digipal;

--
-- Name: digipal_aspect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_aspect_id_seq OWNED BY digipal_aspect.id;


--
-- Name: digipal_authenticitycategory; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_authenticitycategory (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_authenticitycategory OWNER TO app_digipal;

--
-- Name: digipal_authenticitycategory_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_authenticitycategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_authenticitycategory_id_seq OWNER TO app_digipal;

--
-- Name: digipal_authenticitycategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_authenticitycategory_id_seq OWNED BY digipal_authenticitycategory.id;


--
-- Name: digipal_carouselitem; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_carouselitem (
    id integer NOT NULL,
    link character varying(200),
    image character varying(200),
    image_alt character varying(300),
    image_title character varying(300),
    sort_order integer NOT NULL,
    title character varying(300) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    image_file character varying(100)
);


ALTER TABLE digipal_carouselitem OWNER TO app_digipal;

--
-- Name: digipal_carouselitem_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_carouselitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_carouselitem_id_seq OWNER TO app_digipal;

--
-- Name: digipal_carouselitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_carouselitem_id_seq OWNED BY digipal_carouselitem.id;


--
-- Name: digipal_cataloguenumber; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_cataloguenumber (
    id integer NOT NULL,
    historical_item_id integer,
    source_id integer NOT NULL,
    number character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    text_id integer,
    url character varying(200),
    number_slug character varying(100)
);


ALTER TABLE digipal_cataloguenumber OWNER TO app_digipal;

--
-- Name: digipal_cataloguenumber_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_cataloguenumber_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_cataloguenumber_id_seq OWNER TO app_digipal;

--
-- Name: digipal_cataloguenumber_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_cataloguenumber_id_seq OWNED BY digipal_cataloguenumber.id;


--
-- Name: digipal_category; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_category (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    sort_order integer,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    CONSTRAINT digipal_category_sort_order_check CHECK ((sort_order >= 0))
);


ALTER TABLE digipal_category OWNER TO app_digipal;

--
-- Name: digipal_category_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_category_id_seq OWNER TO app_digipal;

--
-- Name: digipal_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_category_id_seq OWNED BY digipal_category.id;


--
-- Name: digipal_character; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_character (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    unicode_point character varying(32),
    ontograph_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    form_id integer NOT NULL
);


ALTER TABLE digipal_character OWNER TO app_digipal;

--
-- Name: digipal_character_components; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_character_components (
    id integer NOT NULL,
    character_id integer NOT NULL,
    component_id integer NOT NULL
);


ALTER TABLE digipal_character_components OWNER TO app_digipal;

--
-- Name: digipal_character_components_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_character_components_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_character_components_id_seq OWNER TO app_digipal;

--
-- Name: digipal_character_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_character_components_id_seq OWNED BY digipal_character_components.id;


--
-- Name: digipal_character_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_character_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_character_id_seq OWNER TO app_digipal;

--
-- Name: digipal_character_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_character_id_seq OWNED BY digipal_character.id;


--
-- Name: digipal_characterform; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_characterform (
    id integer NOT NULL,
    name character varying(128) NOT NULL
);


ALTER TABLE digipal_characterform OWNER TO app_digipal;

--
-- Name: digipal_characterform_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_characterform_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_characterform_id_seq OWNER TO app_digipal;

--
-- Name: digipal_characterform_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_characterform_id_seq OWNED BY digipal_characterform.id;


--
-- Name: digipal_collation; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_collation (
    id integer NOT NULL,
    historical_item_id integer NOT NULL,
    fragment boolean,
    leaves integer,
    front_flyleaves integer,
    back_flyleaves integer,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_collation OWNER TO app_digipal;

--
-- Name: digipal_collation_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_collation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_collation_id_seq OWNER TO app_digipal;

--
-- Name: digipal_collation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_collation_id_seq OWNED BY digipal_collation.id;


--
-- Name: digipal_component; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_component (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_component OWNER TO app_digipal;

--
-- Name: digipal_component_features; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_component_features (
    id integer NOT NULL,
    component_id integer NOT NULL,
    feature_id integer NOT NULL,
    set_by_default boolean NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_component_features OWNER TO app_digipal;

--
-- Name: digipal_component_features_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_component_features_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_component_features_id_seq OWNER TO app_digipal;

--
-- Name: digipal_component_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_component_features_id_seq OWNED BY digipal_component_features.id;


--
-- Name: digipal_component_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_component_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_component_id_seq OWNER TO app_digipal;

--
-- Name: digipal_component_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_component_id_seq OWNED BY digipal_component.id;


--
-- Name: digipal_county; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_county (
    id integer NOT NULL,
    legacy_id integer,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_county OWNER TO app_digipal;

--
-- Name: digipal_county_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_county_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_county_id_seq OWNER TO app_digipal;

--
-- Name: digipal_county_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_county_id_seq OWNED BY digipal_county.id;


--
-- Name: digipal_currentitem; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_currentitem (
    id integer NOT NULL,
    legacy_id integer,
    repository_id integer NOT NULL,
    shelfmark character varying(128) NOT NULL,
    description text,
    display_label character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_currentitem OWNER TO app_digipal;

--
-- Name: digipal_currentitem_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_currentitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_currentitem_id_seq OWNER TO app_digipal;

--
-- Name: digipal_currentitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_currentitem_id_seq OWNED BY digipal_currentitem.id;


--
-- Name: digipal_currentitem_owners; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_currentitem_owners (
    id integer NOT NULL,
    currentitem_id integer NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE digipal_currentitem_owners OWNER TO app_digipal;

--
-- Name: digipal_currentitem_owners_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_currentitem_owners_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_currentitem_owners_id_seq OWNER TO app_digipal;

--
-- Name: digipal_currentitem_owners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_currentitem_owners_id_seq OWNED BY digipal_currentitem_owners.id;


--
-- Name: digipal_date; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_date (
    id integer NOT NULL,
    legacy_id integer,
    date character varying(128) NOT NULL,
    sort_order integer,
    weight double precision NOT NULL,
    band integer,
    additional_band integer,
    post_conquest boolean,
    s_xi boolean,
    min_weight double precision,
    max_weight double precision,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    legacy_reference character varying(128),
    evidence character varying(255)
);


ALTER TABLE digipal_date OWNER TO app_digipal;

--
-- Name: digipal_date_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_date_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_date_id_seq OWNER TO app_digipal;

--
-- Name: digipal_date_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_date_id_seq OWNED BY digipal_date.id;


--
-- Name: digipal_dateevidence; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_dateevidence (
    id integer NOT NULL,
    legacy_id integer,
    hand_id integer,
    date_id integer,
    date_description character varying(128),
    reference_id integer,
    evidence text,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    historical_item_id integer,
    is_firm_date boolean NOT NULL
);


ALTER TABLE digipal_dateevidence OWNER TO app_digipal;

--
-- Name: digipal_dateevidence_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_dateevidence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_dateevidence_id_seq OWNER TO app_digipal;

--
-- Name: digipal_dateevidence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_dateevidence_id_seq OWNED BY digipal_dateevidence.id;


--
-- Name: digipal_decoration; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_decoration (
    id integer NOT NULL,
    historical_item_id integer NOT NULL,
    illustrated boolean,
    decorated boolean,
    illuminated boolean,
    num_colours integer,
    colours character varying(256),
    num_inks integer,
    inks character varying(256),
    style character varying(256),
    description text,
    catalogue_references character varying(256),
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_decoration OWNER TO app_digipal;

--
-- Name: digipal_decoration_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_decoration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_decoration_id_seq OWNER TO app_digipal;

--
-- Name: digipal_decoration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_decoration_id_seq OWNED BY digipal_decoration.id;


--
-- Name: digipal_description; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_description (
    id integer NOT NULL,
    historical_item_id integer,
    source_id integer NOT NULL,
    description text,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    text_id integer,
    comments text,
    summary character varying(256)
);


ALTER TABLE digipal_description OWNER TO app_digipal;

--
-- Name: digipal_description_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_description_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_description_id_seq OWNER TO app_digipal;

--
-- Name: digipal_description_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_description_id_seq OWNED BY digipal_description.id;


--
-- Name: digipal_feature; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_feature (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_feature OWNER TO app_digipal;

--
-- Name: digipal_feature_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_feature_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_feature_id_seq OWNER TO app_digipal;

--
-- Name: digipal_feature_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_feature_id_seq OWNED BY digipal_feature.id;


--
-- Name: digipal_format; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_format (
    id integer NOT NULL,
    legacy_id integer,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_format OWNER TO app_digipal;

--
-- Name: digipal_format_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_format_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_format_id_seq OWNER TO app_digipal;

--
-- Name: digipal_format_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_format_id_seq OWNED BY digipal_format.id;


--
-- Name: digipal_graph; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_graph (
    id integer NOT NULL,
    idiograph_id integer NOT NULL,
    hand_id integer NOT NULL,
    display_label character varying(256) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    group_id integer
);


ALTER TABLE digipal_graph OWNER TO app_digipal;

--
-- Name: digipal_graph_aspects; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_graph_aspects (
    id integer NOT NULL,
    graph_id integer NOT NULL,
    aspect_id integer NOT NULL
);


ALTER TABLE digipal_graph_aspects OWNER TO app_digipal;

--
-- Name: digipal_graph_aspects_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_graph_aspects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_graph_aspects_id_seq OWNER TO app_digipal;

--
-- Name: digipal_graph_aspects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_graph_aspects_id_seq OWNED BY digipal_graph_aspects.id;


--
-- Name: digipal_graph_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_graph_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_graph_id_seq OWNER TO app_digipal;

--
-- Name: digipal_graph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_graph_id_seq OWNED BY digipal_graph.id;


--
-- Name: digipal_graphcomponent; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_graphcomponent (
    id integer NOT NULL,
    graph_id integer NOT NULL,
    component_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_graphcomponent OWNER TO app_digipal;

--
-- Name: digipal_graphcomponent_features; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_graphcomponent_features (
    id integer NOT NULL,
    graphcomponent_id integer NOT NULL,
    feature_id integer NOT NULL
);


ALTER TABLE digipal_graphcomponent_features OWNER TO app_digipal;

--
-- Name: digipal_graphcomponent_features_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_graphcomponent_features_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_graphcomponent_features_id_seq OWNER TO app_digipal;

--
-- Name: digipal_graphcomponent_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_graphcomponent_features_id_seq OWNED BY digipal_graphcomponent_features.id;


--
-- Name: digipal_graphcomponent_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_graphcomponent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_graphcomponent_id_seq OWNER TO app_digipal;

--
-- Name: digipal_graphcomponent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_graphcomponent_id_seq OWNED BY digipal_graphcomponent.id;


--
-- Name: digipal_hair; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_hair (
    id integer NOT NULL,
    legacy_id integer,
    label character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_hair OWNER TO app_digipal;

--
-- Name: digipal_hair_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_hair_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_hair_id_seq OWNER TO app_digipal;

--
-- Name: digipal_hair_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_hair_id_seq OWNED BY digipal_hair.id;


--
-- Name: digipal_hand; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_hand (
    id integer NOT NULL,
    legacy_id integer,
    num integer NOT NULL,
    item_part_id integer NOT NULL,
    script_id integer,
    scribe_id integer,
    assigned_date_id integer,
    assigned_place_id integer,
    scragg character varying(6),
    em_title character varying(256),
    label text,
    display_note text,
    internal_note text,
    appearance_id integer,
    relevant boolean,
    latin_only boolean,
    gloss_only boolean,
    membra_disjecta boolean,
    num_glosses integer,
    num_glossing_hands integer,
    glossed_text_id integer,
    scribble_only boolean,
    imitative boolean,
    latin_style_id integer,
    comments text,
    display_label character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    locus character varying(300),
    surrogates character varying(50),
    selected_locus character varying(100),
    stewart_record_id integer,
    ker character varying(10)
);


ALTER TABLE digipal_hand OWNER TO app_digipal;

--
-- Name: digipal_hand_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_hand_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_hand_id_seq OWNER TO app_digipal;

--
-- Name: digipal_hand_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_hand_id_seq OWNED BY digipal_hand.id;


--
-- Name: digipal_hand_images; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_hand_images (
    id integer NOT NULL,
    hand_id integer NOT NULL,
    image_id integer NOT NULL
);


ALTER TABLE digipal_hand_images OWNER TO app_digipal;

--
-- Name: digipal_hand_images_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_hand_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_hand_images_id_seq OWNER TO app_digipal;

--
-- Name: digipal_hand_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_hand_images_id_seq OWNED BY digipal_hand_images.id;


--
-- Name: digipal_handdescription; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_handdescription (
    id integer NOT NULL,
    hand_id integer,
    source_id integer,
    description text NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    label character varying(64)
);


ALTER TABLE digipal_handdescription OWNER TO app_digipal;

--
-- Name: digipal_handdescription_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_handdescription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_handdescription_id_seq OWNER TO app_digipal;

--
-- Name: digipal_handdescription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_handdescription_id_seq OWNED BY digipal_handdescription.id;


--
-- Name: digipal_historicalitem; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_historicalitem (
    id integer NOT NULL,
    legacy_id integer,
    historical_item_type_id integer NOT NULL,
    historical_item_format_id integer,
    date character varying(128),
    name character varying(256),
    hair_id integer,
    language_id integer,
    url character varying(200),
    vernacular boolean,
    neumed boolean,
    catalogue_number character varying(128) NOT NULL,
    display_label character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    legacy_reference character varying(128),
    date_sort character varying(128)
);


ALTER TABLE digipal_historicalitem OWNER TO app_digipal;

--
-- Name: digipal_historicalitem_categories; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_historicalitem_categories (
    id integer NOT NULL,
    historicalitem_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE digipal_historicalitem_categories OWNER TO app_digipal;

--
-- Name: digipal_historicalitem_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_historicalitem_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_historicalitem_categories_id_seq OWNER TO app_digipal;

--
-- Name: digipal_historicalitem_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_historicalitem_categories_id_seq OWNED BY digipal_historicalitem_categories.id;


--
-- Name: digipal_historicalitem_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_historicalitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_historicalitem_id_seq OWNER TO app_digipal;

--
-- Name: digipal_historicalitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_historicalitem_id_seq OWNED BY digipal_historicalitem.id;


--
-- Name: digipal_historicalitem_owners; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_historicalitem_owners (
    id integer NOT NULL,
    historicalitem_id integer NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE digipal_historicalitem_owners OWNER TO app_digipal;

--
-- Name: digipal_historicalitem_owners_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_historicalitem_owners_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_historicalitem_owners_id_seq OWNER TO app_digipal;

--
-- Name: digipal_historicalitem_owners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_historicalitem_owners_id_seq OWNED BY digipal_historicalitem_owners.id;


--
-- Name: digipal_historicalitemdate; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_historicalitemdate (
    id integer NOT NULL,
    legacy_id integer,
    historical_item_id integer NOT NULL,
    date_id integer NOT NULL,
    evidence text NOT NULL,
    vernacular boolean,
    addition boolean,
    dubitable boolean,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_historicalitemdate OWNER TO app_digipal;

--
-- Name: digipal_historicalitemdate_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_historicalitemdate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_historicalitemdate_id_seq OWNER TO app_digipal;

--
-- Name: digipal_historicalitemdate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_historicalitemdate_id_seq OWNED BY digipal_historicalitemdate.id;


--
-- Name: digipal_historicalitemtype; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_historicalitemtype (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_historicalitemtype OWNER TO app_digipal;

--
-- Name: digipal_historicalitemtype_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_historicalitemtype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_historicalitemtype_id_seq OWNER TO app_digipal;

--
-- Name: digipal_historicalitemtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_historicalitemtype_id_seq OWNED BY digipal_historicalitemtype.id;


--
-- Name: digipal_idiograph; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_idiograph (
    id integer NOT NULL,
    allograph_id integer NOT NULL,
    scribe_id integer,
    display_label character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_idiograph OWNER TO app_digipal;

--
-- Name: digipal_idiograph_aspects; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_idiograph_aspects (
    id integer NOT NULL,
    idiograph_id integer NOT NULL,
    aspect_id integer NOT NULL
);


ALTER TABLE digipal_idiograph_aspects OWNER TO app_digipal;

--
-- Name: digipal_idiograph_aspects_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_idiograph_aspects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_idiograph_aspects_id_seq OWNER TO app_digipal;

--
-- Name: digipal_idiograph_aspects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_idiograph_aspects_id_seq OWNED BY digipal_idiograph_aspects.id;


--
-- Name: digipal_idiograph_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_idiograph_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_idiograph_id_seq OWNER TO app_digipal;

--
-- Name: digipal_idiograph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_idiograph_id_seq OWNED BY digipal_idiograph.id;


--
-- Name: digipal_idiographcomponent; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_idiographcomponent (
    id integer NOT NULL,
    idiograph_id integer NOT NULL,
    component_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_idiographcomponent OWNER TO app_digipal;

--
-- Name: digipal_idiographcomponent_features; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_idiographcomponent_features (
    id integer NOT NULL,
    idiographcomponent_id integer NOT NULL,
    feature_id integer NOT NULL
);


ALTER TABLE digipal_idiographcomponent_features OWNER TO app_digipal;

--
-- Name: digipal_idiographcomponent_features_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_idiographcomponent_features_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_idiographcomponent_features_id_seq OWNER TO app_digipal;

--
-- Name: digipal_idiographcomponent_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_idiographcomponent_features_id_seq OWNED BY digipal_idiographcomponent_features.id;


--
-- Name: digipal_idiographcomponent_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_idiographcomponent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_idiographcomponent_id_seq OWNER TO app_digipal;

--
-- Name: digipal_idiographcomponent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_idiographcomponent_id_seq OWNED BY digipal_idiographcomponent.id;


--
-- Name: digipal_image; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_image (
    id integer NOT NULL,
    item_part_id integer,
    locus character varying(64) NOT NULL,
    caption character varying(256),
    image character varying(100),
    display_label character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    folio_side character varying(4),
    folio_number character varying(8),
    iipimage character varying(200),
    media_permission_id integer,
    transcription text,
    internal_notes text,
    custom_label character varying(128),
    annotation_status_id integer,
    width integer NOT NULL,
    height integer NOT NULL,
    size integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    quire character varying(10),
    page_boundaries character varying(100)
);


ALTER TABLE digipal_image OWNER TO app_digipal;

--
-- Name: digipal_image_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_image_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_image_id_seq OWNER TO app_digipal;

--
-- Name: digipal_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_image_id_seq OWNED BY digipal_image.id;


--
-- Name: digipal_imageannotationstatus; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_imageannotationstatus (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_imageannotationstatus OWNER TO app_digipal;

--
-- Name: digipal_imageannotationstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_imageannotationstatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_imageannotationstatus_id_seq OWNER TO app_digipal;

--
-- Name: digipal_imageannotationstatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_imageannotationstatus_id_seq OWNED BY digipal_imageannotationstatus.id;


--
-- Name: digipal_institution; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_institution (
    id integer NOT NULL,
    legacy_id integer,
    institution_type_id integer NOT NULL,
    name character varying(256) NOT NULL,
    founder_id integer,
    reformer_id integer,
    patron_id integer,
    place_id integer NOT NULL,
    foundation character varying(128),
    refoundation character varying(128),
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_institution OWNER TO app_digipal;

--
-- Name: digipal_institution_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_institution_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_institution_id_seq OWNER TO app_digipal;

--
-- Name: digipal_institution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_institution_id_seq OWNED BY digipal_institution.id;


--
-- Name: digipal_institutiontype; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_institutiontype (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_institutiontype OWNER TO app_digipal;

--
-- Name: digipal_institutiontype_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_institutiontype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_institutiontype_id_seq OWNER TO app_digipal;

--
-- Name: digipal_institutiontype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_institutiontype_id_seq OWNED BY digipal_institutiontype.id;


--
-- Name: digipal_itemorigin; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_itemorigin (
    id integer NOT NULL,
    legacy_id integer,
    historical_item_id integer NOT NULL,
    evidence text,
    dubitable boolean,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    place_id integer,
    institution_id integer
);


ALTER TABLE digipal_itemorigin OWNER TO app_digipal;

--
-- Name: digipal_itemorigin_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_itemorigin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_itemorigin_id_seq OWNER TO app_digipal;

--
-- Name: digipal_itemorigin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_itemorigin_id_seq OWNED BY digipal_itemorigin.id;


--
-- Name: digipal_itempart; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_itempart (
    id integer NOT NULL,
    current_item_id integer,
    locus character varying(64),
    display_label character varying(300) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    pagination boolean NOT NULL,
    group_id integer,
    type_id integer,
    group_locus character varying(64),
    notes text,
    keywords_string character varying(500) NOT NULL
);


ALTER TABLE digipal_itempart OWNER TO app_digipal;

--
-- Name: digipal_itempart_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_itempart_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_itempart_id_seq OWNER TO app_digipal;

--
-- Name: digipal_itempart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_itempart_id_seq OWNED BY digipal_itempart.id;


--
-- Name: digipal_itempart_owners; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_itempart_owners (
    id integer NOT NULL,
    itempart_id integer NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE digipal_itempart_owners OWNER TO app_digipal;

--
-- Name: digipal_itempart_owners_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_itempart_owners_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_itempart_owners_id_seq OWNER TO app_digipal;

--
-- Name: digipal_itempart_owners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_itempart_owners_id_seq OWNED BY digipal_itempart_owners.id;


--
-- Name: digipal_itempartauthenticity; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_itempartauthenticity (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    item_part_id integer NOT NULL,
    category_id integer NOT NULL,
    source_id integer,
    note text
);


ALTER TABLE digipal_itempartauthenticity OWNER TO app_digipal;

--
-- Name: digipal_itempartauthenticity_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_itempartauthenticity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_itempartauthenticity_id_seq OWNER TO app_digipal;

--
-- Name: digipal_itempartauthenticity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_itempartauthenticity_id_seq OWNED BY digipal_itempartauthenticity.id;


--
-- Name: digipal_itempartitem; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_itempartitem (
    id integer NOT NULL,
    historical_item_id integer NOT NULL,
    item_part_id integer NOT NULL,
    locus character varying(64) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_itempartitem OWNER TO app_digipal;

--
-- Name: digipal_itempartitem_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_itempartitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_itempartitem_id_seq OWNER TO app_digipal;

--
-- Name: digipal_itempartitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_itempartitem_id_seq OWNED BY digipal_itempartitem.id;


--
-- Name: digipal_itemparttype; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_itemparttype (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_itemparttype OWNER TO app_digipal;

--
-- Name: digipal_itemparttype_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_itemparttype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_itemparttype_id_seq OWNER TO app_digipal;

--
-- Name: digipal_itemparttype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_itemparttype_id_seq OWNED BY digipal_itemparttype.id;


--
-- Name: digipal_keyval; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_keyval (
    id integer NOT NULL,
    key character varying(300) NOT NULL,
    val text,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_keyval OWNER TO app_digipal;

--
-- Name: digipal_keyval_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_keyval_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_keyval_id_seq OWNER TO app_digipal;

--
-- Name: digipal_keyval_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_keyval_id_seq OWNED BY digipal_keyval.id;


--
-- Name: digipal_language; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_language (
    id integer NOT NULL,
    legacy_id integer,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_language OWNER TO app_digipal;

--
-- Name: digipal_language_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_language_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_language_id_seq OWNER TO app_digipal;

--
-- Name: digipal_language_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_language_id_seq OWNED BY digipal_language.id;


--
-- Name: digipal_latinstyle; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_latinstyle (
    id integer NOT NULL,
    legacy_id integer,
    style character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_latinstyle OWNER TO app_digipal;

--
-- Name: digipal_latinstyle_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_latinstyle_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_latinstyle_id_seq OWNER TO app_digipal;

--
-- Name: digipal_latinstyle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_latinstyle_id_seq OWNED BY digipal_latinstyle.id;


--
-- Name: digipal_layout; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_layout (
    id integer NOT NULL,
    historical_item_id integer,
    page_height integer,
    page_width integer,
    frame_height integer,
    frame_width integer,
    tramline_width integer,
    lines integer,
    columns integer,
    on_top_line boolean,
    multiple_sheet_rulling boolean,
    bilinear_ruling boolean,
    comments text,
    hair_arrangement_id integer,
    insular_pricking boolean,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    item_part_id integer
);


ALTER TABLE digipal_layout OWNER TO app_digipal;

--
-- Name: digipal_layout_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_layout_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_layout_id_seq OWNER TO app_digipal;

--
-- Name: digipal_layout_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_layout_id_seq OWNED BY digipal_layout.id;


--
-- Name: digipal_measurement; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_measurement (
    id integer NOT NULL,
    legacy_id integer,
    label character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_measurement OWNER TO app_digipal;

--
-- Name: digipal_measurement_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_measurement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_measurement_id_seq OWNER TO app_digipal;

--
-- Name: digipal_measurement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_measurement_id_seq OWNED BY digipal_measurement.id;


--
-- Name: digipal_mediapermission; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_mediapermission (
    id integer NOT NULL,
    label character varying(64) NOT NULL,
    display_message text NOT NULL,
    permission integer NOT NULL
);


ALTER TABLE digipal_mediapermission OWNER TO app_digipal;

--
-- Name: digipal_mediapermission_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_mediapermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_mediapermission_id_seq OWNER TO app_digipal;

--
-- Name: digipal_mediapermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_mediapermission_id_seq OWNED BY digipal_mediapermission.id;


--
-- Name: digipal_ontograph; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_ontograph (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    ontograph_type_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    nesting_level integer NOT NULL,
    sort_order integer NOT NULL
);


ALTER TABLE digipal_ontograph OWNER TO app_digipal;

--
-- Name: digipal_ontograph_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_ontograph_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_ontograph_id_seq OWNER TO app_digipal;

--
-- Name: digipal_ontograph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_ontograph_id_seq OWNED BY digipal_ontograph.id;


--
-- Name: digipal_ontographtype; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_ontographtype (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_ontographtype OWNER TO app_digipal;

--
-- Name: digipal_ontographtype_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_ontographtype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_ontographtype_id_seq OWNER TO app_digipal;

--
-- Name: digipal_ontographtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_ontographtype_id_seq OWNED BY digipal_ontographtype.id;


--
-- Name: digipal_owner; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_owner (
    id integer NOT NULL,
    legacy_id integer,
    date character varying(128) NOT NULL,
    evidence text NOT NULL,
    rebound boolean,
    annotated boolean,
    dubitable boolean,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    person_id integer,
    institution_id integer,
    repository_id integer,
    display_label character varying(250) NOT NULL
);


ALTER TABLE digipal_owner OWNER TO app_digipal;

--
-- Name: digipal_owner_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_owner_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_owner_id_seq OWNER TO app_digipal;

--
-- Name: digipal_owner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_owner_id_seq OWNED BY digipal_owner.id;


--
-- Name: digipal_ownertype; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_ownertype (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_ownertype OWNER TO app_digipal;

--
-- Name: digipal_ownertype_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_ownertype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_ownertype_id_seq OWNER TO app_digipal;

--
-- Name: digipal_ownertype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_ownertype_id_seq OWNED BY digipal_ownertype.id;


--
-- Name: digipal_person; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_person (
    id integer NOT NULL,
    legacy_id integer,
    name character varying(256) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_person OWNER TO app_digipal;

--
-- Name: digipal_person_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_person_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_person_id_seq OWNER TO app_digipal;

--
-- Name: digipal_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_person_id_seq OWNED BY digipal_person.id;


--
-- Name: digipal_place; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_place (
    id integer NOT NULL,
    legacy_id integer,
    name character varying(256) NOT NULL,
    eastings double precision,
    northings double precision,
    region_id integer,
    current_county_id integer,
    historical_county_id integer,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    type_id integer,
    other_names character varying(256)
);


ALTER TABLE digipal_place OWNER TO app_digipal;

--
-- Name: digipal_place_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_place_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_place_id_seq OWNER TO app_digipal;

--
-- Name: digipal_place_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_place_id_seq OWNED BY digipal_place.id;


--
-- Name: digipal_placeevidence; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_placeevidence (
    id integer NOT NULL,
    legacy_id integer,
    hand_id integer,
    place_id integer NOT NULL,
    place_description character varying(128),
    reference_id integer NOT NULL,
    evidence text NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    historical_item_id integer,
    written_as character varying(128)
);


ALTER TABLE digipal_placeevidence OWNER TO app_digipal;

--
-- Name: digipal_placeevidence_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_placeevidence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_placeevidence_id_seq OWNER TO app_digipal;

--
-- Name: digipal_placeevidence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_placeevidence_id_seq OWNED BY digipal_placeevidence.id;


--
-- Name: digipal_placetype; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_placetype (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_placetype OWNER TO app_digipal;

--
-- Name: digipal_placetype_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_placetype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_placetype_id_seq OWNER TO app_digipal;

--
-- Name: digipal_placetype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_placetype_id_seq OWNED BY digipal_placetype.id;


--
-- Name: digipal_proportion; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_proportion (
    id integer NOT NULL,
    legacy_id integer,
    hand_id integer NOT NULL,
    measurement_id integer NOT NULL,
    description text,
    cue_height double precision NOT NULL,
    value double precision NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_proportion OWNER TO app_digipal;

--
-- Name: digipal_proportion_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_proportion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_proportion_id_seq OWNER TO app_digipal;

--
-- Name: digipal_proportion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_proportion_id_seq OWNED BY digipal_proportion.id;


--
-- Name: digipal_reference; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_reference (
    id integer NOT NULL,
    legacy_id integer,
    name character varying(128) NOT NULL,
    name_index character varying(1),
    legacy_reference character varying(128),
    full_reference text NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_reference OWNER TO app_digipal;

--
-- Name: digipal_reference_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_reference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_reference_id_seq OWNER TO app_digipal;

--
-- Name: digipal_reference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_reference_id_seq OWNED BY digipal_reference.id;


--
-- Name: digipal_region; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_region (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_region OWNER TO app_digipal;

--
-- Name: digipal_region_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_region_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_region_id_seq OWNER TO app_digipal;

--
-- Name: digipal_region_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_region_id_seq OWNED BY digipal_region.id;


--
-- Name: digipal_repository; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_repository (
    id integer NOT NULL,
    legacy_id integer,
    name character varying(256) NOT NULL,
    short_name character varying(64),
    place_id integer NOT NULL,
    url character varying(200),
    comma boolean,
    british_isles boolean,
    digital_project boolean,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    copyright_notice text,
    media_permission_id integer,
    type_id integer,
    part_of_id integer
);


ALTER TABLE digipal_repository OWNER TO app_digipal;

--
-- Name: digipal_repository_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_repository_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_repository_id_seq OWNER TO app_digipal;

--
-- Name: digipal_repository_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_repository_id_seq OWNED BY digipal_repository.id;


--
-- Name: digipal_requestlog; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_requestlog (
    id integer NOT NULL,
    request character varying(300),
    created timestamp with time zone NOT NULL,
    result_count integer NOT NULL
);


ALTER TABLE digipal_requestlog OWNER TO app_digipal;

--
-- Name: digipal_requestlog_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_requestlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_requestlog_id_seq OWNER TO app_digipal;

--
-- Name: digipal_requestlog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_requestlog_id_seq OWNED BY digipal_requestlog.id;


--
-- Name: digipal_scribe; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_scribe (
    id integer NOT NULL,
    legacy_id integer,
    name character varying(128) NOT NULL,
    date character varying(128),
    scriptorium_id integer,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    legacy_reference character varying(128)
);


ALTER TABLE digipal_scribe OWNER TO app_digipal;

--
-- Name: digipal_scribe_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_scribe_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_scribe_id_seq OWNER TO app_digipal;

--
-- Name: digipal_scribe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_scribe_id_seq OWNED BY digipal_scribe.id;


--
-- Name: digipal_scribe_reference; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_scribe_reference (
    id integer NOT NULL,
    scribe_id integer NOT NULL,
    reference_id integer NOT NULL
);


ALTER TABLE digipal_scribe_reference OWNER TO app_digipal;

--
-- Name: digipal_scribe_reference_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_scribe_reference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_scribe_reference_id_seq OWNER TO app_digipal;

--
-- Name: digipal_scribe_reference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_scribe_reference_id_seq OWNED BY digipal_scribe_reference.id;


--
-- Name: digipal_script; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_script (
    id integer NOT NULL,
    legacy_id integer,
    name character varying(128) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_script OWNER TO app_digipal;

--
-- Name: digipal_script_allographs; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_script_allographs (
    id integer NOT NULL,
    script_id integer NOT NULL,
    allograph_id integer NOT NULL
);


ALTER TABLE digipal_script_allographs OWNER TO app_digipal;

--
-- Name: digipal_script_allographs_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_script_allographs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_script_allographs_id_seq OWNER TO app_digipal;

--
-- Name: digipal_script_allographs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_script_allographs_id_seq OWNED BY digipal_script_allographs.id;


--
-- Name: digipal_script_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_script_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_script_id_seq OWNER TO app_digipal;

--
-- Name: digipal_script_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_script_id_seq OWNED BY digipal_script.id;


--
-- Name: digipal_scriptcomponent; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_scriptcomponent (
    id integer NOT NULL,
    script_id integer NOT NULL,
    component_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_scriptcomponent OWNER TO app_digipal;

--
-- Name: digipal_scriptcomponent_features; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_scriptcomponent_features (
    id integer NOT NULL,
    scriptcomponent_id integer NOT NULL,
    feature_id integer NOT NULL
);


ALTER TABLE digipal_scriptcomponent_features OWNER TO app_digipal;

--
-- Name: digipal_scriptcomponent_features_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_scriptcomponent_features_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_scriptcomponent_features_id_seq OWNER TO app_digipal;

--
-- Name: digipal_scriptcomponent_features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_scriptcomponent_features_id_seq OWNED BY digipal_scriptcomponent_features.id;


--
-- Name: digipal_scriptcomponent_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_scriptcomponent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_scriptcomponent_id_seq OWNER TO app_digipal;

--
-- Name: digipal_scriptcomponent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_scriptcomponent_id_seq OWNED BY digipal_scriptcomponent.id;


--
-- Name: digipal_source; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_source (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    label character varying(30),
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    priority integer NOT NULL,
    label_styled character varying(30),
    label_slug character varying(30)
);


ALTER TABLE digipal_source OWNER TO app_digipal;

--
-- Name: digipal_source_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_source_id_seq OWNER TO app_digipal;

--
-- Name: digipal_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_source_id_seq OWNED BY digipal_source.id;


--
-- Name: digipal_status; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_status (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    "default" boolean NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_status OWNER TO app_digipal;

--
-- Name: digipal_status_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_status_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_status_id_seq OWNER TO app_digipal;

--
-- Name: digipal_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_status_id_seq OWNED BY digipal_status.id;


--
-- Name: digipal_stewartrecord; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_stewartrecord (
    id integer NOT NULL,
    scragg character varying(300),
    repository character varying(300),
    shelf_mark character varying(300),
    fols character varying(300),
    gneuss character varying(300),
    sp character varying(300),
    ker character varying(300),
    locus character varying(300),
    selected character varying(300),
    adate character varying(300),
    location character varying(300),
    surrogates character varying(300),
    contents character varying(500),
    notes character varying(600),
    em character varying(800),
    glosses character varying(300),
    minor character varying(300),
    charter character varying(300),
    cartulary character varying(300),
    eel character varying(1000),
    stokes_db character varying(300),
    ker_hand character varying(300),
    import_messages text,
    matched_hands character varying(1000)
);


ALTER TABLE digipal_stewartrecord OWNER TO app_digipal;

--
-- Name: digipal_stewartrecord_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_stewartrecord_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_stewartrecord_id_seq OWNER TO app_digipal;

--
-- Name: digipal_stewartrecord_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_stewartrecord_id_seq OWNED BY digipal_stewartrecord.id;


--
-- Name: digipal_text; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    legacy_id integer,
    date character varying(128),
    url character varying(200),
    date_sort character varying(128)
);


ALTER TABLE digipal_text OWNER TO app_digipal;

--
-- Name: digipal_text_categories; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_categories (
    id integer NOT NULL,
    text_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE digipal_text_categories OWNER TO app_digipal;

--
-- Name: digipal_text_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_categories_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_categories_id_seq OWNED BY digipal_text_categories.id;


--
-- Name: digipal_text_entryhand; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_entryhand (
    id integer NOT NULL,
    item_part_id integer NOT NULL,
    entry_number character varying(20) NOT NULL,
    hand_label character varying(20) NOT NULL,
    "order" integer NOT NULL,
    correction boolean NOT NULL,
    certainty double precision NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_text_entryhand OWNER TO app_digipal;

--
-- Name: digipal_text_entryhand_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_entryhand_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_entryhand_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_entryhand_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_entryhand_id_seq OWNED BY digipal_text_entryhand.id;


--
-- Name: digipal_text_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_id_seq OWNED BY digipal_text.id;


--
-- Name: digipal_text_languages; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_languages (
    id integer NOT NULL,
    text_id integer NOT NULL,
    language_id integer NOT NULL
);


ALTER TABLE digipal_text_languages OWNER TO app_digipal;

--
-- Name: digipal_text_languages_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_languages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_languages_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_languages_id_seq OWNED BY digipal_text_languages.id;


--
-- Name: digipal_text_textannotation; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_textannotation (
    id integer NOT NULL,
    annotation_id integer NOT NULL,
    elementid character varying(255) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_text_textannotation OWNER TO app_digipal;

--
-- Name: digipal_text_textannotation_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_textannotation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_textannotation_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_textannotation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_textannotation_id_seq OWNED BY digipal_text_textannotation.id;


--
-- Name: digipal_text_textcontent; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_textcontent (
    id integer NOT NULL,
    type_id integer NOT NULL,
    item_part_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    text_id integer
);


ALTER TABLE digipal_text_textcontent OWNER TO app_digipal;

--
-- Name: digipal_text_textcontent_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_textcontent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_textcontent_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_textcontent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_textcontent_id_seq OWNED BY digipal_text_textcontent.id;


--
-- Name: digipal_text_textcontent_languages; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_textcontent_languages (
    id integer NOT NULL,
    textcontent_id integer NOT NULL,
    language_id integer NOT NULL
);


ALTER TABLE digipal_text_textcontent_languages OWNER TO app_digipal;

--
-- Name: digipal_text_textcontent_languages_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_textcontent_languages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_textcontent_languages_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_textcontent_languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_textcontent_languages_id_seq OWNED BY digipal_text_textcontent_languages.id;


--
-- Name: digipal_text_textcontenttype; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_textcontenttype (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    slug character varying(100) NOT NULL
);


ALTER TABLE digipal_text_textcontenttype OWNER TO app_digipal;

--
-- Name: digipal_text_textcontenttype_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_textcontenttype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_textcontenttype_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_textcontenttype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_textcontenttype_id_seq OWNED BY digipal_text_textcontenttype.id;


--
-- Name: digipal_text_textcontentxml; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_textcontentxml (
    id integer NOT NULL,
    status_id integer NOT NULL,
    text_content_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    content text,
    last_image_id integer
);


ALTER TABLE digipal_text_textcontentxml OWNER TO app_digipal;

--
-- Name: digipal_text_textcontentxml_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_textcontentxml_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_textcontentxml_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_textcontentxml_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_textcontentxml_id_seq OWNED BY digipal_text_textcontentxml.id;


--
-- Name: digipal_text_textcontentxmlcopy; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_textcontentxmlcopy (
    id integer NOT NULL,
    source_id integer,
    content bytea,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    ahash character varying(100)
);


ALTER TABLE digipal_text_textcontentxmlcopy OWNER TO app_digipal;

--
-- Name: digipal_text_textcontentxmlcopy_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_textcontentxmlcopy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_textcontentxmlcopy_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_textcontentxmlcopy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_textcontentxmlcopy_id_seq OWNED BY digipal_text_textcontentxmlcopy.id;


--
-- Name: digipal_text_textcontentxmlstatus; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_textcontentxmlstatus (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    slug character varying(100) NOT NULL,
    sort_order integer NOT NULL
);


ALTER TABLE digipal_text_textcontentxmlstatus OWNER TO app_digipal;

--
-- Name: digipal_text_textcontentxmlstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_textcontentxmlstatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_textcontentxmlstatus_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_textcontentxmlstatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_textcontentxmlstatus_id_seq OWNED BY digipal_text_textcontentxmlstatus.id;


--
-- Name: digipal_text_textpattern; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_text_textpattern (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    key character varying(100) NOT NULL,
    pattern character varying(1000),
    "order" integer NOT NULL,
    description text,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE digipal_text_textpattern OWNER TO app_digipal;

--
-- Name: digipal_text_textpattern_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_text_textpattern_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_text_textpattern_id_seq OWNER TO app_digipal;

--
-- Name: digipal_text_textpattern_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_text_textpattern_id_seq OWNED BY digipal_text_textpattern.id;


--
-- Name: digipal_textitempart; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE digipal_textitempart (
    id integer NOT NULL,
    locus character varying(20),
    item_part_id integer NOT NULL,
    text_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    date character varying(128)
);


ALTER TABLE digipal_textitempart OWNER TO app_digipal;

--
-- Name: digipal_textitempart_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE digipal_textitempart_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE digipal_textitempart_id_seq OWNER TO app_digipal;

--
-- Name: digipal_textitempart_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE digipal_textitempart_id_seq OWNED BY digipal_textitempart.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO app_digipal;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO app_digipal;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_comment_flags; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE django_comment_flags (
    id integer NOT NULL,
    user_id integer NOT NULL,
    comment_id integer NOT NULL,
    flag character varying(30) NOT NULL,
    flag_date timestamp with time zone NOT NULL
);


ALTER TABLE django_comment_flags OWNER TO app_digipal;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE django_comment_flags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_comment_flags_id_seq OWNER TO app_digipal;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE django_comment_flags_id_seq OWNED BY django_comment_flags.id;


--
-- Name: django_comments; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE django_comments (
    id integer NOT NULL,
    content_type_id integer NOT NULL,
    object_pk text NOT NULL,
    site_id integer NOT NULL,
    user_id integer,
    user_name character varying(50) NOT NULL,
    user_email character varying(254) NOT NULL,
    user_url character varying(200) NOT NULL,
    comment text NOT NULL,
    submit_date timestamp with time zone NOT NULL,
    ip_address inet,
    is_public boolean NOT NULL,
    is_removed boolean NOT NULL
);


ALTER TABLE django_comments OWNER TO app_digipal;

--
-- Name: django_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE django_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_comments_id_seq OWNER TO app_digipal;

--
-- Name: django_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE django_comments_id_seq OWNED BY django_comments.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO app_digipal;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO app_digipal;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO app_digipal;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO app_digipal;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_redirect; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE django_redirect (
    id integer NOT NULL,
    site_id integer NOT NULL,
    old_path character varying(200) NOT NULL,
    new_path character varying(200) NOT NULL
);


ALTER TABLE django_redirect OWNER TO app_digipal;

--
-- Name: django_redirect_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE django_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_redirect_id_seq OWNER TO app_digipal;

--
-- Name: django_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE django_redirect_id_seq OWNED BY django_redirect.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO app_digipal;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE django_site OWNER TO app_digipal;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_site_id_seq OWNER TO app_digipal;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: forms_field; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE forms_field (
    _order integer,
    form_id integer NOT NULL,
    "default" character varying(2000) NOT NULL,
    required boolean NOT NULL,
    label character varying(200) NOT NULL,
    visible boolean NOT NULL,
    help_text character varying(100) NOT NULL,
    choices character varying(1000) NOT NULL,
    id integer NOT NULL,
    placeholder_text character varying(100) NOT NULL,
    field_type integer NOT NULL
);


ALTER TABLE forms_field OWNER TO app_digipal;

--
-- Name: forms_field_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE forms_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE forms_field_id_seq OWNER TO app_digipal;

--
-- Name: forms_field_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE forms_field_id_seq OWNED BY forms_field.id;


--
-- Name: forms_fieldentry; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE forms_fieldentry (
    entry_id integer NOT NULL,
    field_id integer NOT NULL,
    id integer NOT NULL,
    value character varying(2000)
);


ALTER TABLE forms_fieldentry OWNER TO app_digipal;

--
-- Name: forms_fieldentry_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE forms_fieldentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE forms_fieldentry_id_seq OWNER TO app_digipal;

--
-- Name: forms_fieldentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE forms_fieldentry_id_seq OWNED BY forms_fieldentry.id;


--
-- Name: forms_form; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE forms_form (
    email_message text NOT NULL,
    page_ptr_id integer NOT NULL,
    email_copies character varying(200) NOT NULL,
    button_text character varying(50) NOT NULL,
    response text NOT NULL,
    content text NOT NULL,
    send_email boolean NOT NULL,
    email_subject character varying(200) NOT NULL,
    email_from character varying(254) NOT NULL
);


ALTER TABLE forms_form OWNER TO app_digipal;

--
-- Name: forms_formentry; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE forms_formentry (
    entry_time timestamp with time zone NOT NULL,
    id integer NOT NULL,
    form_id integer NOT NULL
);


ALTER TABLE forms_formentry OWNER TO app_digipal;

--
-- Name: forms_formentry_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE forms_formentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE forms_formentry_id_seq OWNER TO app_digipal;

--
-- Name: forms_formentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE forms_formentry_id_seq OWNED BY forms_formentry.id;


--
-- Name: galleries_gallery; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE galleries_gallery (
    page_ptr_id integer NOT NULL,
    content text NOT NULL,
    zip_import character varying(100) NOT NULL
);


ALTER TABLE galleries_gallery OWNER TO app_digipal;

--
-- Name: galleries_galleryimage; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE galleries_galleryimage (
    id integer NOT NULL,
    _order integer,
    gallery_id integer NOT NULL,
    file character varying(200) NOT NULL,
    description character varying(1000) NOT NULL
);


ALTER TABLE galleries_galleryimage OWNER TO app_digipal;

--
-- Name: galleries_galleryimage_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE galleries_galleryimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE galleries_galleryimage_id_seq OWNER TO app_digipal;

--
-- Name: galleries_galleryimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE galleries_galleryimage_id_seq OWNED BY galleries_galleryimage.id;


--
-- Name: generic_assignedkeyword; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE generic_assignedkeyword (
    content_type_id integer NOT NULL,
    id integer NOT NULL,
    keyword_id integer NOT NULL,
    object_pk integer,
    _order integer
);


ALTER TABLE generic_assignedkeyword OWNER TO app_digipal;

--
-- Name: generic_assignedkeyword_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE generic_assignedkeyword_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE generic_assignedkeyword_id_seq OWNER TO app_digipal;

--
-- Name: generic_assignedkeyword_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE generic_assignedkeyword_id_seq OWNED BY generic_assignedkeyword.id;


--
-- Name: generic_keyword; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE generic_keyword (
    slug character varying(2000),
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE generic_keyword OWNER TO app_digipal;

--
-- Name: generic_keyword_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE generic_keyword_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE generic_keyword_id_seq OWNER TO app_digipal;

--
-- Name: generic_keyword_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE generic_keyword_id_seq OWNED BY generic_keyword.id;


--
-- Name: generic_rating; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE generic_rating (
    content_type_id integer NOT NULL,
    id integer NOT NULL,
    value integer NOT NULL,
    object_pk integer,
    rating_date timestamp with time zone,
    user_id integer
);


ALTER TABLE generic_rating OWNER TO app_digipal;

--
-- Name: generic_rating_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE generic_rating_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE generic_rating_id_seq OWNER TO app_digipal;

--
-- Name: generic_rating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE generic_rating_id_seq OWNED BY generic_rating.id;


--
-- Name: generic_threadedcomment; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE generic_threadedcomment (
    by_author boolean NOT NULL,
    comment_ptr_id integer NOT NULL,
    replied_to_id integer,
    rating_count integer NOT NULL,
    rating_average double precision NOT NULL,
    rating_sum integer NOT NULL
);


ALTER TABLE generic_threadedcomment OWNER TO app_digipal;

--
-- Name: pages_link; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE pages_link (
    page_ptr_id integer NOT NULL
);


ALTER TABLE pages_link OWNER TO app_digipal;

--
-- Name: pages_page; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE pages_page (
    status integer NOT NULL,
    _order integer,
    parent_id integer,
    description text NOT NULL,
    title character varying(500) NOT NULL,
    short_url character varying(200),
    login_required boolean NOT NULL,
    id integer NOT NULL,
    expiry_date timestamp with time zone,
    publish_date timestamp with time zone,
    titles character varying(1000),
    content_model character varying(50),
    slug character varying(2000),
    keywords_string character varying(500) NOT NULL,
    site_id integer NOT NULL,
    gen_description boolean NOT NULL,
    in_menus character varying(100),
    _meta_title character varying(500),
    in_sitemap boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone
);


ALTER TABLE pages_page OWNER TO app_digipal;

--
-- Name: pages_page_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE pages_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pages_page_id_seq OWNER TO app_digipal;

--
-- Name: pages_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE pages_page_id_seq OWNED BY pages_page.id;


--
-- Name: pages_richtextpage; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE pages_richtextpage (
    content text NOT NULL,
    page_ptr_id integer NOT NULL
);


ALTER TABLE pages_richtextpage OWNER TO app_digipal;

--
-- Name: reversion_revision; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE reversion_revision (
    id integer NOT NULL,
    date_created timestamp with time zone NOT NULL,
    user_id integer,
    comment text NOT NULL,
    manager_slug character varying(191) NOT NULL
);


ALTER TABLE reversion_revision OWNER TO app_digipal;

--
-- Name: reversion_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE reversion_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reversion_revision_id_seq OWNER TO app_digipal;

--
-- Name: reversion_revision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE reversion_revision_id_seq OWNED BY reversion_revision.id;


--
-- Name: reversion_version; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE reversion_version (
    id integer NOT NULL,
    revision_id integer NOT NULL,
    object_id text NOT NULL,
    content_type_id integer NOT NULL,
    format character varying(255) NOT NULL,
    serialized_data text NOT NULL,
    object_repr text NOT NULL,
    object_id_int integer
);


ALTER TABLE reversion_version OWNER TO app_digipal;

--
-- Name: reversion_version_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE reversion_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reversion_version_id_seq OWNER TO app_digipal;

--
-- Name: reversion_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE reversion_version_id_seq OWNED BY reversion_version.id;


--
-- Name: south_migrationhistory; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE south_migrationhistory (
    id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    migration character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE south_migrationhistory OWNER TO app_digipal;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE south_migrationhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE south_migrationhistory_id_seq OWNER TO app_digipal;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE south_migrationhistory_id_seq OWNED BY south_migrationhistory.id;


--
-- Name: twitter_query; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE twitter_query (
    interested boolean NOT NULL,
    type character varying(10) NOT NULL,
    id integer NOT NULL,
    value character varying(140) NOT NULL
);


ALTER TABLE twitter_query OWNER TO app_digipal;

--
-- Name: twitter_query_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE twitter_query_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE twitter_query_id_seq OWNER TO app_digipal;

--
-- Name: twitter_query_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE twitter_query_id_seq OWNED BY twitter_query.id;


--
-- Name: twitter_tweet; Type: TABLE; Schema: public; Owner: app_digipal
--

CREATE TABLE twitter_tweet (
    retweeter_profile_image_url character varying(200),
    text text,
    created_at timestamp with time zone,
    remote_id character varying(50) NOT NULL,
    retweeter_user_name character varying(100),
    profile_image_url character varying(200),
    full_name character varying(100),
    query_id integer NOT NULL,
    user_name character varying(100),
    id integer NOT NULL,
    retweeter_full_name character varying(100)
);


ALTER TABLE twitter_tweet OWNER TO app_digipal;

--
-- Name: twitter_tweet_id_seq; Type: SEQUENCE; Schema: public; Owner: app_digipal
--

CREATE SEQUENCE twitter_tweet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE twitter_tweet_id_seq OWNER TO app_digipal;

--
-- Name: twitter_tweet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_digipal
--

ALTER SEQUENCE twitter_tweet_id_seq OWNED BY twitter_tweet.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogcategory ALTER COLUMN id SET DEFAULT nextval('blog_blogcategory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost ALTER COLUMN id SET DEFAULT nextval('blog_blogpost_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_categories ALTER COLUMN id SET DEFAULT nextval('blog_blogpost_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_related_posts ALTER COLUMN id SET DEFAULT nextval('blog_blogpost_related_posts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY conf_setting ALTER COLUMN id SET DEFAULT nextval('conf_setting_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY core_sitepermission ALTER COLUMN id SET DEFAULT nextval('core_sitepermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY core_sitepermission_sites ALTER COLUMN id SET DEFAULT nextval('core_sitepermission_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allograph ALTER COLUMN id SET DEFAULT nextval('digipal_allograph_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allograph_aspects ALTER COLUMN id SET DEFAULT nextval('digipal_allograph_aspects_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allographcomponent ALTER COLUMN id SET DEFAULT nextval('digipal_allographcomponent_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allographcomponent_features ALTER COLUMN id SET DEFAULT nextval('digipal_allographcomponent_features_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet ALTER COLUMN id SET DEFAULT nextval('digipal_alphabet_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_hands ALTER COLUMN id SET DEFAULT nextval('digipal_alphabet_hands_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_ontographs ALTER COLUMN id SET DEFAULT nextval('digipal_alphabet_ontographs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_annotation ALTER COLUMN id SET DEFAULT nextval('digipal_annotation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_apitransform ALTER COLUMN id SET DEFAULT nextval('digipal_apitransform_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_appearance ALTER COLUMN id SET DEFAULT nextval('digipal_appearance_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_archive ALTER COLUMN id SET DEFAULT nextval('digipal_archive_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_aspect ALTER COLUMN id SET DEFAULT nextval('digipal_aspect_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_aspect_features ALTER COLUMN id SET DEFAULT nextval('digipal_aspect_features_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_authenticitycategory ALTER COLUMN id SET DEFAULT nextval('digipal_authenticitycategory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_carouselitem ALTER COLUMN id SET DEFAULT nextval('digipal_carouselitem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_cataloguenumber ALTER COLUMN id SET DEFAULT nextval('digipal_cataloguenumber_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_category ALTER COLUMN id SET DEFAULT nextval('digipal_category_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character ALTER COLUMN id SET DEFAULT nextval('digipal_character_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character_components ALTER COLUMN id SET DEFAULT nextval('digipal_character_components_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_characterform ALTER COLUMN id SET DEFAULT nextval('digipal_characterform_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_collation ALTER COLUMN id SET DEFAULT nextval('digipal_collation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_component ALTER COLUMN id SET DEFAULT nextval('digipal_component_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_component_features ALTER COLUMN id SET DEFAULT nextval('digipal_component_features_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_county ALTER COLUMN id SET DEFAULT nextval('digipal_county_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_currentitem ALTER COLUMN id SET DEFAULT nextval('digipal_currentitem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_currentitem_owners ALTER COLUMN id SET DEFAULT nextval('digipal_currentitem_owners_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_date ALTER COLUMN id SET DEFAULT nextval('digipal_date_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_dateevidence ALTER COLUMN id SET DEFAULT nextval('digipal_dateevidence_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_decoration ALTER COLUMN id SET DEFAULT nextval('digipal_decoration_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_description ALTER COLUMN id SET DEFAULT nextval('digipal_description_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_feature ALTER COLUMN id SET DEFAULT nextval('digipal_feature_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_format ALTER COLUMN id SET DEFAULT nextval('digipal_format_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph ALTER COLUMN id SET DEFAULT nextval('digipal_graph_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph_aspects ALTER COLUMN id SET DEFAULT nextval('digipal_graph_aspects_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graphcomponent ALTER COLUMN id SET DEFAULT nextval('digipal_graphcomponent_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graphcomponent_features ALTER COLUMN id SET DEFAULT nextval('digipal_graphcomponent_features_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hair ALTER COLUMN id SET DEFAULT nextval('digipal_hair_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand ALTER COLUMN id SET DEFAULT nextval('digipal_hand_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand_images ALTER COLUMN id SET DEFAULT nextval('digipal_hand_images_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_handdescription ALTER COLUMN id SET DEFAULT nextval('digipal_handdescription_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem ALTER COLUMN id SET DEFAULT nextval('digipal_historicalitem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_categories ALTER COLUMN id SET DEFAULT nextval('digipal_historicalitem_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_owners ALTER COLUMN id SET DEFAULT nextval('digipal_historicalitem_owners_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitemdate ALTER COLUMN id SET DEFAULT nextval('digipal_historicalitemdate_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitemtype ALTER COLUMN id SET DEFAULT nextval('digipal_historicalitemtype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiograph ALTER COLUMN id SET DEFAULT nextval('digipal_idiograph_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiograph_aspects ALTER COLUMN id SET DEFAULT nextval('digipal_idiograph_aspects_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiographcomponent ALTER COLUMN id SET DEFAULT nextval('digipal_idiographcomponent_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiographcomponent_features ALTER COLUMN id SET DEFAULT nextval('digipal_idiographcomponent_features_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_image ALTER COLUMN id SET DEFAULT nextval('digipal_image_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_imageannotationstatus ALTER COLUMN id SET DEFAULT nextval('digipal_imageannotationstatus_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_institution ALTER COLUMN id SET DEFAULT nextval('digipal_institution_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_institutiontype ALTER COLUMN id SET DEFAULT nextval('digipal_institutiontype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itemorigin ALTER COLUMN id SET DEFAULT nextval('digipal_itemorigin_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart ALTER COLUMN id SET DEFAULT nextval('digipal_itempart_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart_owners ALTER COLUMN id SET DEFAULT nextval('digipal_itempart_owners_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartauthenticity ALTER COLUMN id SET DEFAULT nextval('digipal_itempartauthenticity_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartitem ALTER COLUMN id SET DEFAULT nextval('digipal_itempartitem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itemparttype ALTER COLUMN id SET DEFAULT nextval('digipal_itemparttype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_keyval ALTER COLUMN id SET DEFAULT nextval('digipal_keyval_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_language ALTER COLUMN id SET DEFAULT nextval('digipal_language_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_latinstyle ALTER COLUMN id SET DEFAULT nextval('digipal_latinstyle_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_layout ALTER COLUMN id SET DEFAULT nextval('digipal_layout_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_measurement ALTER COLUMN id SET DEFAULT nextval('digipal_measurement_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_mediapermission ALTER COLUMN id SET DEFAULT nextval('digipal_mediapermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_ontograph ALTER COLUMN id SET DEFAULT nextval('digipal_ontograph_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_ontographtype ALTER COLUMN id SET DEFAULT nextval('digipal_ontographtype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_owner ALTER COLUMN id SET DEFAULT nextval('digipal_owner_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_ownertype ALTER COLUMN id SET DEFAULT nextval('digipal_ownertype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_person ALTER COLUMN id SET DEFAULT nextval('digipal_person_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_place ALTER COLUMN id SET DEFAULT nextval('digipal_place_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_placeevidence ALTER COLUMN id SET DEFAULT nextval('digipal_placeevidence_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_placetype ALTER COLUMN id SET DEFAULT nextval('digipal_placetype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_proportion ALTER COLUMN id SET DEFAULT nextval('digipal_proportion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_reference ALTER COLUMN id SET DEFAULT nextval('digipal_reference_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_region ALTER COLUMN id SET DEFAULT nextval('digipal_region_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_repository ALTER COLUMN id SET DEFAULT nextval('digipal_repository_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_requestlog ALTER COLUMN id SET DEFAULT nextval('digipal_requestlog_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scribe ALTER COLUMN id SET DEFAULT nextval('digipal_scribe_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scribe_reference ALTER COLUMN id SET DEFAULT nextval('digipal_scribe_reference_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_script ALTER COLUMN id SET DEFAULT nextval('digipal_script_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_script_allographs ALTER COLUMN id SET DEFAULT nextval('digipal_script_allographs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scriptcomponent ALTER COLUMN id SET DEFAULT nextval('digipal_scriptcomponent_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scriptcomponent_features ALTER COLUMN id SET DEFAULT nextval('digipal_scriptcomponent_features_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_source ALTER COLUMN id SET DEFAULT nextval('digipal_source_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_status ALTER COLUMN id SET DEFAULT nextval('digipal_status_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_stewartrecord ALTER COLUMN id SET DEFAULT nextval('digipal_stewartrecord_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text ALTER COLUMN id SET DEFAULT nextval('digipal_text_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_categories ALTER COLUMN id SET DEFAULT nextval('digipal_text_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_entryhand ALTER COLUMN id SET DEFAULT nextval('digipal_text_entryhand_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_languages ALTER COLUMN id SET DEFAULT nextval('digipal_text_languages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textannotation ALTER COLUMN id SET DEFAULT nextval('digipal_text_textannotation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent ALTER COLUMN id SET DEFAULT nextval('digipal_text_textcontent_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent_languages ALTER COLUMN id SET DEFAULT nextval('digipal_text_textcontent_languages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontenttype ALTER COLUMN id SET DEFAULT nextval('digipal_text_textcontenttype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxml ALTER COLUMN id SET DEFAULT nextval('digipal_text_textcontentxml_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxmlcopy ALTER COLUMN id SET DEFAULT nextval('digipal_text_textcontentxmlcopy_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxmlstatus ALTER COLUMN id SET DEFAULT nextval('digipal_text_textcontentxmlstatus_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textpattern ALTER COLUMN id SET DEFAULT nextval('digipal_text_textpattern_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_textitempart ALTER COLUMN id SET DEFAULT nextval('digipal_textitempart_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comment_flags ALTER COLUMN id SET DEFAULT nextval('django_comment_flags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comments ALTER COLUMN id SET DEFAULT nextval('django_comments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_redirect ALTER COLUMN id SET DEFAULT nextval('django_redirect_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_field ALTER COLUMN id SET DEFAULT nextval('forms_field_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_fieldentry ALTER COLUMN id SET DEFAULT nextval('forms_fieldentry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_formentry ALTER COLUMN id SET DEFAULT nextval('forms_formentry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY galleries_galleryimage ALTER COLUMN id SET DEFAULT nextval('galleries_galleryimage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_assignedkeyword ALTER COLUMN id SET DEFAULT nextval('generic_assignedkeyword_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_keyword ALTER COLUMN id SET DEFAULT nextval('generic_keyword_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_rating ALTER COLUMN id SET DEFAULT nextval('generic_rating_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY pages_page ALTER COLUMN id SET DEFAULT nextval('pages_page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY reversion_revision ALTER COLUMN id SET DEFAULT nextval('reversion_revision_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY reversion_version ALTER COLUMN id SET DEFAULT nextval('reversion_version_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY south_migrationhistory ALTER COLUMN id SET DEFAULT nextval('south_migrationhistory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY twitter_query ALTER COLUMN id SET DEFAULT nextval('twitter_query_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY twitter_tweet ALTER COLUMN id SET DEFAULT nextval('twitter_tweet_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add user	3	add_user
8	Can change user	3	change_user
9	Can delete user	3	delete_user
10	Can add content type	4	add_contenttype
11	Can change content type	4	change_contenttype
12	Can delete content type	4	delete_contenttype
13	Can add redirect	5	add_redirect
14	Can change redirect	5	change_redirect
15	Can delete redirect	5	delete_redirect
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add site	7	add_site
20	Can change site	7	change_site
21	Can delete site	7	delete_site
22	Can add migration history	8	add_migrationhistory
23	Can change migration history	8	change_migrationhistory
24	Can delete migration history	8	delete_migrationhistory
25	Can add log entry	9	add_logentry
26	Can change log entry	9	change_logentry
27	Can delete log entry	9	delete_logentry
28	Can add comment	10	add_comment
29	Can change comment	10	change_comment
30	Can delete comment	10	delete_comment
31	Can moderate comments	10	can_moderate
32	Can add comment flag	11	add_commentflag
33	Can change comment flag	11	change_commentflag
34	Can delete comment flag	11	delete_commentflag
35	Can add Setting	12	add_setting
36	Can change Setting	12	change_setting
37	Can delete Setting	12	delete_setting
38	Can add Site permission	13	add_sitepermission
39	Can change Site permission	13	change_sitepermission
40	Can delete Site permission	13	delete_sitepermission
41	Can add Page	14	add_page
42	Can change Page	14	change_page
43	Can delete Page	14	delete_page
44	Can add Rich text page	15	add_richtextpage
45	Can change Rich text page	15	change_richtextpage
46	Can delete Rich text page	15	delete_richtextpage
47	Can add Link	16	add_link
48	Can change Link	16	change_link
49	Can delete Link	16	delete_link
50	Can add Blog post	17	add_blogpost
51	Can change Blog post	17	change_blogpost
52	Can delete Blog post	17	delete_blogpost
53	Can add Blog Category	18	add_blogcategory
54	Can change Blog Category	18	change_blogcategory
55	Can delete Blog Category	18	delete_blogcategory
56	Can add Comment	19	add_threadedcomment
57	Can change Comment	19	change_threadedcomment
58	Can delete Comment	19	delete_threadedcomment
59	Can add Keyword	20	add_keyword
60	Can change Keyword	20	change_keyword
61	Can delete Keyword	20	delete_keyword
62	Can add assigned keyword	21	add_assignedkeyword
63	Can change assigned keyword	21	change_assignedkeyword
64	Can delete assigned keyword	21	delete_assignedkeyword
65	Can add Rating	22	add_rating
66	Can change Rating	22	change_rating
67	Can delete Rating	22	delete_rating
68	Can add Form	23	add_form
69	Can change Form	23	change_form
70	Can delete Form	23	delete_form
71	Can add Field	24	add_field
72	Can change Field	24	change_field
73	Can delete Field	24	delete_field
74	Can add Form entry	25	add_formentry
75	Can change Form entry	25	change_formentry
76	Can delete Form entry	25	delete_formentry
77	Can add Form field entry	26	add_fieldentry
78	Can change Form field entry	26	change_fieldentry
79	Can delete Form field entry	26	delete_fieldentry
80	Can add Gallery	27	add_gallery
81	Can change Gallery	27	change_gallery
82	Can delete Gallery	27	delete_gallery
83	Can add Image	28	add_galleryimage
84	Can change Image	28	change_galleryimage
85	Can delete Image	28	delete_galleryimage
86	Can add Twitter query	29	add_query
87	Can change Twitter query	29	change_query
88	Can delete Twitter query	29	delete_query
89	Can add Tweet	30	add_tweet
90	Can change Tweet	30	change_tweet
91	Can delete Tweet	30	delete_tweet
92	Can add media permission	31	add_mediapermission
93	Can change media permission	31	change_mediapermission
94	Can delete media permission	31	delete_mediapermission
95	Can add appearance	32	add_appearance
96	Can change appearance	32	change_appearance
97	Can delete appearance	32	delete_appearance
98	Can add feature	33	add_feature
99	Can change feature	33	change_feature
100	Can delete feature	33	delete_feature
101	Can add component	34	add_component
102	Can change component	34	change_component
103	Can delete component	34	delete_component
104	Can add component feature	35	add_componentfeature
105	Can change component feature	35	change_componentfeature
106	Can delete component feature	35	delete_componentfeature
107	Can add aspect	36	add_aspect
108	Can change aspect	36	change_aspect
109	Can delete aspect	36	delete_aspect
110	Can add ontograph type	37	add_ontographtype
111	Can change ontograph type	37	change_ontographtype
112	Can delete ontograph type	37	delete_ontographtype
113	Can add ontograph	38	add_ontograph
114	Can change ontograph	38	change_ontograph
115	Can delete ontograph	38	delete_ontograph
116	Can add character form	39	add_characterform
117	Can change character form	39	change_characterform
118	Can delete character form	39	delete_characterform
119	Can add character	40	add_character
120	Can change character	40	change_character
121	Can delete character	40	delete_character
122	Can add allograph	41	add_allograph
123	Can change allograph	41	change_allograph
124	Can delete allograph	41	delete_allograph
125	Can add allograph component	42	add_allographcomponent
126	Can change allograph component	42	change_allographcomponent
127	Can delete allograph component	42	delete_allographcomponent
128	Can add Text Info	43	add_text
129	Can change Text Info	43	change_text
130	Can delete Text Info	43	delete_text
131	Can add script	44	add_script
132	Can change script	44	change_script
133	Can delete script	44	delete_script
134	Can add script component	45	add_scriptcomponent
135	Can change script component	45	change_scriptcomponent
136	Can delete script component	45	delete_scriptcomponent
137	Can add reference	46	add_reference
138	Can change reference	46	change_reference
139	Can delete reference	46	delete_reference
140	Can add owner	47	add_owner
141	Can change owner	47	change_owner
142	Can delete owner	47	delete_owner
143	Can add date	48	add_date
144	Can change date	48	change_date
145	Can delete date	48	delete_date
146	Can add category	49	add_category
147	Can change category	49	change_category
148	Can delete category	49	delete_category
149	Can add format	50	add_format
150	Can change format	50	change_format
151	Can delete format	50	delete_format
152	Can add hair	51	add_hair
153	Can change hair	51	change_hair
154	Can delete hair	51	delete_hair
155	Can add historical item type	52	add_historicalitemtype
156	Can change historical item type	52	change_historicalitemtype
157	Can delete historical item type	52	delete_historicalitemtype
158	Can add language	53	add_language
159	Can change language	53	change_language
160	Can delete language	53	delete_language
161	Can add historical item	54	add_historicalitem
162	Can change historical item	54	change_historicalitem
163	Can delete historical item	54	delete_historicalitem
164	Can add source	55	add_source
165	Can change source	55	change_source
166	Can delete source	55	delete_source
167	Can add catalogue number	56	add_cataloguenumber
168	Can change catalogue number	56	change_cataloguenumber
169	Can delete catalogue number	56	delete_cataloguenumber
170	Can add collation	57	add_collation
171	Can change collation	57	change_collation
172	Can delete collation	57	delete_collation
173	Can add decoration	58	add_decoration
174	Can change decoration	58	change_decoration
175	Can delete decoration	58	delete_decoration
176	Can add description	59	add_description
177	Can change description	59	change_description
178	Can delete description	59	delete_description
179	Can add layout	60	add_layout
180	Can change layout	60	change_layout
181	Can delete layout	60	delete_layout
182	Can add item origin	61	add_itemorigin
183	Can change item origin	61	change_itemorigin
184	Can delete item origin	61	delete_itemorigin
185	Can add archive	62	add_archive
186	Can change archive	62	change_archive
187	Can delete archive	62	delete_archive
188	Can add region	63	add_region
189	Can change region	63	change_region
190	Can delete region	63	delete_region
191	Can add county	64	add_county
192	Can change county	64	change_county
193	Can delete county	64	delete_county
194	Can add place type	65	add_placetype
195	Can change place type	65	change_placetype
196	Can delete place type	65	delete_placetype
197	Can add place	66	add_place
198	Can change place	66	change_place
199	Can delete place	66	delete_place
200	Can add owner type	67	add_ownertype
201	Can change owner type	67	change_ownertype
202	Can delete owner type	67	delete_ownertype
203	Can add repository	68	add_repository
204	Can change repository	68	change_repository
205	Can delete repository	68	delete_repository
206	Can add current item	69	add_currentitem
207	Can change current item	69	change_currentitem
208	Can delete current item	69	delete_currentitem
209	Can add person	70	add_person
210	Can change person	70	change_person
211	Can delete person	70	delete_person
212	Can add institution type	71	add_institutiontype
213	Can change institution type	71	change_institutiontype
214	Can delete institution type	71	delete_institutiontype
215	Can add institution	72	add_institution
216	Can change institution	72	change_institution
217	Can delete institution	72	delete_institution
218	Can add scribe	73	add_scribe
219	Can change scribe	73	change_scribe
220	Can delete scribe	73	delete_scribe
221	Can add idiograph	74	add_idiograph
222	Can change idiograph	74	change_idiograph
223	Can delete idiograph	74	delete_idiograph
224	Can add idiograph component	75	add_idiographcomponent
225	Can change idiograph component	75	change_idiographcomponent
226	Can delete idiograph component	75	delete_idiographcomponent
227	Can add historical item date	76	add_historicalitemdate
228	Can change historical item date	76	change_historicalitemdate
229	Can delete historical item date	76	delete_historicalitemdate
230	Can add item part type	77	add_itemparttype
231	Can change item part type	77	change_itemparttype
232	Can delete item part type	77	delete_itemparttype
233	Can add item part	78	add_itempart
234	Can change item part	78	change_itempart
235	Can delete item part	78	delete_itempart
236	Can add Item Partition	79	add_itempartitem
237	Can change Item Partition	79	change_itempartitem
238	Can delete Item Partition	79	delete_itempartitem
239	Can add item part authenticity	80	add_itempartauthenticity
240	Can change item part authenticity	80	change_itempartauthenticity
241	Can delete item part authenticity	80	delete_itempartauthenticity
242	Can add authenticity category	81	add_authenticitycategory
243	Can change authenticity category	81	change_authenticitycategory
244	Can delete authenticity category	81	delete_authenticitycategory
245	Can add text item part	82	add_textitempart
246	Can change text item part	82	change_textitempart
247	Can delete text item part	82	delete_textitempart
248	Can add latin style	83	add_latinstyle
249	Can change latin style	83	change_latinstyle
250	Can delete latin style	83	delete_latinstyle
251	Can add image annotation status	84	add_imageannotationstatus
252	Can change image annotation status	84	change_imageannotationstatus
253	Can delete image annotation status	84	delete_imageannotationstatus
254	Can add image	85	add_image
255	Can change image	85	change_image
256	Can delete image	85	delete_image
257	Can add hand	86	add_hand
258	Can change hand	86	change_hand
259	Can delete hand	86	delete_hand
260	Can add hand description	87	add_handdescription
261	Can change hand description	87	change_handdescription
262	Can delete hand description	87	delete_handdescription
263	Can add alphabet	88	add_alphabet
264	Can change alphabet	88	change_alphabet
265	Can delete alphabet	88	delete_alphabet
266	Can add date evidence	89	add_dateevidence
267	Can change date evidence	89	change_dateevidence
268	Can delete date evidence	89	delete_dateevidence
269	Can add graph	90	add_graph
270	Can change graph	90	change_graph
271	Can delete graph	90	delete_graph
272	Can add graph component	91	add_graphcomponent
273	Can change graph component	91	change_graphcomponent
274	Can delete graph component	91	delete_graphcomponent
275	Can add status	92	add_status
276	Can change status	92	change_status
277	Can delete status	92	delete_status
278	Can add annotation	93	add_annotation
279	Can change annotation	93	change_annotation
280	Can delete annotation	93	delete_annotation
281	Can add place evidence	94	add_placeevidence
282	Can change place evidence	94	change_placeevidence
283	Can delete place evidence	94	delete_placeevidence
284	Can add measurement	95	add_measurement
285	Can change measurement	95	change_measurement
286	Can delete measurement	95	delete_measurement
287	Can add proportion	96	add_proportion
288	Can change proportion	96	change_proportion
289	Can delete proportion	96	delete_proportion
290	Can add carousel item	97	add_carouselitem
291	Can change carousel item	97	change_carouselitem
292	Can delete carousel item	97	delete_carouselitem
293	Can add stewart record	98	add_stewartrecord
294	Can change stewart record	98	change_stewartrecord
295	Can delete stewart record	98	delete_stewartrecord
296	Can add request log	99	add_requestlog
297	Can change request log	99	change_requestlog
298	Can delete request log	99	delete_requestlog
299	Can add api transform	100	add_apitransform
300	Can change api transform	100	change_apitransform
301	Can delete api transform	100	delete_apitransform
302	Can add Text Type	101	add_textcontenttype
303	Can change Text Type	101	change_textcontenttype
304	Can delete Text Type	101	delete_textcontenttype
305	Can add Text (meta)	102	add_textcontent
306	Can change Text (meta)	102	change_textcontent
307	Can delete Text (meta)	102	delete_textcontent
308	Can add Text Status	103	add_textcontentxmlstatus
309	Can change Text Status	103	change_textcontentxmlstatus
310	Can delete Text Status	103	delete_textcontentxmlstatus
311	Can add Text Copy	104	add_textcontentxmlcopy
312	Can change Text Copy	104	change_textcontentxmlcopy
313	Can delete Text Copy	104	delete_textcontentxmlcopy
314	Can add Text (XML)	105	add_textcontentxml
315	Can change Text (XML)	105	change_textcontentxml
316	Can delete Text (XML)	105	delete_textcontentxml
317	Can add text annotation	106	add_textannotation
318	Can change text annotation	106	change_textannotation
319	Can delete text annotation	106	delete_textannotation
320	Can add entry hand	107	add_entryhand
321	Can change entry hand	107	change_entryhand
322	Can delete entry hand	107	delete_entryhand
323	Can add revision	108	add_revision
324	Can change revision	108	change_revision
325	Can delete revision	108	delete_revision
326	Can add version	109	add_version
327	Can change version	109	change_version
328	Can delete version	109	delete_version
329	Can add key val	111	add_keyval
330	Can change key val	111	change_keyval
331	Can delete key val	111	delete_keyval
332	Can add text pattern	112	add_textpattern
333	Can change text pattern	112	change_textpattern
334	Can delete text pattern	112	delete_textpattern
335	Can add comment	113	add_comment
336	Can change comment	113	change_comment
337	Can delete comment	113	delete_comment
338	Can moderate comments	113	can_moderate
339	Can add comment flag	114	add_commentflag
340	Can change comment flag	114	change_commentflag
341	Can delete comment flag	114	delete_commentflag
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('auth_permission_id_seq', 341, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$20000$cZaQVTz4as5T$Y14qz3+6H9WSkiqwBfYWaYX8uG8mJsxwIZo122VZqAI=	2017-08-29 20:48:33.31245+00	t	admin	Admin			t	t	2015-03-12 17:34:13+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: blog_blogcategory; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY blog_blogcategory (slug, id, title, site_id) FROM stdin;
blog	1	Blog	1
news	2	News	1
\.


--
-- Name: blog_blogcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('blog_blogcategory_id_seq', 2, true);


--
-- Data for Name: blog_blogpost; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY blog_blogpost (status, description, title, short_url, id, content, expiry_date, publish_date, user_id, slug, comments_count, keywords_string, site_id, rating_average, rating_count, allow_comments, featured_image, gen_description, _meta_title, in_sitemap, rating_sum, created, updated) FROM stdin;
2	This is an example news item. You can delete this and add your own very easily: just log in (using the link at the bottom of the page), then click on Database &gt; Web Content &gt; Blog Posts. Enter a title in the 'Title' field of the form, set the category to 'News', then scroll down and type your text into the 'Content' box. Click 'Save' and you're done!	First News Item	\N	2	<p>This is an example news item. You can delete this and add your own very easily: just log in (using the link at the bottom of the page), then click on Database &gt; Web Content &gt; Blog Posts. Enter a title in the 'Title' field of the form, set the category to 'News', then scroll down and type your text into the 'Content' box. Click 'Save' and you're done!</p>	\N	2017-04-21 21:25:01.57058+00	1	first-news-item	0		1	0	0	t	\N	t		t	0	2017-04-21 21:25:01.578855+00	2017-04-21 21:25:01.578855+00
2	This is an example blog post. You can delete this and add your own very easily: just log in (using the link at the bottom of the page), then click on Database &gt; Web Content &gt; Blog Posts. Enter a title in the 'Title' field of the form, set the category to 'Blog', then scroll down and type your text into the 'Content' box. Click 'Save' and you're done!	First Blog Post	http://127.0.0.1:8000/blog/first-blog-post/	1	<p>This is an example blog post. You can delete this and add your own very easily: just log in (using the link at the bottom of the page), then click on Database &gt; Web Content &gt; Blog Posts. Enter a title in the 'Title' field of the form, set the category to 'Blog', then scroll down and type your text into the 'Content' box. Click 'Save' and you're done!</p>	\N	2017-04-21 21:24:30.017191+00	1	first-blog-post	0		1	0	0	t	\N	t		t	0	2017-04-21 21:24:30.034667+00	2017-04-21 21:25:37.453652+00
\.


--
-- Data for Name: blog_blogpost_categories; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY blog_blogpost_categories (id, blogpost_id, blogcategory_id) FROM stdin;
1	1	1
2	2	2
\.


--
-- Name: blog_blogpost_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('blog_blogpost_categories_id_seq', 2, true);


--
-- Name: blog_blogpost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('blog_blogpost_id_seq', 2, true);


--
-- Data for Name: blog_blogpost_related_posts; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY blog_blogpost_related_posts (id, from_blogpost_id, to_blogpost_id) FROM stdin;
\.


--
-- Name: blog_blogpost_related_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('blog_blogpost_related_posts_id_seq', 1, false);


--
-- Data for Name: conf_setting; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY conf_setting (id, value, name, site_id) FROM stdin;
\.


--
-- Name: conf_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('conf_setting_id_seq', 1, false);


--
-- Data for Name: core_sitepermission; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY core_sitepermission (id, user_id) FROM stdin;
\.


--
-- Name: core_sitepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('core_sitepermission_id_seq', 1, false);


--
-- Data for Name: core_sitepermission_sites; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY core_sitepermission_sites (id, sitepermission_id, site_id) FROM stdin;
\.


--
-- Name: core_sitepermission_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('core_sitepermission_sites_id_seq', 1, false);


--
-- Data for Name: digipal_allograph; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_allograph (id, name, character_id, "default", created, modified, hidden) FROM stdin;
1	abbrev. stroke	1	f	2012-05-21 13:24:50.273+00	2013-05-02 10:17:56.446+00	f
2	wynn	2	f	2012-05-21 13:24:50.285+00	2013-05-02 10:17:56.45+00	f
3	punctus elevatus	3	f	2012-05-21 13:24:50.299+00	2013-05-02 10:17:56.453+00	f
4	ligature	4	f	2012-05-21 13:24:50.313+00	2013-05-02 10:17:56.457+00	f
5	accent	5	f	2012-05-21 13:24:50.328+00	2013-05-02 10:17:56.461+00	f
6	punctus	6	f	2012-05-21 13:24:50.34+00	2013-05-02 10:17:56.464+00	f
7	7	7	f	2012-05-21 13:24:50.352+00	2013-05-02 10:17:56.468+00	f
8	punctus versus	8	f	2012-05-21 13:24:50.367+00	2013-05-02 10:17:56.472+00	f
9	punctus interrogativus	9	f	2012-05-21 13:24:50.38+00	2013-05-02 10:17:56.475+00	f
10	N	10	f	2012-05-21 13:24:50.394+00	2013-05-02 10:17:56.48+00	f
11	Insular	11	t	2012-05-21 13:24:50.407+00	2013-05-02 10:17:56.484+00	f
12	Square	11	f	2012-05-21 13:24:50.413+00	2013-05-02 10:17:56.49+00	f
13	Caroline	11	f	2012-05-21 13:24:50.421+00	2013-05-02 10:17:56.495+00	f
14	&	12	f	2012-05-21 13:24:50.439+00	2013-05-02 10:17:56.499+00	f
15	c	13	f	2012-05-21 13:24:50.457+00	2013-05-02 10:17:56.502+00	f
16	b	14	f	2012-05-21 13:24:50.471+00	2013-05-02 10:17:56.506+00	f
17	e	15	f	2012-05-21 13:24:50.484+00	2013-05-02 10:17:56.51+00	f
18	Insular	16	t	2012-05-21 13:24:50.498+00	2013-05-02 10:17:56.513+00	f
19	Caroline	16	f	2012-05-21 13:24:50.504+00	2014-07-03 20:01:23.011+00	f
20	Insular	17	t	2012-05-21 13:24:50.518+00	2013-05-02 10:17:56.52+00	f
21	Caroline	17	f	2012-05-21 13:24:50.53+00	2013-05-02 10:17:56.527+00	f
22	Insular	18	t	2012-05-21 13:24:50.541+00	2013-05-02 10:17:56.53+00	f
23	Square	18	f	2012-05-21 13:24:50.552+00	2013-05-02 10:17:56.538+00	f
24	Caroline	18	f	2012-05-21 13:24:50.568+00	2013-05-02 10:17:56.542+00	f
25	i	19	f	2012-05-21 13:24:50.589+00	2013-05-02 10:17:56.546+00	f
26	Insular	20	t	2012-05-21 13:24:50.6+00	2013-05-02 10:17:56.55+00	f
27	k	21	f	2012-05-21 13:24:50.613+00	2013-05-02 10:17:56.554+00	f
28	Insular	22	t	2012-05-21 13:24:50.628+00	2013-05-02 10:17:56.558+00	f
29	Caroline	22	f	2012-05-21 13:24:50.643+00	2013-05-02 10:17:56.562+00	f
30	m	23	f	2012-05-21 13:24:50.66+00	2013-05-02 10:17:56.565+00	f
31	l	24	f	2012-05-21 13:24:50.675+00	2013-05-02 10:17:56.569+00	f
32	o	25	f	2012-05-21 13:24:50.686+00	2013-05-02 10:17:56.574+00	f
33	n	26	f	2012-05-21 13:24:50.696+00	2013-05-02 10:17:56.579+00	f
34	q	27	f	2012-05-21 13:24:50.709+00	2013-05-02 10:17:56.584+00	f
35	p	28	f	2012-05-21 13:24:50.722+00	2013-05-02 10:17:56.588+00	f
36	Tall	29	f	2012-05-21 13:24:50.735+00	2013-05-02 10:17:56.592+00	f
37	Caroline	29	f	2012-05-21 13:24:50.744+00	2013-05-02 10:17:56.596+00	f
38	Round	29	f	2012-05-21 13:24:50.751+00	2013-05-02 10:17:56.6+00	f
39	Long	29	f	2012-05-21 13:24:50.758+00	2013-05-02 10:17:56.603+00	f
40	Low	29	t	2012-05-21 13:24:50.768+00	2013-05-02 10:17:56.607+00	f
41	Insular	30	t	2012-05-21 13:24:50.781+00	2013-05-02 10:17:56.613+00	f
42	Caroline	30	f	2012-05-21 13:24:50.787+00	2013-05-02 10:17:56.616+00	f
43	u	31	f	2012-05-21 13:24:50.8+00	2013-05-02 10:17:56.62+00	f
44	t	32	f	2012-05-21 13:24:50.813+00	2013-05-02 10:17:56.624+00	f
45	Straight	33	t	2012-05-21 13:24:50.825+00	2013-05-02 10:17:56.628+00	f
46	Round	33	f	2012-05-21 13:24:50.833+00	2014-07-07 17:09:05.666+00	f
47	F-shaped	33	f	2012-05-21 13:24:50.842+00	2013-05-02 10:17:56.635+00	f
48	x	34	t	2012-05-21 13:24:50.859+00	2013-05-02 10:17:56.639+00	f
49	Three-stroke	34	f	2012-05-21 13:24:50.867+00	2013-05-02 10:17:56.642+00	f
50	eth	35	f	2012-05-21 13:24:50.882+00	2013-05-02 10:17:56.646+00	f
51	z	36	f	2012-05-21 13:24:50.898+00	2013-05-02 10:17:56.651+00	f
52	thorn	37	f	2012-05-21 13:24:50.914+00	2013-05-02 10:17:56.655+00	f
56	thæt	38	f	2012-07-03 17:28:06.256+00	2013-05-02 10:17:56.659+00	f
57	Caroline	20	f	2012-07-06 14:26:47.254+00	2013-05-02 10:17:56.662+00	f
58	2-shaped	30	f	2013-07-13 21:28:52.091+00	2013-07-13 21:28:52.091+00	f
59	Round	18	f	2012-11-21 14:24:59.451+00	2012-11-21 14:24:59.451+00	f
\.


--
-- Data for Name: digipal_allograph_aspects; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_allograph_aspects (id, allograph_id, aspect_id) FROM stdin;
\.


--
-- Name: digipal_allograph_aspects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_allograph_aspects_id_seq', 1, false);


--
-- Name: digipal_allograph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_allograph_id_seq', 59, true);


--
-- Data for Name: digipal_allographcomponent; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_allographcomponent (id, allograph_id, component_id, created, modified) FROM stdin;
1	2	11	2012-05-22 13:06:41.786335+00	2013-05-02 10:17:56.673202+00
2	2	22	2012-05-22 13:06:41.788845+00	2013-05-02 10:17:56.678589+00
3	3	30	2012-05-22 13:06:41.798534+00	2013-05-02 10:17:56.68398+00
4	3	39	2012-05-22 13:06:41.800428+00	2013-05-02 10:17:56.689357+00
5	4	20	2012-05-22 13:06:41.811209+00	2013-05-02 10:17:56.693219+00
6	5	46	2012-05-22 13:06:41.822231+00	2013-05-02 10:17:56.69693+00
7	6	30	2012-05-22 13:06:41.832954+00	2013-05-02 10:17:56.700763+00
8	7	38	2012-05-22 13:06:41.844366+00	2013-05-02 10:17:56.704434+00
9	7	1	2012-05-22 13:06:41.846571+00	2013-05-02 10:17:56.708117+00
10	8	30	2012-05-22 13:06:41.855445+00	2013-05-02 10:17:56.711801+00
11	8	9	2012-05-22 13:06:41.861144+00	2013-05-02 10:17:56.715435+00
12	9	30	2012-05-22 13:06:41.871131+00	2013-05-02 10:17:56.719128+00
13	9	37	2012-05-22 13:06:41.875834+00	2013-05-02 10:17:56.722965+00
14	11	5	2012-05-22 13:06:41.899858+00	2013-05-02 10:17:56.726731+00
15	11	8	2012-05-22 13:06:41.901738+00	2013-05-02 10:17:56.730515+00
16	12	28	2012-05-22 13:06:41.904826+00	2013-05-02 10:17:56.734322+00
17	12	38	2012-05-22 13:06:41.906755+00	2013-05-02 10:17:56.73769+00
18	12	25	2012-05-22 13:06:41.908666+00	2013-05-02 10:17:56.742042+00
19	13	18	2012-05-22 13:06:41.911762+00	2013-05-02 10:17:56.748733+00
20	13	5	2012-05-22 13:06:41.913601+00	2013-05-02 10:17:56.753126+00
21	13	22	2012-05-22 13:06:41.91563+00	2013-05-02 10:17:56.758682+00
22	14	41	2012-05-22 13:06:41.925832+00	2013-05-02 10:17:56.763964+00
23	14	40	2012-05-22 13:06:41.927681+00	2013-05-02 10:17:56.769386+00
24	14	23	2012-05-22 13:06:41.929559+00	2013-05-02 10:17:56.77328+00
25	15	19	2012-05-22 13:06:41.939862+00	2013-05-02 10:17:56.777038+00
26	15	25	2012-05-22 13:06:41.941728+00	2013-05-02 10:17:56.780807+00
27	16	4	2012-05-22 13:06:41.951617+00	2013-05-02 10:17:56.784464+00
28	16	8	2012-05-22 13:06:41.957724+00	2013-05-02 10:17:56.788158+00
29	17	15	2012-05-22 13:06:41.967902+00	2013-05-02 10:17:56.791971+00
30	17	25	2012-05-22 13:06:41.970547+00	2013-05-02 10:17:56.795703+00
31	18	8	2012-05-22 13:06:41.980784+00	2013-05-02 10:17:56.799603+00
32	18	34	2012-05-22 13:06:41.982884+00	2013-05-02 10:17:56.803445+00
33	19	8	2012-05-22 13:06:41.985904+00	2013-05-02 10:17:56.807098+00
34	19	4	2012-05-22 13:06:41.987798+00	2013-05-02 10:17:56.810537+00
35	20	38	2012-05-22 13:06:42.001692+00	2013-05-02 10:17:56.814406+00
36	20	27	2012-05-22 13:06:42.003629+00	2013-05-02 10:17:56.818112+00
37	20	17	2012-05-22 13:06:42.005425+00	2013-05-02 10:17:56.821434+00
38	22	5	2012-05-22 13:06:42.018238+00	2013-05-02 10:17:56.825254+00
39	22	22	2012-05-22 13:06:42.020182+00	2013-05-02 10:17:56.828793+00
40	22	15	2012-05-22 13:06:42.02206+00	2013-05-02 10:17:56.832358+00
41	22	25	2012-05-22 13:06:42.023918+00	2013-05-02 10:17:56.836335+00
42	22	35	2012-05-22 13:06:42.025795+00	2013-05-02 10:17:56.84004+00
43	23	28	2012-05-22 13:06:42.028782+00	2013-05-02 10:17:56.84373+00
44	23	38	2012-05-22 13:06:42.030657+00	2013-05-02 10:17:56.847366+00
45	23	25	2012-05-22 13:06:42.032581+00	2013-05-02 10:17:56.851216+00
46	23	15	2012-05-22 13:06:42.034506+00	2013-05-02 10:17:56.854925+00
47	23	35	2012-05-22 13:06:42.036415+00	2013-05-02 10:17:56.858774+00
48	24	18	2012-05-22 13:06:42.039692+00	2013-05-02 10:17:56.862427+00
49	24	5	2012-05-22 13:06:42.041642+00	2013-05-02 10:17:56.866114+00
50	24	22	2012-05-22 13:06:42.043694+00	2013-05-02 10:17:56.86964+00
51	24	15	2012-05-22 13:06:42.045542+00	2013-05-02 10:17:56.87341+00
52	24	25	2012-05-22 13:06:42.047409+00	2013-05-02 10:17:56.877083+00
53	24	35	2012-05-22 13:06:42.049214+00	2013-05-02 10:17:56.881007+00
54	25	28	2012-05-22 13:06:42.062675+00	2013-05-02 10:17:56.885138+00
55	26	4	2012-05-22 13:06:42.072663+00	2013-05-02 10:17:56.888985+00
56	26	3	2012-05-22 13:06:42.074491+00	2013-05-02 10:17:56.892799+00
57	27	4	2012-05-22 13:06:42.084064+00	2013-05-02 10:17:56.896538+00
58	27	41	2012-05-22 13:06:42.085874+00	2013-05-02 10:17:56.901911+00
59	27	24	2012-05-22 13:06:42.087667+00	2013-05-02 10:17:56.907518+00
60	28	19	2012-05-22 13:06:42.100911+00	2013-05-02 10:17:56.915025+00
61	28	35	2012-05-22 13:06:42.102914+00	2013-05-02 10:17:56.918714+00
62	28	11	2012-05-22 13:06:42.104915+00	2013-05-02 10:17:56.922487+00
63	29	19	2012-05-22 13:06:42.10794+00	2013-05-02 10:17:56.926263+00
64	29	35	2012-05-22 13:06:42.109842+00	2013-05-02 10:17:56.9297+00
65	29	13	2012-05-22 13:06:42.111802+00	2013-05-02 10:17:56.933195+00
66	30	28	2012-05-22 13:06:42.121884+00	2013-05-02 10:17:56.936826+00
67	30	26	2012-05-22 13:06:42.124055+00	2013-05-02 10:17:56.94057+00
68	30	3	2012-05-22 13:06:42.125895+00	2013-05-02 10:17:56.944017+00
69	31	4	2012-05-22 13:06:42.135712+00	2013-05-02 10:17:56.94913+00
70	32	8	2012-05-22 13:06:42.145551+00	2013-05-02 10:17:56.954232+00
71	33	28	2012-05-22 13:06:42.159537+00	2013-05-02 10:17:56.959496+00
72	33	3	2012-05-22 13:06:42.161376+00	2013-05-02 10:17:56.963671+00
73	34	8	2012-05-22 13:06:42.172617+00	2013-05-02 10:17:56.96736+00
74	34	11	2012-05-22 13:06:42.174455+00	2013-05-02 10:17:56.971115+00
75	35	8	2012-05-22 13:06:42.184261+00	2013-05-02 10:17:56.974857+00
76	35	11	2012-05-22 13:06:42.186233+00	2013-05-02 10:17:56.978548+00
77	36	19	2012-05-22 13:06:42.199454+00	2013-05-02 10:17:56.982344+00
78	36	13	2012-05-22 13:06:42.201391+00	2013-05-02 10:17:56.9857+00
79	37	19	2012-05-22 13:06:42.204344+00	2013-05-02 10:17:56.989417+00
80	37	13	2012-05-22 13:06:42.206547+00	2013-05-02 10:17:56.993093+00
81	38	42	2012-05-22 13:06:42.210246+00	2013-05-02 10:17:56.996814+00
82	38	25	2012-05-22 13:06:42.214161+00	2013-05-02 10:17:57.000506+00
83	39	19	2012-05-22 13:06:42.21717+00	2013-05-02 10:17:57.004266+00
85	39	11	2012-05-22 13:06:42.22131+00	2013-05-02 10:17:57.011153+00
86	40	19	2012-05-22 13:06:42.224242+00	2013-05-02 10:17:57.01515+00
87	40	11	2012-05-22 13:06:42.226066+00	2013-05-02 10:17:57.019001+00
88	41	3	2012-05-22 13:06:42.236134+00	2013-05-02 10:17:57.022731+00
89	41	11	2012-05-22 13:06:42.238039+00	2013-05-02 10:17:57.0264+00
90	42	19	2012-05-22 13:06:42.241056+00	2013-05-02 10:17:57.029556+00
91	42	28	2012-05-22 13:06:42.242951+00	2013-05-02 10:17:57.03327+00
92	43	28	2012-05-22 13:06:42.253055+00	2013-05-02 10:17:57.039177+00
93	43	25	2012-05-22 13:06:42.254823+00	2013-05-02 10:17:57.046547+00
94	44	38	2012-05-22 13:06:42.267946+00	2013-05-02 10:17:57.051901+00
96	45	43	2012-05-22 13:06:42.28131+00	2013-05-02 10:17:57.059779+00
97	45	44	2012-05-22 13:06:42.283258+00	2013-05-02 10:17:57.06363+00
98	45	32	2012-05-22 13:06:42.285224+00	2013-05-02 10:17:57.067517+00
99	46	21	2012-05-22 13:06:42.288182+00	2013-05-02 10:17:57.071203+00
100	46	31	2012-05-22 13:06:42.290023+00	2013-05-02 10:17:57.075242+00
101	47	43	2012-05-22 13:06:42.296394+00	2013-05-02 10:17:57.080008+00
102	47	44	2012-05-22 13:06:42.298288+00	2013-05-02 10:17:57.084185+00
103	47	32	2012-05-22 13:06:42.300164+00	2013-05-02 10:17:57.087916+00
104	48	32	2012-05-22 13:06:42.310444+00	2013-05-02 10:17:57.091638+00
105	48	29	2012-05-22 13:06:42.312341+00	2013-05-02 10:17:57.0956+00
106	48	33	2012-05-22 13:06:42.314244+00	2013-05-02 10:17:57.099621+00
107	49	32	2012-05-22 13:06:42.317281+00	2013-05-02 10:17:57.103353+00
108	49	29	2012-05-22 13:06:42.319178+00	2013-05-02 10:17:57.10715+00
109	49	33	2012-05-22 13:06:42.321091+00	2013-05-02 10:17:57.114708+00
111	50	34	2012-05-22 13:06:42.335233+00	2013-05-02 10:17:57.125276+00
112	50	10	2012-05-22 13:06:42.337171+00	2013-05-02 10:17:57.130094+00
113	51	38	2012-05-22 13:06:42.346942+00	2013-05-02 10:17:57.135951+00
114	51	12	2012-05-22 13:06:42.34884+00	2013-05-02 10:17:57.139706+00
115	52	4	2012-05-22 13:06:42.364169+00	2013-05-02 10:17:57.143409+00
116	52	8	2012-05-22 13:06:42.366063+00	2013-05-02 10:17:57.147012+00
117	52	11	2012-05-22 13:06:42.367832+00	2013-05-02 10:17:57.150763+00
118	1	47	2012-06-20 15:58:42.635835+00	2013-05-02 10:17:57.157176+00
119	17	35	2012-06-20 15:59:49.793222+00	2013-05-02 10:17:57.160932+00
120	27	13	2012-06-20 16:00:46.769399+00	2013-05-02 10:17:57.164738+00
122	45	48	2012-06-21 12:06:09.561802+00	2013-05-02 10:17:57.168258+00
123	47	48	2012-06-21 12:06:22.351109+00	2013-05-02 10:17:57.172023+00
124	46	48	2012-06-21 12:07:24.43935+00	2013-05-02 10:17:57.175849+00
125	56	4	2012-07-03 17:29:05.551345+00	2013-05-02 10:17:57.179983+00
127	56	8	2012-07-03 17:30:09.501482+00	2013-05-02 10:17:57.187544+00
128	56	47	2012-07-03 17:30:23.210345+00	2013-05-02 10:17:57.191167+00
129	57	4	2012-07-06 14:26:47.258837+00	2013-05-02 10:17:57.195088+00
130	57	3	2012-07-06 14:26:47.262462+00	2013-05-02 10:17:57.198802+00
131	51	7	2012-11-01 17:03:17.483264+00	2013-05-02 10:17:57.202549+00
95	44	25	2012-05-22 13:06:42.269895+00	2013-05-02 10:17:57.055692+00
110	50	8	2012-05-22 13:06:42.333283+00	2013-05-02 10:17:57.119974+00
126	56	11	2012-07-03 17:29:27.44319+00	2013-05-02 10:17:57.183755+00
\.


--
-- Data for Name: digipal_allographcomponent_features; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_allographcomponent_features (id, allographcomponent_id, feature_id) FROM stdin;
\.


--
-- Name: digipal_allographcomponent_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_allographcomponent_features_id_seq', 1, false);


--
-- Name: digipal_allographcomponent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_allographcomponent_id_seq', 131, true);


--
-- Data for Name: digipal_alphabet; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_alphabet (id, name, created, modified) FROM stdin;
\.


--
-- Data for Name: digipal_alphabet_hands; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_alphabet_hands (id, alphabet_id, hand_id) FROM stdin;
\.


--
-- Name: digipal_alphabet_hands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_alphabet_hands_id_seq', 1, false);


--
-- Name: digipal_alphabet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_alphabet_id_seq', 1, false);


--
-- Data for Name: digipal_alphabet_ontographs; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_alphabet_ontographs (id, alphabet_id, ontograph_id) FROM stdin;
\.


--
-- Name: digipal_alphabet_ontographs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_alphabet_ontographs_id_seq', 1, false);


--
-- Data for Name: digipal_annotation; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_annotation (id, image_id, cutout, status_id, before_id, graph_id, after_id, vector_id, geo_json, display_note, internal_note, author_id, created, modified, rotation, holes, clientid, type) FROM stdin;
10	2	\N	\N	\N	10	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1075,1500],[1075,1539],[1116,1539],[1116,1500],[1075,1500]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:17:52.290029+00	2017-04-22 17:17:52.290067+00	0	\N	\N	\N
11	2	\N	\N	\N	11	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1241.0322321468,1601.9487215847],[1241.0322321468,1642.9487215847],[1276.0322321468,1642.9487215847],[1276.0322321468,1601.9487215847],[1241.0322321468,1601.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:18:00.792857+00	2017-04-22 17:18:00.792887+00	0	\N	\N	\N
12	2	\N	\N	\N	12	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[776.0322321468,1709.9487215847],[776.0322321468,1750.9487215847],[818.0322321468,1750.9487215847],[818.0322321468,1709.9487215847],[776.0322321468,1709.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:18:10.855784+00	2017-04-22 17:18:10.855814+00	0	\N	\N	\N
13	2	\N	\N	\N	13	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1267.5322321468,1173.9487215847],[1267.5322321468,1207.9487215847],[1312.5322321468,1207.9487215847],[1312.5322321468,1173.9487215847],[1267.5322321468,1173.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:18:49.81144+00	2017-04-22 17:18:49.811459+00	0	\N	\N	\N
14	2	\N	\N	\N	14	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1279.5322321468,813.9487215847],[1279.5322321468,851.9487215847],[1326.5322321468,851.9487215847],[1326.5322321468,813.9487215847],[1279.5322321468,813.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:19:36.298076+00	2017-04-22 17:19:36.29811+00	0	\N	\N	\N
15	2	\N	\N	\N	15	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[762.5322321468,412.9487215847],[762.5322321468,464.9487215847],[805.5322321468,464.9487215847],[805.5322321468,412.9487215847],[762.5322321468,412.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:19:56.670509+00	2017-04-22 17:19:56.670544+00	0	\N	\N	\N
16	2	\N	\N	\N	16	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1074.5322321468,752.9487215847],[1074.5322321468,813.9487215847],[1121.5322321468,813.9487215847],[1121.5322321468,752.9487215847],[1074.5322321468,752.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:20:05.670549+00	2017-04-22 17:20:05.670578+00	0	\N	\N	\N
17	2	\N	\N	\N	17	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1138.5322321468,771.9487215847],[1138.5322321468,822.9487215847],[1175.5322321468,822.9487215847],[1175.5322321468,771.9487215847],[1138.5322321468,771.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:20:18.367209+00	2017-04-22 17:20:18.367255+00	0	\N	\N	\N
18	2	\N	\N	\N	18	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1288.5322321468,558.9487215847],[1288.5322321468,619.9487215847],[1329.5322321468,619.9487215847],[1329.5322321468,558.9487215847],[1288.5322321468,558.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:20:24.111867+00	2017-04-22 17:20:24.111897+00	0	\N	\N	\N
19	2	\N	\N	\N	19	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[708.5322321468,1025.9487215847],[708.5322321468,1063.9487215847],[743.5322321468,1063.9487215847],[743.5322321468,1025.9487215847],[708.5322321468,1025.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:20:48.766457+00	2017-04-22 17:20:48.766483+00	0	\N	\N	\N
20	2	\N	\N	\N	20	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[964.5322321468,1019.9487215847],[964.5322321468,1062.9487215847],[998.5322321468,1062.9487215847],[998.5322321468,1019.9487215847],[964.5322321468,1019.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:20:52.820499+00	2017-04-22 17:20:52.820555+00	0	\N	\N	\N
21	2	\N	\N	\N	21	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1382.5322321468,763.9487215847],[1382.5322321468,803.9487215847],[1428.5322321468,803.9487215847],[1428.5322321468,763.9487215847],[1382.5322321468,763.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:21:28.407733+00	2017-04-22 17:21:28.407755+00	0	\N	\N	\N
22	2	\N	\N	\N	22	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[917.5322321468,680.9487215847],[917.5322321468,715.9487215847],[957.5322321468,715.9487215847],[957.5322321468,680.9487215847],[917.5322321468,680.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:21:33.128734+00	2017-04-22 17:21:33.128753+00	0	\N	\N	\N
23	2	\N	\N	\N	23	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[768.5322321468,569.9487215847],[768.5322321468,607.9487215847],[805.5322321468,607.9487215847],[805.5322321468,569.9487215847],[768.5322321468,569.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:21:37.446502+00	2017-04-22 17:21:37.446536+00	0	\N	\N	\N
24	2	\N	\N	\N	24	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1162.5322321468,713.9487215847],[1162.5322321468,769.9487215847],[1196.5322321468,769.9487215847],[1196.5322321468,713.9487215847],[1162.5322321468,713.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:22:00.018893+00	2017-04-22 17:22:00.018928+00	0	\N	\N	\N
25	2	\N	\N	\N	25	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[884.5322321468,549.9487215847],[884.5322321468,607.9487215847],[923.5322321468,607.9487215847],[923.5322321468,549.9487215847],[884.5322321468,549.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:22:13.888751+00	2017-04-22 17:22:13.888803+00	0	\N	\N	\N
26	2	\N	\N	\N	26	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1036.5322321468,869.9487215847],[1036.5322321468,915.9487215847],[1079.5322321468,915.9487215847],[1079.5322321468,869.9487215847],[1036.5322321468,869.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:22:23.108641+00	2017-04-22 17:22:23.108663+00	0	\N	\N	\N
27	2	\N	\N	\N	27	\N		{'type':'Feature','properties':{'saved':0},'geometry':{'type':'Polygon','coordinates':[[[1438.5322321468,859.9487215847],[1438.5322321468,904.9487215847],[1379.5322321468,904.9487215847],[1379.5322321468,859.9487215847],[1438.5322321468,859.9487215847]]]},'crs':{'type':'name','properties':{'name':'EPSG:3785'}}}			1	2017-04-22 17:22:36.745326+00	2017-04-22 17:22:36.745351+00	0	\N	\N	\N
28	2	\N	\N	\N	\N	\N		{"geometry": {"type": "Polygon", "coordinates": [[[818.965207933044, 1422.3657398181945], [818.965207933044, 1342.4571745885903], [1229.4046566123734, 1342.4571745885903], [1229.4046566123734, 1422.3657398181945], [818.965207933044, 1422.3657398181945]]]}, "type": "Feature", "properties": {"elementid": [["", "person"], ["type", "name"], ["@text", "salmus-david"]]}}	\N	\N	1	2017-08-29 20:50:03.936708+00	2017-08-29 20:50:07.957141+00	0	\N	1504039803889:505	text
\.


--
-- Name: digipal_annotation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_annotation_id_seq', 28, true);


--
-- Data for Name: digipal_apitransform; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_apitransform (id, title, slug, template, description, created, modified, mimetype, sample_request, webpage) FROM stdin;
\.


--
-- Name: digipal_apitransform_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_apitransform_id_seq', 1, false);


--
-- Data for Name: digipal_appearance; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_appearance (id, legacy_id, text, sort_order, description, created, modified) FROM stdin;
\.


--
-- Name: digipal_appearance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_appearance_id_seq', 1, false);


--
-- Data for Name: digipal_archive; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_archive (id, legacy_id, content_type_id, object_id, historical_item_id, dubitable, created, modified) FROM stdin;
\.


--
-- Name: digipal_archive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_archive_id_seq', 1, false);


--
-- Data for Name: digipal_aspect; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_aspect (id, name, created, modified) FROM stdin;
\.


--
-- Data for Name: digipal_aspect_features; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_aspect_features (id, aspect_id, feature_id) FROM stdin;
\.


--
-- Name: digipal_aspect_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_aspect_features_id_seq', 1, false);


--
-- Name: digipal_aspect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_aspect_id_seq', 1, false);


--
-- Data for Name: digipal_authenticitycategory; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_authenticitycategory (id, name, slug, created, modified) FROM stdin;
\.


--
-- Name: digipal_authenticitycategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_authenticitycategory_id_seq', 1, false);


--
-- Data for Name: digipal_carouselitem; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_carouselitem (id, link, image, image_alt, image_title, sort_order, title, created, modified, image_file) FROM stdin;
1					1	Annotate scripts according to your alphabet	2017-04-21 21:01:51.55322+00	2017-04-21 21:01:51.553251+00	uploads/images/MultiPal_Screenshot.jpg
2					2	Manipulate images in the Lightbox	2017-04-21 21:02:13.277753+00	2017-08-29 20:01:39.932795+00	uploads/images/3._Lightbox_Screenshot-_Eadwig.png
\.


--
-- Name: digipal_carouselitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_carouselitem_id_seq', 2, true);


--
-- Data for Name: digipal_cataloguenumber; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_cataloguenumber (id, historical_item_id, source_id, number, created, modified, text_id, url, number_slug) FROM stdin;
1	2	2	4	2017-04-22 17:23:59.940162+00	2017-04-22 17:23:59.940187+00	\N		4
\.


--
-- Name: digipal_cataloguenumber_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_cataloguenumber_id_seq', 1, true);


--
-- Data for Name: digipal_category; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_category (id, name, sort_order, created, modified) FROM stdin;
\.


--
-- Name: digipal_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_category_id_seq', 1, false);


--
-- Data for Name: digipal_character; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_character (id, name, unicode_point, ontograph_id, created, modified, form_id) FROM stdin;
1	abbrev. stroke	00af	1	2012-05-22 13:06:41.772+00	2013-05-02 10:17:56.293+00	1
2	wynn	01bf	2	2012-05-22 13:06:41.783+00	2012-05-22 13:06:41.79+00	2
3	./	f1f0	3	2012-05-22 13:06:41.795+00	2012-05-22 13:06:41.802+00	1
4	ligature	ligature	4	2012-05-22 13:06:41.808+00	2012-05-22 13:06:41.813+00	1
5	accent	accent	5	2012-05-22 13:06:41.819+00	2012-05-22 13:06:41.824+00	1
6	.	.	6	2012-05-22 13:06:41.829+00	2012-05-22 13:06:41.834+00	1
7	7	204a	7	2012-05-22 13:06:41.841+00	2012-05-22 13:06:41.848+00	1
8	;	;	3	2012-05-22 13:06:41.852+00	2012-05-22 13:06:41.863+00	1
9	?	2e33	8	2012-05-22 13:06:41.868+00	2012-05-22 13:06:41.877+00	1
10	N	N	9	2012-05-22 13:06:41.882+00	2012-05-22 13:06:41.888+00	3
11	a	a	10	2012-05-22 13:06:41.896+00	2012-05-22 13:06:41.917+00	2
12	&	&	11	2012-05-22 13:06:41.922+00	2012-05-22 13:06:41.931+00	1
13	c	c	12	2012-05-22 13:06:41.936+00	2012-05-22 13:06:41.943+00	2
14	b	b	13	2012-05-22 13:06:41.948+00	2012-05-22 13:06:41.959+00	2
15	e	e	14	2012-05-22 13:06:41.964+00	2012-05-22 13:06:41.972+00	2
16	d	d	15	2012-05-22 13:06:41.977+00	2012-05-22 13:06:41.989+00	2
17	g	g	16	2012-05-22 13:06:41.994+00	2012-05-22 13:06:42.01+00	2
18	æ	00e6	17	2012-05-22 13:06:42.015+00	2012-05-22 13:06:42.051+00	2
19	i	i	18	2012-05-22 13:06:42.056+00	2012-05-22 13:06:42.064+00	2
20	h	h	19	2012-05-22 13:06:42.069+00	2012-05-22 13:06:42.076+00	2
21	k	k	20	2012-05-22 13:06:42.081+00	2012-05-22 13:06:42.089+00	2
22	f	f	21	2012-05-22 13:06:42.097+00	2012-05-22 13:06:42.113+00	2
23	m	m	22	2012-05-22 13:06:42.118+00	2012-05-22 13:06:42.127+00	2
24	l	l	23	2012-05-22 13:06:42.132+00	2012-05-22 13:06:42.137+00	2
25	o	o	24	2012-05-22 13:06:42.142+00	2012-05-22 13:06:42.148+00	2
26	n	n	9	2012-05-22 13:06:42.156+00	2012-05-22 13:06:42.163+00	2
27	q	q	25	2012-05-22 13:06:42.169+00	2012-05-22 13:06:42.176+00	2
28	p	p	26	2012-05-22 13:06:42.181+00	2012-05-22 13:06:42.188+00	2
29	s	s	27	2012-05-22 13:06:42.192+00	2012-05-22 13:06:42.227+00	2
30	r	r	28	2012-05-22 13:06:42.232+00	2012-05-22 13:06:42.245+00	2
31	u	u	29	2012-05-22 13:06:42.25+00	2012-05-22 13:06:42.26+00	2
32	t	t	30	2012-05-22 13:06:42.264+00	2012-05-22 13:06:42.271+00	2
33	y	y	31	2012-05-22 13:06:42.277+00	2012-05-22 13:06:42.302+00	2
34	x	x	32	2012-05-22 13:06:42.307+00	2012-05-22 13:06:42.322+00	2
35	eth	00f0	33	2012-05-22 13:06:42.33+00	2012-05-22 13:06:42.339+00	2
36	z	z	34	2012-05-22 13:06:42.344+00	2012-05-22 13:06:42.356+00	2
37	thorn	00fe	35	2012-05-22 13:06:42.361+00	2012-05-22 13:06:42.369+00	2
38	thæt	U+A765	36	2012-07-03 17:27:55.75+00	2012-07-03 17:27:55.751+00	2
\.


--
-- Data for Name: digipal_character_components; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_character_components (id, character_id, component_id) FROM stdin;
1	38	11
2	38	47
3	38	4
4	38	8
\.


--
-- Name: digipal_character_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_character_components_id_seq', 4, true);


--
-- Name: digipal_character_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_character_id_seq', 38, true);


--
-- Data for Name: digipal_characterform; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_characterform (id, name) FROM stdin;
1	n/a
2	minuscule
3	majuscule
\.


--
-- Name: digipal_characterform_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_characterform_id_seq', 3, true);


--
-- Data for Name: digipal_collation; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_collation (id, historical_item_id, fragment, leaves, front_flyleaves, back_flyleaves, created, modified) FROM stdin;
\.


--
-- Name: digipal_collation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_collation_id_seq', 1, false);


--
-- Data for Name: digipal_component; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_component (id, name, created, modified) FROM stdin;
10	cross stroke (eth)	2012-05-22 13:06:40.925792+00	2012-07-03 15:37:10.207725+00
2	a-component	2012-05-22 13:06:40.710385+00	2012-05-22 13:06:40.71317+00
17	tail (g)	2012-05-22 13:06:41.08283+00	2012-06-20 16:11:20.841117+00
5	back	2012-05-22 13:06:40.81795+00	2012-05-22 13:06:40.832836+00
6	body (Caroline g)	2012-05-22 13:06:40.834849+00	2012-05-22 13:06:40.837707+00
9	comma	2012-05-22 13:06:40.920907+00	2012-05-22 13:06:40.923802+00
27	body (g)	2012-05-22 13:06:41.3293+00	2012-09-17 10:26:52.53905+00
31	right-hand stroke (round y)	2012-05-22 13:06:41.421942+00	2012-11-01 14:31:45.136969+00
14	e-component	2012-05-22 13:06:41.026918+00	2012-05-22 13:06:41.029757+00
16	foot	2012-05-22 13:06:41.055798+00	2012-05-22 13:06:41.080932+00
15	eye	2012-05-22 13:06:41.031672+00	2012-11-28 17:25:38.518068+00
35	tongue	2012-05-22 13:06:41.535713+00	2012-11-28 17:26:35.979309+00
19	hook	2012-05-22 13:06:41.156159+00	2012-05-22 13:06:41.210228+00
20	join	2012-05-22 13:06:41.212175+00	2012-05-22 13:06:41.221195+00
8	bowl	2012-05-22 13:06:40.874882+00	2012-11-28 17:39:16.973+00
22	lobe	2012-05-22 13:06:41.230078+00	2012-11-28 17:40:03.517115+00
21	left-hand curve (y)	2012-05-22 13:06:41.223113+00	2012-06-20 16:17:11.487192+00
23	lower bowl (&)	2012-05-22 13:06:41.249828+00	2012-06-20 16:17:22.774944+00
24	lower branch (k)	2012-05-22 13:06:41.263575+00	2012-06-20 16:17:29.123018+00
30	point	2012-05-22 13:06:41.408806+00	2012-05-22 13:06:41.419871+00
29	upper right branch (x)	2012-05-22 13:06:41.386062+00	2012-06-20 16:19:15.629308+00
39	up stroke (punct. elev.)	2012-05-22 13:06:41.64859+00	2012-06-20 16:19:53.688071+00
40	upper bowl	2012-05-22 13:06:41.662352+00	2012-05-22 13:06:41.673526+00
41	upper branch	2012-05-22 13:06:41.675494+00	2012-05-22 13:06:41.683972+00
37	top curve (punct. interrog.)	2012-05-22 13:06:41.605353+00	2012-06-20 16:20:31.042112+00
46	accent stroke	2012-06-20 16:06:04.961021+00	2012-06-20 16:06:04.961048+00
12	diagonal stroke (z)	2012-05-22 13:06:41.01222+00	2012-06-20 16:09:30.503402+00
18	head (a)	2012-05-22 13:06:41.132172+00	2012-06-20 16:09:51.74514+00
26	mid-arch (m)	2012-05-22 13:06:41.304813+00	2012-06-20 16:56:04.739687+00
42	upper curve	2012-05-22 13:06:41.686146+00	2012-06-20 16:58:06.531389+00
48	dot (y)	2012-06-21 12:05:27.521566+00	2012-06-21 12:06:32.551282+00
7	bottom stroke (z)	2012-05-22 13:06:40.839731+00	2012-06-21 15:24:10.097284+00
13	downstroke	2012-05-22 13:06:41.02225+00	2012-06-21 15:24:36.919356+00
1	downstroke (7)	2012-05-22 13:06:40.6602+00	2012-06-21 15:44:05.514273+00
3	arch	2012-05-22 13:06:40.715151+00	2012-06-26 15:59:27.181688+00
11	descender	2012-05-22 13:06:40.965729+00	2012-06-26 16:00:33.075678+00
34	stem	2012-05-22 13:06:41.475556+00	2012-06-26 16:00:46.805181+00
33	lower left branch (x)	2012-05-22 13:06:41.447895+00	2012-06-26 16:07:11.988315+00
44	lower right branch (y)	2012-05-22 13:06:41.713958+00	2012-06-26 16:08:33.361176+00
45	tail (y)	2012-05-22 13:06:41.730474+00	2012-06-26 16:08:52.46032+00
43	upper left branch (y)	2012-05-22 13:06:41.703395+00	2012-06-26 16:09:04.474524+00
32	main stroke	2012-05-22 13:06:41.432061+00	2012-06-27 13:22:10.03554+00
4	ascender	2012-05-22 13:06:40.750793+00	2012-06-29 13:22:56.771894+00
28	minim	2012-05-22 13:06:41.351538+00	2012-06-29 13:23:11.910374+00
47	abbrev. stroke	2012-06-20 17:17:34.945366+00	2012-07-03 12:35:03.569049+00
38	top stroke	2012-05-22 13:06:41.61568+00	2012-07-03 13:16:49.096458+00
25	lower curve	2012-05-22 13:06:41.278061+00	2012-07-03 14:44:35.948805+00
\.


--
-- Data for Name: digipal_component_features; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_component_features (id, component_id, feature_id, set_by_default, created, modified) FROM stdin;
491	26	37	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
492	26	39	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
493	26	40	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
494	26	41	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
495	26	123	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
496	26	92	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
948	10	43	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
949	10	104	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
950	10	75	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
951	10	76	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
952	10	52	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
953	10	55	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
954	10	56	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
955	10	57	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
535	42	16	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
536	42	5	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
537	42	85	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
538	42	87	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
418	21	22	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
421	24	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
422	24	108	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
809	32	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
810	32	131	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
38	5	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
39	5	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
40	5	87	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
41	5	25	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
811	32	132	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
812	32	75	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
445	29	16	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
446	29	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
447	29	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
448	29	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
813	32	22	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
814	32	56	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
815	32	31	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
449	29	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
452	39	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
453	39	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
660	7	128	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
661	7	33	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
662	7	4	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
663	7	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
664	7	44	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
665	7	78	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
666	7	112	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
667	7	86	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
668	7	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
669	7	122	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
845	28	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
846	28	99	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
847	28	74	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
848	28	14	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
90	16	13	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
91	16	9	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
92	16	57	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
93	16	6	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
94	16	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
95	16	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
849	28	47	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
850	28	20	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
851	28	117	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
852	28	118	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
853	28	120	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
854	28	58	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
855	28	124	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
856	28	94	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
113	19	7	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
114	19	44	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
115	19	24	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
116	19	52	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
117	19	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
118	19	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
119	19	37	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
120	19	71	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
121	19	64	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
122	19	65	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
123	19	66	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
124	19	42	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
125	19	67	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
126	19	68	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
127	19	53	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
128	20	24	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
129	20	73	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
867	47	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
868	47	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
869	47	61	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
870	47	86	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
871	47	55	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
872	47	56	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
873	47	57	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
874	47	122	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
875	47	28	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
876	47	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
877	47	62	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
878	47	31	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
617	48	125	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
169	30	78	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
170	30	17	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
171	30	16	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
618	48	6	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
935	25	129	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
936	25	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
937	25	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
938	25	134	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
939	25	135	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
940	25	11	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
738	11	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
739	11	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
740	11	99	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
741	11	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
742	11	8	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
743	11	10	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
744	11	109	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
745	11	46	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
746	11	47	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
747	11	48	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
748	11	72	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
749	11	115	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
750	11	21	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
751	11	118	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
752	11	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
753	11	27	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
754	11	124	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
755	11	74	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
756	11	94	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
757	11	117	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
793	44	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
794	44	131	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
795	44	132	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
796	44	5	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
797	44	16	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
798	44	54	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
805	43	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
806	43	131	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
807	43	132	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
808	43	54	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
941	25	130	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
942	25	117	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
943	25	87	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
944	25	121	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
945	25	26	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
946	25	59	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
947	25	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
826	4	19	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
827	4	98	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
828	4	99	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
829	4	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
830	4	72	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
831	4	126	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
832	4	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
833	4	46	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
834	4	48	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
835	4	115	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
836	4	21	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
837	4	118	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
838	4	120	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
839	4	58	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
956	10	28	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
957	10	61	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
958	10	62	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
959	10	31	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
840	4	27	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
841	4	124	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
842	4	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
843	4	94	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
844	4	117	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
879	38	33	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
880	38	5	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
881	38	45	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
882	38	61	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
883	38	16	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
884	38	117	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
885	38	86	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
886	38	55	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
887	38	56	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
888	38	122	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
889	38	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
890	38	62	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
891	38	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
229	40	24	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
230	40	73	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
231	40	93	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
232	41	111	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
233	41	108	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
974	27	1	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
975	27	135	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
976	27	14	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
977	27	49	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
978	27	50	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
979	27	51	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
980	27	60	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
981	27	93	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
982	31	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
983	31	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
670	13	128	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
671	13	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
672	13	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
673	13	99	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
674	13	4	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
675	13	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
676	13	72	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
677	13	109	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
678	13	78	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
679	13	47	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
680	13	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
689	1	128	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
690	1	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
691	1	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
692	1	99	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
693	1	4	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
694	1	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
695	1	8	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
696	1	10	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
697	1	109	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
698	1	78	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
699	1	47	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
700	1	72	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
984	15	24	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
985	15	44	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
986	15	82	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
987	15	52	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
988	15	96	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
989	35	64	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
701	1	115	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
702	1	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
703	1	74	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
726	3	123	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
727	3	37	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
728	3	70	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
729	3	39	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
730	3	40	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
731	3	41	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
732	3	74	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
733	3	7	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
734	3	47	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
990	35	33	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
991	35	66	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
992	35	67	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
993	35	68	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
994	35	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
995	35	102	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
996	35	65	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
997	35	63	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
998	35	108	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
999	35	79	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
735	3	88	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
736	3	91	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
737	3	127	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
758	34	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
759	34	3	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
760	34	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
761	34	106	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
762	34	107	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
763	34	108	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
764	34	110	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
765	34	18	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
766	34	115	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
767	34	20	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
768	34	117	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
769	34	22	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
333	46	56	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
334	46	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
335	46	31	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
336	46	28	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
337	46	55	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
338	12	19	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
339	12	115	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
340	12	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
341	12	22	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
342	18	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
343	18	7	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
344	18	20	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
345	18	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
346	18	5	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
351	17	2	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
352	17	73	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
353	17	87	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
354	17	77	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
355	17	14	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
356	17	79	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
357	17	80	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
358	17	81	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
359	17	82	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
360	17	105	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
361	17	119	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
362	17	26	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
770	34	23	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
771	34	116	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
772	34	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
773	34	28	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
419	23	88	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
420	23	93	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
774	34	31	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
785	33	128	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
786	33	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
787	33	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
788	33	4	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
789	33	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
790	33	78	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
454	37	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
455	37	69	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
791	33	56	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
792	33	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
799	45	97	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
800	45	34	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
801	45	131	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
802	45	132	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
803	45	22	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
804	45	54	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1000	35	86	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1001	35	57	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1002	35	90	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1003	35	111	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1004	35	101	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1005	8	100	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1006	8	25	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1007	8	134	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1008	8	136	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1009	8	73	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1010	8	11	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1011	8	46	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1012	8	82	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1013	8	84	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1014	8	87	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1015	8	121	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1016	8	59	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1017	8	29	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1018	8	30	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1019	8	95	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1020	22	100	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1021	22	14	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1022	22	82	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1023	22	87	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1024	22	25	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
1025	22	93	f	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
\.


--
-- Name: digipal_component_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_component_features_id_seq', 1025, true);


--
-- Name: digipal_component_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_component_id_seq', 48, true);


--
-- Data for Name: digipal_county; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_county (id, legacy_id, name, created, modified) FROM stdin;
1	1	Bedfordshire	2012-05-22 13:06:44.564237+00	2012-05-22 13:06:44.564253+00
2	5	Berkshire	2012-05-22 13:06:44.566169+00	2012-05-22 13:06:44.566185+00
3	9	Buckinghamshire	2012-05-22 13:06:44.567814+00	2012-05-22 13:06:44.56783+00
4	13	Cambridgeshire	2012-05-22 13:06:44.569636+00	2012-05-22 13:06:44.569652+00
5	17	Cheshire	2012-05-22 13:06:44.571328+00	2012-05-22 13:06:44.571344+00
6	21	Cornwall	2012-05-22 13:06:44.572995+00	2012-05-22 13:06:44.573011+00
7	25	Cumberland	2012-05-22 13:06:44.574907+00	2012-05-22 13:06:44.574922+00
8	29	Derbyshire	2012-05-22 13:06:44.576836+00	2012-05-22 13:06:44.576851+00
9	33	Devon	2012-05-22 13:06:44.578574+00	2012-05-22 13:06:44.578589+00
10	37	Dorset	2012-05-22 13:06:44.580185+00	2012-05-22 13:06:44.580201+00
11	40	Durham	2012-05-22 13:06:44.582155+00	2012-05-22 13:06:44.582171+00
12	2	Essex	2012-05-22 13:06:44.583916+00	2012-05-22 13:06:44.583932+00
13	6	Gloucestershire	2012-05-22 13:06:44.585888+00	2012-05-22 13:06:44.585904+00
14	10	Hampshire	2012-05-22 13:06:44.587925+00	2012-05-22 13:06:44.587941+00
15	14	Herefordshire	2012-05-22 13:06:44.589768+00	2012-05-22 13:06:44.589783+00
16	18	Hertfordshire	2012-05-22 13:06:44.591538+00	2012-05-22 13:06:44.591554+00
17	22	Huntingdonshire	2012-05-22 13:06:44.593249+00	2012-05-22 13:06:44.593265+00
18	26	Isle of Wight	2012-05-22 13:06:44.594992+00	2012-05-22 13:06:44.595007+00
19	30	Kent	2012-05-22 13:06:44.597093+00	2012-05-22 13:06:44.597109+00
20	34	Lancashire	2012-05-22 13:06:44.598767+00	2012-05-22 13:06:44.598782+00
21	38	Leicestershire	2012-05-22 13:06:44.600436+00	2012-05-22 13:06:44.600451+00
22	41	Lincolnshire	2012-05-22 13:06:44.602129+00	2012-05-22 13:06:44.602145+00
23	3	Middlesex	2012-05-22 13:06:44.603816+00	2012-05-22 13:06:44.60383+00
24	7	Norfolk	2012-05-22 13:06:44.605567+00	2012-05-22 13:06:44.605582+00
25	11	Northamptonshire	2012-05-22 13:06:44.607276+00	2012-05-22 13:06:44.607291+00
26	15	Northumberland	2012-05-22 13:06:44.609006+00	2012-05-22 13:06:44.609022+00
27	19	Nottinghamshire	2012-05-22 13:06:44.61067+00	2012-05-22 13:06:44.610685+00
28	23	Oxfordshire	2012-05-22 13:06:44.61225+00	2012-05-22 13:06:44.612265+00
29	27	Rutland	2012-05-22 13:06:44.613888+00	2012-05-22 13:06:44.613904+00
30	31	Shropshire	2012-05-22 13:06:44.615582+00	2012-05-22 13:06:44.615598+00
31	35	Somerset	2012-05-22 13:06:44.617288+00	2012-05-22 13:06:44.617304+00
32	39	Staffordshire	2012-05-22 13:06:44.619023+00	2012-05-22 13:06:44.619038+00
33	42	Suffolk	2012-05-22 13:06:44.620756+00	2012-05-22 13:06:44.620772+00
34	4	Surrey	2012-05-22 13:06:44.625058+00	2012-05-22 13:06:44.625074+00
35	8	Sussex	2012-05-22 13:06:44.626787+00	2012-05-22 13:06:44.626802+00
36	12	Warwickshire	2012-05-22 13:06:44.628546+00	2012-05-22 13:06:44.628561+00
37	16	Westmorland	2012-05-22 13:06:44.630286+00	2012-05-22 13:06:44.630302+00
38	20	Wiltshire	2012-05-22 13:06:44.632034+00	2012-05-22 13:06:44.632049+00
39	24	Worcestershire	2012-05-22 13:06:44.633891+00	2012-05-22 13:06:44.633906+00
40	43	Yorkshire	2012-05-22 13:06:44.635592+00	2012-05-22 13:06:44.635608+00
41	28	Yorkshire ER	2012-05-22 13:06:44.637279+00	2012-05-22 13:06:44.637294+00
42	32	Yorkshire NR	2012-05-22 13:06:44.639062+00	2012-05-22 13:06:44.639078+00
43	36	Yorkshire WR	2012-05-22 13:06:44.640852+00	2012-05-22 13:06:44.640867+00
\.


--
-- Name: digipal_county_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_county_id_seq', 43, true);


--
-- Data for Name: digipal_currentitem; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_currentitem (id, legacy_id, repository_id, shelfmark, description, display_label, created, modified) FROM stdin;
2	\N	2	Ff.1.23		CUL Ff.1.23	2017-04-22 17:03:21.551431+00	2017-04-22 17:03:21.551467+00
\.


--
-- Name: digipal_currentitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_currentitem_id_seq', 2, true);


--
-- Data for Name: digipal_currentitem_owners; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_currentitem_owners (id, currentitem_id, owner_id) FROM stdin;
\.


--
-- Name: digipal_currentitem_owners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_currentitem_owners_id_seq', 1, false);


--
-- Data for Name: digipal_date; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_date (id, legacy_id, date, sort_order, weight, band, additional_band, post_conquest, s_xi, min_weight, max_weight, created, modified, legacy_reference, evidence) FROM stdin;
1	\N	saec. xi1/4	\N	1012.5	\N	\N	\N	\N	1000	1025	2017-04-22 17:10:21.76753+00	2017-04-22 17:10:21.76756+00		
\.


--
-- Name: digipal_date_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_date_id_seq', 1, true);


--
-- Data for Name: digipal_dateevidence; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_dateevidence (id, legacy_id, hand_id, date_id, date_description, reference_id, evidence, created, modified, historical_item_id, is_firm_date) FROM stdin;
\.


--
-- Name: digipal_dateevidence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_dateevidence_id_seq', 1, false);


--
-- Data for Name: digipal_decoration; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_decoration (id, historical_item_id, illustrated, decorated, illuminated, num_colours, colours, num_inks, inks, style, description, catalogue_references, created, modified) FROM stdin;
\.


--
-- Name: digipal_decoration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_decoration_id_seq', 1, false);


--
-- Data for Name: digipal_description; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_description (id, historical_item_id, source_id, description, created, modified, text_id, comments, summary) FROM stdin;
1	2	1	<p>Cambridge University Library MS Ff.1.23, known as the&nbsp;<em>Winchcombe Psalter</em>, principally comprises a copy of the Psalms in Latin and Old English, dated between 1025 and 1050. In addition, the manuscript contains two sets of prayers on folios&nbsp;4r&nbsp;and&nbsp;276r-281v); Canticles, on folios&nbsp;251r-274r, and a Litany (folios&nbsp;274r-276r). A sixteenth-century table of incipits has been added on folios&nbsp;2v-3r. [For the full description see&nbsp;<a href="http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/">http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/</a>]</p>\r\n<p>&nbsp;</p>	2017-04-22 17:05:45.77023+00	2017-04-22 17:07:36.54292+00	\N		
\.


--
-- Name: digipal_description_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_description_id_seq', 1, true);


--
-- Data for Name: digipal_feature; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_feature (id, name, created, modified) FROM stdin;
1	3-shaped	2012-05-22 13:06:40.403469+00	2012-05-22 13:06:40.403486+00
2	3/4 closed	2012-05-22 13:06:40.405797+00	2012-05-22 13:06:40.405813+00
4	above baseline	2012-05-22 13:06:40.40958+00	2012-05-22 13:06:40.409596+00
6	absent	2012-05-22 13:06:40.413159+00	2012-05-22 13:06:40.413175+00
7	angled	2012-05-22 13:06:40.414981+00	2012-05-22 13:06:40.414998+00
8	angled back	2012-05-22 13:06:40.416911+00	2012-05-22 13:06:40.416927+00
9	angled down	2012-05-22 13:06:40.418824+00	2012-05-22 13:06:40.41884+00
10	angled forward	2012-05-22 13:06:40.421046+00	2012-05-22 13:06:40.421062+00
13	angled up	2012-05-22 13:06:40.426778+00	2012-05-22 13:06:40.426794+00
14	angular	2012-05-22 13:06:40.428749+00	2012-05-22 13:06:40.428765+00
17	at mid-height	2012-05-22 13:06:40.434433+00	2012-05-22 13:06:40.434449+00
18	back vertical	2012-05-22 13:06:40.43623+00	2012-05-22 13:06:40.436246+00
19	backward-leaning	2012-05-22 13:06:40.438122+00	2012-05-22 13:06:40.438138+00
20	backward-reaching	2012-05-22 13:06:40.440071+00	2012-05-22 13:06:40.440087+00
21	barbed	2012-05-22 13:06:40.441903+00	2012-05-22 13:06:40.441919+00
22	bilinear	2012-05-22 13:06:40.443754+00	2012-05-22 13:06:40.443771+00
23	broken	2012-05-22 13:06:40.445503+00	2012-05-22 13:06:40.445519+00
24	bulging	2012-05-22 13:06:40.44729+00	2012-05-22 13:06:40.447306+00
25	c-shaped	2012-05-22 13:06:40.448957+00	2012-05-22 13:06:40.448973+00
26	closed	2012-05-22 13:06:40.450615+00	2012-05-22 13:06:40.45063+00
27	clubbed	2012-05-22 13:06:40.452337+00	2012-05-22 13:06:40.452354+00
28	concave down	2012-05-22 13:06:40.453989+00	2012-05-22 13:06:40.454005+00
29	concave left	2012-05-22 13:06:40.455669+00	2012-05-22 13:06:40.455685+00
30	concave right	2012-05-22 13:06:40.461418+00	2012-05-22 13:06:40.461434+00
31	concave up	2012-05-22 13:06:40.463134+00	2012-05-22 13:06:40.46315+00
33	convex	2012-05-22 13:06:40.466536+00	2012-05-22 13:06:40.466552+00
34	curved	2012-05-22 13:06:40.468214+00	2012-05-22 13:06:40.46823+00
35	curved down	2012-05-22 13:06:40.469977+00	2012-05-22 13:06:40.469993+00
36	curved up	2012-05-22 13:06:40.471764+00	2012-05-22 13:06:40.47178+00
37	deeply split	2012-05-22 13:06:40.473433+00	2012-05-22 13:06:40.473449+00
38	dotted	2012-05-22 13:06:40.475117+00	2012-05-22 13:06:40.475133+00
39	downstroke rounded	2012-05-22 13:06:40.476923+00	2012-05-22 13:06:40.476939+00
40	downstroke turned in	2012-05-22 13:06:40.478761+00	2012-05-22 13:06:40.478777+00
41	downstroke turned out	2012-05-22 13:06:40.480592+00	2012-05-22 13:06:40.480608+00
42	false ligature with t	2012-05-22 13:06:40.482398+00	2012-05-22 13:06:40.482414+00
43	flagpole	2012-05-22 13:06:40.484202+00	2012-05-22 13:06:40.484218+00
44	flat	2012-05-22 13:06:40.485994+00	2012-05-22 13:06:40.486009+00
45	flat-shaped	2012-05-22 13:06:40.487698+00	2012-05-22 13:06:40.487715+00
46	flat-topped	2012-05-22 13:06:40.489406+00	2012-05-22 13:06:40.489422+00
47	foot	2012-05-22 13:06:40.491197+00	2012-05-22 13:06:40.491213+00
49	hangs from left	2012-05-22 13:06:40.498801+00	2012-05-22 13:06:40.498817+00
50	hangs from middle	2012-05-22 13:06:40.500688+00	2012-05-22 13:06:40.500704+00
51	hangs from right	2012-05-22 13:06:40.502606+00	2012-05-22 13:06:40.502622+00
52	high	2012-05-22 13:06:40.50446+00	2012-05-22 13:06:40.504476+00
53	high wedge	2012-05-22 13:06:40.506266+00	2012-05-22 13:06:40.506281+00
55	hooked down	2012-05-22 13:06:40.509635+00	2012-05-22 13:06:40.509652+00
56	hooked up	2012-05-22 13:06:40.511293+00	2012-05-22 13:06:40.511309+00
57	horizontal	2012-05-22 13:06:40.513254+00	2012-05-22 13:06:40.51327+00
59	horned	2012-05-22 13:06:40.517054+00	2012-05-22 13:06:40.51707+00
60	large	2012-05-22 13:06:40.518999+00	2012-05-22 13:06:40.519015+00
61	left hooked down	2012-05-22 13:06:40.520889+00	2012-05-22 13:06:40.520905+00
62	left hooked up	2012-05-22 13:06:40.522768+00	2012-05-22 13:06:40.522784+00
63	ligatured	2012-05-22 13:06:40.524716+00	2012-05-22 13:06:40.524732+00
64	ligatured with f	2012-05-22 13:06:40.526496+00	2012-05-22 13:06:40.526512+00
65	ligatured with s	2012-05-22 13:06:40.528384+00	2012-05-22 13:06:40.528401+00
66	ligatured with t	2012-05-22 13:06:40.530393+00	2012-05-22 13:06:40.530409+00
67	ligatured with descender	2012-05-22 13:06:40.532228+00	2012-05-22 13:06:40.532245+00
68	ligatured with minim	2012-05-22 13:06:40.534134+00	2012-05-22 13:06:40.53415+00
69	long	2012-05-22 13:06:40.536018+00	2012-05-22 13:06:40.536034+00
70	long foot	2012-05-22 13:06:40.537902+00	2012-05-22 13:06:40.537919+00
71	looped	2012-05-22 13:06:40.539705+00	2012-05-22 13:06:40.539721+00
72	minim-length	2012-05-22 13:06:40.54158+00	2012-05-22 13:06:40.541596+00
73	narrow	2012-05-22 13:06:40.54344+00	2012-05-22 13:06:40.543456+00
76	not through	2012-05-22 13:06:40.548916+00	2012-05-22 13:06:40.548932+00
78	on baseline	2012-05-22 13:06:40.556155+00	2012-05-22 13:06:40.556171+00
79	on left	2012-05-22 13:06:40.55799+00	2012-05-22 13:06:40.558005+00
80	on middle	2012-05-22 13:06:40.559764+00	2012-05-22 13:06:40.55978+00
81	on right	2012-05-22 13:06:40.561569+00	2012-05-22 13:06:40.561585+00
82	open	2012-05-22 13:06:40.563449+00	2012-05-22 13:06:40.563464+00
84	point-topped	2012-05-22 13:06:40.567093+00	2012-05-22 13:06:40.567108+00
85	pointed	2012-05-22 13:06:40.569698+00	2012-05-22 13:06:40.569714+00
86	rising	2012-05-22 13:06:40.571493+00	2012-05-22 13:06:40.571509+00
87	round	2012-05-22 13:06:40.573298+00	2012-05-22 13:06:40.573314+00
88	rounded	2012-05-22 13:06:40.575237+00	2012-05-22 13:06:40.575253+00
89	s-shaped	2012-05-22 13:06:40.577131+00	2012-05-22 13:06:40.577147+00
90	short	2012-05-22 13:06:40.579082+00	2012-05-22 13:06:40.579098+00
91	short foot	2012-05-22 13:06:40.581024+00	2012-05-22 13:06:40.58104+00
92	shoulder angled	2012-05-22 13:06:40.582837+00	2012-05-22 13:06:40.582853+00
93	small	2012-05-22 13:06:40.584693+00	2012-05-22 13:06:40.584709+00
95	square	2012-05-22 13:06:40.588443+00	2012-05-22 13:06:40.58846+00
96	squinting	2012-05-22 13:06:40.590371+00	2012-05-22 13:06:40.590387+00
97	straight	2012-05-22 13:06:40.592121+00	2012-05-22 13:06:40.592138+00
98	sway-backed	2012-05-22 13:06:40.593938+00	2012-05-22 13:06:40.593954+00
99	tapering	2012-05-22 13:06:40.599444+00	2012-05-22 13:06:40.59946+00
100	teardrop-shaped	2012-05-22 13:06:40.601309+00	2012-05-22 13:06:40.601325+00
101	thick	2012-05-22 13:06:40.603153+00	2012-05-22 13:06:40.603168+00
102	thin	2012-05-22 13:06:40.605121+00	2012-05-22 13:06:40.605137+00
103	three-stroke	2012-05-22 13:06:40.607026+00	2012-05-22 13:06:40.607043+00
104	through	2012-05-22 13:06:40.609068+00	2012-05-22 13:06:40.609084+00
105	tip horizontal	2012-05-22 13:06:40.613196+00	2012-05-22 13:06:40.613212+00
106	trailing left	2012-05-22 13:06:40.615631+00	2012-05-22 13:06:40.615647+00
107	turned back	2012-05-22 13:06:40.617552+00	2012-05-22 13:06:40.617568+00
108	turned down	2012-05-22 13:06:40.619415+00	2012-05-22 13:06:40.619431+00
109	turned left	2012-05-22 13:06:40.621456+00	2012-05-22 13:06:40.621472+00
110	turned right	2012-05-22 13:06:40.62325+00	2012-05-22 13:06:40.623267+00
111	turned up	2012-05-22 13:06:40.62505+00	2012-05-22 13:06:40.625066+00
112	turned up right	2012-05-22 13:06:40.626994+00	2012-05-22 13:06:40.62701+00
113	undotted	2012-05-22 13:06:40.628941+00	2012-05-22 13:06:40.628957+00
115	vertical	2012-05-22 13:06:40.632858+00	2012-05-22 13:06:40.632875+00
116	vertical tip	2012-05-22 13:06:40.634792+00	2012-05-22 13:06:40.634809+00
117	wedged	2012-05-22 13:06:40.636924+00	2012-05-22 13:06:40.63694+00
119	wide	2012-05-22 13:06:40.640874+00	2012-05-22 13:06:40.640891+00
120	vertically symmetric	2012-05-22 13:06:40.642705+00	2012-05-22 13:06:40.642721+00
121	vertical left	2012-05-22 13:06:40.644621+00	2012-05-22 13:06:40.644637+00
118	unadorned	2012-05-22 13:06:40.638922+00	2012-06-20 16:14:49.149116+00
3	45°	2012-05-22 13:06:40.407674+00	2012-06-20 16:15:18.853249+00
122	tilde-shaped	2012-06-20 16:52:15.685359+00	2012-06-20 16:52:15.68538+00
77	oval	2012-05-22 13:06:40.550647+00	2012-06-20 16:54:10.174734+00
16	at minim-height	2012-05-22 13:06:40.432595+00	2012-06-20 16:54:24.675469+00
5	above minim-height	2012-05-22 13:06:40.411399+00	2012-06-20 16:54:32.34031+00
123	downstroke vertical	2012-06-20 16:55:40.304512+00	2012-06-20 16:55:40.304532+00
124	approach stroke	2012-06-20 16:56:41.682382+00	2012-06-20 16:56:41.682406+00
125	present	2012-06-21 12:05:06.602283+00	2012-06-21 12:05:06.602302+00
126	forward leaning	2012-06-21 15:03:08.877516+00	2012-06-21 15:03:08.877535+00
127	bulging stroke	2012-06-21 15:14:54.983955+00	2012-06-21 15:14:54.983977+00
128	below baseline	2012-06-21 15:23:31.434718+00	2012-06-21 15:23:31.434737+00
11	slanted lower left	2012-05-22 13:06:40.423044+00	2012-06-21 16:00:46.831146+00
114	upright – OBSOLETE. Use vertical	2012-05-22 13:06:40.630826+00	2012-06-26 16:01:24.224834+00
48	forked (small split)	2012-05-22 13:06:40.497034+00	2012-06-26 16:02:24.03293+00
94	split (large split)	2012-05-22 13:06:40.586532+00	2012-06-26 16:02:37.430472+00
54	hooked – OBS: which direction?	2012-05-22 13:06:40.507964+00	2012-06-26 16:07:55.185636+00
74	foot absent	2012-05-22 13:06:40.545164+00	2012-06-29 13:29:36.974131+00
75	hook absent	2012-05-22 13:06:40.546962+00	2012-06-29 13:29:47.569844+00
12	angled ll quadrant – OBSOLETE	2012-05-22 13:06:40.424804+00	2012-06-21 16:00:34.114014+00
15	at baseline OBS: 'on baseline'	2012-05-22 13:06:40.430655+00	2012-06-26 16:03:48.512156+00
129	turned down toe	2012-06-26 16:05:59.428515+00	2012-06-26 16:05:59.428537+00
130	turned up toe	2012-06-26 16:06:04.695268+00	2012-06-26 16:06:04.695287+00
131	hooked left	2012-06-26 16:08:02.334402+00	2012-06-26 16:08:02.334424+00
132	hooked right	2012-06-26 16:08:08.717267+00	2012-06-26 16:08:08.717286+00
134	flat-bottomed	2012-07-03 14:34:08.736394+00	2012-07-03 14:34:08.736418+00
135	through top-stroke	2012-07-03 14:44:00.912528+00	2012-07-03 14:44:00.912561+00
136	semi-caroline	2012-09-17 10:20:13.107117+00	2012-09-17 10:20:13.107135+00
58	horizontally symmetric (flag)	2012-05-22 13:06:40.515165+00	2014-07-03 14:46:36.437373+00
83	ownstroke ticked up [What??]	2012-05-22 13:06:40.565227+00	2012-11-01 17:04:00.708949+00
\.


--
-- Name: digipal_feature_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_feature_id_seq', 136, true);


--
-- Data for Name: digipal_format; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_format (id, legacy_id, name, created, modified) FROM stdin;
1	\N	codex	2017-04-22 17:09:24.055282+00	2017-04-22 17:09:24.055307+00
\.


--
-- Name: digipal_format_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_format_id_seq', 1, true);


--
-- Data for Name: digipal_graph; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_graph (id, idiograph_id, hand_id, display_label, created, modified, group_id) FROM stdin;
10	1	2	a, Caroline. Main Hand	2017-04-22 17:17:52.276348+00	2017-04-22 17:17:52.287985+00	\N
11	1	2	a, Caroline. Main Hand	2017-04-22 17:18:00.789635+00	2017-04-22 17:18:00.790809+00	\N
12	3	2	a, Insular. Main Hand	2017-04-22 17:18:10.852667+00	2017-04-22 17:18:10.854062+00	\N
13	3	2	a, Insular. Main Hand	2017-04-22 17:18:49.809395+00	2017-04-22 17:18:49.810336+00	\N
14	5	2	d, Insular. Main Hand	2017-04-22 17:19:36.294659+00	2017-04-22 17:19:36.296339+00	\N
15	6	2	r, Insular. Main Hand	2017-04-22 17:19:56.667802+00	2017-04-22 17:19:56.668812+00	\N
16	6	2	r, Insular. Main Hand	2017-04-22 17:20:05.667505+00	2017-04-22 17:20:05.668562+00	\N
17	2	2	b. Main Hand	2017-04-22 17:20:18.362814+00	2017-04-22 17:20:18.364748+00	\N
18	2	2	b. Main Hand	2017-04-22 17:20:24.10807+00	2017-04-22 17:20:24.109658+00	\N
19	7	2	c. Main Hand	2017-04-22 17:20:48.763422+00	2017-04-22 17:20:48.764944+00	\N
20	7	2	c. Main Hand	2017-04-22 17:20:52.817295+00	2017-04-22 17:20:52.818417+00	\N
21	8	2	e. Main Hand	2017-04-22 17:21:28.40511+00	2017-04-22 17:21:28.406377+00	\N
22	8	2	e. Main Hand	2017-04-22 17:21:33.126876+00	2017-04-22 17:21:33.127643+00	\N
23	8	2	e. Main Hand	2017-04-22 17:21:37.443235+00	2017-04-22 17:21:37.444494+00	\N
24	9	2	s, Tall. Main Hand	2017-04-22 17:22:00.015195+00	2017-04-22 17:22:00.016908+00	\N
25	10	2	s, Low. Main Hand	2017-04-22 17:22:13.885314+00	2017-04-22 17:22:13.886251+00	\N
26	11	2	s, Round. Main Hand	2017-04-22 17:22:23.106209+00	2017-04-22 17:22:23.107308+00	\N
27	12	2	;, punctus versus. Main Hand	2017-04-22 17:22:36.743419+00	2017-04-22 17:22:36.744115+00	\N
\.


--
-- Data for Name: digipal_graph_aspects; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_graph_aspects (id, graph_id, aspect_id) FROM stdin;
\.


--
-- Name: digipal_graph_aspects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_graph_aspects_id_seq', 1, false);


--
-- Name: digipal_graph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_graph_id_seq', 27, true);


--
-- Data for Name: digipal_graphcomponent; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_graphcomponent (id, graph_id, component_id, created, modified) FROM stdin;
\.


--
-- Data for Name: digipal_graphcomponent_features; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_graphcomponent_features (id, graphcomponent_id, feature_id) FROM stdin;
\.


--
-- Name: digipal_graphcomponent_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_graphcomponent_features_id_seq', 29, true);


--
-- Name: digipal_graphcomponent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_graphcomponent_id_seq', 21, true);


--
-- Data for Name: digipal_hair; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_hair (id, legacy_id, label, created, modified) FROM stdin;
\.


--
-- Name: digipal_hair_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_hair_id_seq', 1, false);


--
-- Data for Name: digipal_hand; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_hand (id, legacy_id, num, item_part_id, script_id, scribe_id, assigned_date_id, assigned_place_id, scragg, em_title, label, display_note, internal_note, appearance_id, relevant, latin_only, gloss_only, membra_disjecta, num_glosses, num_glossing_hands, glossed_text_id, scribble_only, imitative, latin_style_id, comments, display_label, created, modified, locus, surrogates, selected_locus, stewart_record_id, ker) FROM stdin;
2	\N	1	2	\N	\N	1	\N			Main Hand			\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N			2017-04-22 17:12:32.710771+00	2017-04-22 17:17:19.218439+00				\N	
\.


--
-- Name: digipal_hand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_hand_id_seq', 2, true);


--
-- Data for Name: digipal_hand_images; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_hand_images (id, hand_id, image_id) FROM stdin;
2	2	2
\.


--
-- Name: digipal_hand_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_hand_images_id_seq', 2, true);


--
-- Data for Name: digipal_handdescription; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_handdescription (id, hand_id, source_id, description, created, modified, label) FROM stdin;
\.


--
-- Name: digipal_handdescription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_handdescription_id_seq', 1, false);


--
-- Data for Name: digipal_historicalitem; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_historicalitem (id, legacy_id, historical_item_type_id, historical_item_format_id, date, name, hair_id, language_id, url, vernacular, neumed, catalogue_number, display_label, created, modified, legacy_reference, date_sort) FROM stdin;
2	\N	2	1	s. xi1/4	Winchcombe Psalter	\N	\N		\N	\N	Gneuss 4	manuscript Gneuss 4 Winchcombe Psalter	2017-04-22 17:05:45.739686+00	2017-04-22 17:23:59.955243+00		\N
\.


--
-- Data for Name: digipal_historicalitem_categories; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_historicalitem_categories (id, historicalitem_id, category_id) FROM stdin;
\.


--
-- Name: digipal_historicalitem_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_historicalitem_categories_id_seq', 1, false);


--
-- Name: digipal_historicalitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_historicalitem_id_seq', 2, true);


--
-- Data for Name: digipal_historicalitem_owners; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_historicalitem_owners (id, historicalitem_id, owner_id) FROM stdin;
\.


--
-- Name: digipal_historicalitem_owners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_historicalitem_owners_id_seq', 1, false);


--
-- Data for Name: digipal_historicalitemdate; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_historicalitemdate (id, legacy_id, historical_item_id, date_id, evidence, vernacular, addition, dubitable, created, modified) FROM stdin;
\.


--
-- Name: digipal_historicalitemdate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_historicalitemdate_id_seq', 1, false);


--
-- Data for Name: digipal_historicalitemtype; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_historicalitemtype (id, name, created, modified) FROM stdin;
1	document	2015-03-13 18:43:22.222+00	2015-03-13 18:43:22.222+00
2	manuscript	2017-04-22 17:09:17.420455+00	2017-04-22 17:09:17.420494+00
\.


--
-- Name: digipal_historicalitemtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_historicalitemtype_id_seq', 2, true);


--
-- Data for Name: digipal_idiograph; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_idiograph (id, allograph_id, scribe_id, display_label, created, modified) FROM stdin;
1	13	\N	a, Caroline	2017-04-21 19:23:40.17574+00	2017-04-21 19:23:40.175776+00
2	16	\N	b	2017-04-21 19:24:03.779561+00	2017-04-21 19:24:03.77959+00
3	11	\N	a, Insular	2017-04-21 19:24:22.197328+00	2017-04-21 19:24:22.197357+00
4	22	\N	æ, Insular	2017-04-21 19:25:00.076036+00	2017-04-21 19:25:00.076065+00
5	18	\N	d, Insular	2017-04-22 17:19:36.284031+00	2017-04-22 17:19:36.284068+00
6	41	\N	r, Insular	2017-04-22 17:19:56.666427+00	2017-04-22 17:19:56.666479+00
7	15	\N	c	2017-04-22 17:20:48.762082+00	2017-04-22 17:20:48.762143+00
8	17	\N	e	2017-04-22 17:21:28.403563+00	2017-04-22 17:21:28.40359+00
9	36	\N	s, Tall	2017-04-22 17:22:00.013915+00	2017-04-22 17:22:00.013951+00
10	40	\N	s, Low	2017-04-22 17:22:13.884599+00	2017-04-22 17:22:13.884627+00
11	38	\N	s, Round	2017-04-22 17:22:23.104419+00	2017-04-22 17:22:23.10445+00
12	8	\N	;, punctus versus	2017-04-22 17:22:36.742682+00	2017-04-22 17:22:36.742711+00
\.


--
-- Data for Name: digipal_idiograph_aspects; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_idiograph_aspects (id, idiograph_id, aspect_id) FROM stdin;
\.


--
-- Name: digipal_idiograph_aspects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_idiograph_aspects_id_seq', 1, false);


--
-- Name: digipal_idiograph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_idiograph_id_seq', 12, true);


--
-- Data for Name: digipal_idiographcomponent; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_idiographcomponent (id, idiograph_id, component_id, created, modified) FROM stdin;
\.


--
-- Data for Name: digipal_idiographcomponent_features; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_idiographcomponent_features (id, idiographcomponent_id, feature_id) FROM stdin;
\.


--
-- Name: digipal_idiographcomponent_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_idiographcomponent_features_id_seq', 1, false);


--
-- Name: digipal_idiographcomponent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_idiographcomponent_id_seq', 1, false);


--
-- Data for Name: digipal_image; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_image (id, item_part_id, locus, caption, image, display_label, created, modified, folio_side, folio_number, iipimage, media_permission_id, transcription, internal_notes, custom_label, annotation_status_id, width, height, size, keywords_string, quire, page_boundaries) FROM stdin;
2	2	8v	\N		CUL Ff.1.23: 8v	2017-04-22 17:12:34.091168+00	2017-04-22 17:13:48.404665+00	v	8	jp2/admin-upload/2/27ba64e9-9202-4611-b679-98956dabbe1c.tif	\N				\N	1649	2000	0			
\.


--
-- Name: digipal_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_image_id_seq', 2, true);


--
-- Data for Name: digipal_imageannotationstatus; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_imageannotationstatus (id, name, created, modified) FROM stdin;
\.


--
-- Name: digipal_imageannotationstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_imageannotationstatus_id_seq', 1, false);


--
-- Data for Name: digipal_institution; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_institution (id, legacy_id, institution_type_id, name, founder_id, reformer_id, patron_id, place_id, foundation, refoundation, created, modified) FROM stdin;
\.


--
-- Name: digipal_institution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_institution_id_seq', 1, false);


--
-- Data for Name: digipal_institutiontype; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_institutiontype (id, name, created, modified) FROM stdin;
\.


--
-- Name: digipal_institutiontype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_institutiontype_id_seq', 1, false);


--
-- Data for Name: digipal_itemorigin; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_itemorigin (id, legacy_id, historical_item_id, evidence, dubitable, created, modified, place_id, institution_id) FROM stdin;
\.


--
-- Name: digipal_itemorigin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_itemorigin_id_seq', 1, false);


--
-- Data for Name: digipal_itempart; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_itempart (id, current_item_id, locus, display_label, created, modified, pagination, group_id, type_id, group_locus, notes, keywords_string) FROM stdin;
2	2		CUL Ff.1.23	2017-04-22 17:03:21.563903+00	2017-04-22 17:17:19.205191+00	f	\N	\N			
\.


--
-- Name: digipal_itempart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_itempart_id_seq', 2, true);


--
-- Data for Name: digipal_itempart_owners; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_itempart_owners (id, itempart_id, owner_id) FROM stdin;
\.


--
-- Name: digipal_itempart_owners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_itempart_owners_id_seq', 1, false);


--
-- Data for Name: digipal_itempartauthenticity; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_itempartauthenticity (id, created, modified, item_part_id, category_id, source_id, note) FROM stdin;
\.


--
-- Name: digipal_itempartauthenticity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_itempartauthenticity_id_seq', 1, false);


--
-- Data for Name: digipal_itempartitem; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_itempartitem (id, historical_item_id, item_part_id, locus, created, modified) FROM stdin;
1	2	2		2017-04-22 17:05:45.762467+00	2017-04-22 17:05:45.762516+00
\.


--
-- Name: digipal_itempartitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_itempartitem_id_seq', 1, true);


--
-- Data for Name: digipal_itemparttype; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_itemparttype (id, name, created, modified) FROM stdin;
\.


--
-- Name: digipal_itemparttype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_itemparttype_id_seq', 1, false);


--
-- Data for Name: digipal_keyval; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_keyval (id, key, val, created, modified) FROM stdin;
1	indexer	{"updated": "29-08-2017 21:48:48", "started": "29-08-2017 21:48:46", "pid": 636, "indexes": {"graphs": {"started": null, "progress": 1.0, "state": "indexed"}, "texts": {"started": null, "progress": 1.0, "state": "indexed"}, "hands": {"started": null, "progress": 1.0, "state": "indexed"}, "images": {"started": null, "progress": 1.0, "state": "indexed"}, "scribes": {"started": null, "progress": 1.0, "state": "indexed"}, "manuscripts": {"started": null, "progress": 1.0, "state": "indexed"}}, "state": "indexed", "progress": 1.0}	2017-08-29 20:48:46.697423+00	2017-08-29 20:48:48.377889+00
2	get_latest_docker_version	{"version": "2.1.0", "last_checked": 1504040003.584571}	2017-08-29 20:53:23.850593+00	2017-08-29 20:53:23.85617+00
\.


--
-- Name: digipal_keyval_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_keyval_id_seq', 2, true);


--
-- Data for Name: digipal_language; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_language (id, legacy_id, name, created, modified) FROM stdin;
\.


--
-- Name: digipal_language_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_language_id_seq', 1, false);


--
-- Data for Name: digipal_latinstyle; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_latinstyle (id, legacy_id, style, created, modified) FROM stdin;
\.


--
-- Name: digipal_latinstyle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_latinstyle_id_seq', 1, false);


--
-- Data for Name: digipal_layout; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_layout (id, historical_item_id, page_height, page_width, frame_height, frame_width, tramline_width, lines, columns, on_top_line, multiple_sheet_rulling, bilinear_ruling, comments, hair_arrangement_id, insular_pricking, created, modified, item_part_id) FROM stdin;
\.


--
-- Name: digipal_layout_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_layout_id_seq', 1, false);


--
-- Data for Name: digipal_measurement; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_measurement (id, legacy_id, label, created, modified) FROM stdin;
\.


--
-- Name: digipal_measurement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_measurement_id_seq', 1, false);


--
-- Data for Name: digipal_mediapermission; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_mediapermission (id, label, display_message, permission) FROM stdin;
1	Private		100
2	CC BY-NC 3.0	<p>This image is licensed under a Creative Commons Attribution-NonCommercial 3.0 Unported License (CC BY-NC 3.0)</p>	300
\.


--
-- Name: digipal_mediapermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_mediapermission_id_seq', 2, true);


--
-- Data for Name: digipal_ontograph; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_ontograph (id, name, ontograph_type_id, created, modified, nesting_level, sort_order) FROM stdin;
10	A	2	2012-05-22 13:06:41.895733+00	2013-11-04 13:10:48.868141+00	0	100
17	Æ	2	2012-05-22 13:06:42.014212+00	2013-11-04 13:10:51.433439+00	0	115
13	B	2	2012-05-22 13:06:41.94766+00	2013-11-04 13:10:54.134498+00	0	120
12	C	2	2012-05-22 13:06:41.935444+00	2013-11-04 13:10:54.505217+00	0	130
15	D	2	2012-05-22 13:06:41.976321+00	2013-11-04 13:10:56.308464+00	0	140
14	E	2	2012-05-22 13:06:41.963901+00	2013-11-04 13:10:58.496423+00	0	150
21	F	2	2012-05-22 13:06:42.096768+00	2013-11-04 13:11:00.744738+00	0	160
16	G	2	2012-05-22 13:06:41.993471+00	2013-11-04 13:11:03.609003+00	0	170
19	H	2	2012-05-22 13:06:42.068725+00	2013-11-04 13:11:06.11305+00	0	180
18	I	2	2012-05-22 13:06:42.054999+00	2013-11-04 13:11:08.030789+00	0	190
20	K	2	2012-05-22 13:06:42.080245+00	2013-11-04 13:11:08.388403+00	0	200
23	L	2	2012-05-22 13:06:42.131696+00	2013-11-04 13:11:08.743587+00	0	210
22	M	2	2012-05-22 13:06:42.117674+00	2013-11-04 13:11:09.137219+00	0	220
9	N	2	2012-05-22 13:06:41.881532+00	2013-11-04 13:11:10.843194+00	0	230
24	O	2	2012-05-22 13:06:42.141577+00	2013-11-04 13:11:12.889957+00	0	240
26	P	2	2012-05-22 13:06:42.180347+00	2013-11-04 13:11:13.347932+00	0	250
25	Q	2	2012-05-22 13:06:42.168446+00	2013-11-04 13:11:13.721306+00	0	260
28	R	2	2012-05-22 13:06:42.231925+00	2013-11-04 13:11:13.870126+00	0	270
27	S	2	2012-05-22 13:06:42.191934+00	2013-11-04 13:11:15.957391+00	0	280
30	T	2	2012-05-22 13:06:42.264069+00	2013-11-04 13:11:20.469148+00	0	290
29	U	2	2012-05-22 13:06:42.249112+00	2013-11-04 13:11:20.925723+00	0	300
36	thæt	5	2012-07-03 17:27:10.632522+00	2013-11-04 13:17:50.269994+00	0	450
7	tironian et	5	2012-05-22 13:06:41.840075+00	2013-11-04 13:17:50.397177+00	0	400
5	accent	4	2012-05-22 13:06:41.818324+00	2013-11-04 13:17:51.898265+00	0	470
33	ETH	2	2012-05-22 13:06:42.328971+00	2013-11-04 13:17:52.292611+00	0	296
35	THORN	2	2012-05-22 13:06:42.36007+00	2013-11-04 13:17:54.085197+00	0	292
11	&	3	2012-05-22 13:06:41.921762+00	2013-11-04 13:17:54.530825+00	0	410
4	ligature	3	2012-05-22 13:06:41.807212+00	2013-11-04 13:17:54.680975+00	0	480
1	abbrev. stroke	1	2012-05-22 13:06:41.771016+00	2013-11-04 13:17:54.877098+00	0	460
6	punctus	1	2012-05-22 13:06:41.827963+00	2013-11-04 13:17:55.323307+00	0	420
8	punctus interrogativus	1	2012-05-22 13:06:41.867068+00	2013-11-04 13:17:55.792736+00	0	430
3	punctus versus	1	2012-05-22 13:06:41.794474+00	2013-11-04 13:17:55.840202+00	0	440
2	WYNN	2	2012-05-22 13:06:41.782444+00	2013-11-04 13:17:56.110083+00	0	325
32	X	2	2012-05-22 13:06:42.30612+00	2013-11-04 13:17:56.466205+00	0	330
31	Y	2	2012-05-22 13:06:42.276966+00	2013-11-04 13:17:57.386084+00	0	340
34	Z	2	2012-05-22 13:06:42.343152+00	2013-11-04 13:17:59.717372+00	0	350
37	W	2	2015-08-28 09:27:05.638343+00	2015-08-28 09:27:23.199321+00	0	312
\.


--
-- Name: digipal_ontograph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_ontograph_id_seq', 37, true);


--
-- Data for Name: digipal_ontographtype; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_ontographtype (id, name, created, modified) FROM stdin;
1	punctuation	2012-05-22 13:06:41.768102+00	2012-05-22 13:06:41.768119+00
2	letter	2012-05-22 13:06:41.780215+00	2012-05-22 13:06:41.780231+00
3	ligature	2012-05-22 13:06:41.805136+00	2012-05-22 13:06:41.805151+00
4	accent	2012-05-22 13:06:41.816165+00	2012-05-22 13:06:41.81618+00
5	abbreviation	2012-05-22 13:06:41.837668+00	2012-05-22 13:06:41.837683+00
\.


--
-- Name: digipal_ontographtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_ontographtype_id_seq', 5, true);


--
-- Data for Name: digipal_owner; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_owner (id, legacy_id, date, evidence, rebound, annotated, dubitable, created, modified, person_id, institution_id, repository_id, display_label) FROM stdin;
\.


--
-- Name: digipal_owner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_owner_id_seq', 1, false);


--
-- Data for Name: digipal_ownertype; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_ownertype (id, name, created, modified) FROM stdin;
1	Person	2016-09-27 22:11:11.218509+00	2016-09-27 22:11:11.218489+00
2	Institution	2016-09-27 22:11:11.219516+00	2016-09-27 22:11:11.219499+00
3	Library	2016-09-27 22:11:11.220314+00	2016-09-27 22:11:11.220296+00
4	Unknown	2016-09-27 22:11:11.221097+00	2016-09-27 22:11:11.221081+00
\.


--
-- Name: digipal_ownertype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_ownertype_id_seq', 4, true);


--
-- Data for Name: digipal_person; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_person (id, legacy_id, name, created, modified) FROM stdin;
\.


--
-- Name: digipal_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_person_id_seq', 1, false);


--
-- Data for Name: digipal_place; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_place (id, legacy_id, name, eastings, northings, region_id, current_county_id, historical_county_id, created, modified, type_id, other_names) FROM stdin;
1	\N	000000	\N	\N	\N	\N	\N	2012-05-22 13:06:44.67583+00	2012-05-22 13:06:44.67585+00	\N	\N
2	-2054568300	Unknown (Cerne?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.683067+00	2012-05-22 13:06:44.683084+00	\N	\N
3	-1479811358	Unknown (Exeter by s. xi3/4)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.684786+00	2012-05-22 13:06:44.684802+00	\N	\N
4	-1436576276	Unknown (Sherborne prov?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.686583+00	2012-05-22 13:06:44.686599+00	\N	\N
5	-1300274563	Unknown (SW?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.690511+00	2012-05-22 13:06:44.690527+00	\N	\N
6	-1054827014	Unknown (Wi?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.695763+00	2012-05-22 13:06:44.695779+00	\N	\N
7	-1041851303	Unknown (Ca?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.697594+00	2012-05-22 13:06:44.697609+00	\N	\N
8	-809215114	Unknown (CaA?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.699458+00	2012-05-22 13:06:44.699474+00	\N	\N
9	-13625409	Unknown (CaCC?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.701419+00	2012-05-22 13:06:44.701435+00	\N	\N
10	-13625408	Unknown (Westminster archive)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.7032+00	2012-05-22 13:06:44.703216+00	\N	\N
11	-13625407	All	\N	\N	\N	\N	\N	2012-05-22 13:06:44.704967+00	2012-05-22 13:06:44.704983+00	\N	\N
12	-13625406	SW England (Wells?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.707947+00	2012-05-22 13:06:44.707963+00	\N	\N
13	1	Abingdon	4495	1175	1	28	28	2012-05-22 13:06:44.715916+00	2012-05-22 13:06:44.715932+00	\N	\N
14	2	Exeter	2925	925	2	9	9	2012-05-22 13:06:44.72161+00	2012-05-22 13:06:44.721626+00	\N	\N
15	3	CaCC	6145	1575	3	19	19	2012-05-22 13:06:44.727209+00	2012-05-22 13:06:44.727225+00	\N	\N
16	4	CaA	6145	1575	3	19	19	2012-05-22 13:06:44.73299+00	2012-05-22 13:06:44.733006+00	\N	\N
17	5	Gloucester	3835	2185	4	13	13	2012-05-22 13:06:44.738494+00	2012-05-22 13:06:44.73851+00	\N	\N
18	6	WiNM	4485	1295	1	14	14	2012-05-22 13:06:44.74399+00	2012-05-22 13:06:44.744007+00	\N	\N
19	7	WiOM	4485	1295	1	14	14	2012-05-22 13:06:44.749771+00	2012-05-22 13:06:44.749787+00	\N	\N
20	8	WiNun	4485	1295	1	14	14	2012-05-22 13:06:44.759754+00	2012-05-22 13:06:44.759771+00	\N	\N
21	9	Durham	4275	5425	5	11	40	2012-05-22 13:06:44.766055+00	2012-05-22 13:06:44.766071+00	\N	\N
22	10	Salisbury	4145	1305	1	38	38	2012-05-22 13:06:44.771805+00	2012-05-22 13:06:44.771822+00	\N	\N
23	11	Ramsey	5285	2855	6	4	4	2012-05-22 13:06:44.778153+00	2012-05-22 13:06:44.778169+00	\N	\N
24	12	Worcester	3855	2555	4	39	39	2012-05-22 13:06:44.783831+00	2012-05-22 13:06:44.783848+00	\N	\N
25	13	Cerne	3665	1015	2	10	10	2012-05-22 13:06:44.789574+00	2012-05-22 13:06:44.789589+00	\N	\N
26	14	Canterbury	6145	1575	3	19	19	2012-05-22 13:06:44.795387+00	2012-05-22 13:06:44.795404+00	\N	\N
27	16	W England	\N	\N	\N	\N	\N	2012-05-22 13:06:44.798256+00	2012-05-22 13:06:44.798272+00	\N	\N
28	17	J-W	4345	5655	5	40	40	2012-05-22 13:06:44.803855+00	2012-05-22 13:06:44.803871+00	\N	\N
29	18	Northumbria	\N	\N	\N	\N	\N	2012-05-22 13:06:44.80579+00	2012-05-22 13:06:44.805806+00	\N	\N
30	19	S England	\N	\N	\N	\N	\N	2012-05-22 13:06:44.807656+00	2012-05-22 13:06:44.807673+00	\N	\N
31	20	Bath	3745	1645	2	31	31	2012-05-22 13:06:44.813104+00	2012-05-22 13:06:44.81312+00	\N	\N
32	21	SW England	\N	\N	\N	\N	\N	2012-05-22 13:06:44.814824+00	2012-05-22 13:06:44.814839+00	\N	\N
33	22	SE England	\N	\N	\N	\N	\N	2012-05-22 13:06:44.816601+00	2012-05-22 13:06:44.816617+00	\N	\N
34	23	Winchester	4485	1295	1	14	14	2012-05-22 13:06:44.822124+00	2012-05-22 13:06:44.822139+00	\N	\N
35	24	Wessex	\N	\N	\N	\N	\N	2012-05-22 13:06:44.823969+00	2012-05-22 13:06:44.824004+00	\N	\N
36	25	Kent	\N	\N	\N	19	19	2012-05-22 13:06:44.828511+00	2012-05-22 13:06:44.828527+00	\N	\N
37	26	Glastonbury	3505	1395	1	31	31	2012-05-22 13:06:44.83396+00	2012-05-22 13:06:44.833976+00	\N	\N
38	27	London	5315	1815	1	23	23	2012-05-22 13:06:44.839575+00	2012-05-22 13:06:44.839592+00	\N	\N
39	28	Continent	\N	\N	\N	\N	\N	2012-05-22 13:06:44.841366+00	2012-05-22 13:06:44.841382+00	\N	\N
40	29	Unknown	\N	\N	\N	\N	\N	2012-05-22 13:06:44.843191+00	2012-05-22 13:06:44.843207+00	\N	\N
41	30	England	\N	\N	\N	\N	\N	2012-05-22 13:06:44.84507+00	2012-05-22 13:06:44.845086+00	\N	\N
42	31	Lindisfarne	\N	\N	\N	40	40	2012-05-22 13:06:44.849691+00	2012-05-22 13:06:44.849707+00	\N	\N
43	32	Chester-le-Street	4275	5515	5	40	40	2012-05-22 13:06:44.855107+00	2012-05-22 13:06:44.855123+00	\N	\N
44	33	Sherborne	3635	1165	1	10	10	2012-05-22 13:06:44.863881+00	2012-05-22 13:06:44.863901+00	\N	\N
45	34	Hereford	3515	2405	4	15	15	2012-05-22 13:06:44.869391+00	2012-05-22 13:06:44.869407+00	\N	\N
46	35	York	4595	4515	5	40	40	2012-05-22 13:06:44.874827+00	2012-05-22 13:06:44.874843+00	\N	\N
47	36	Thorney	5285	3045	6	4	4	2012-05-22 13:06:44.880256+00	2012-05-22 13:06:44.880272+00	\N	\N
48	37	Mercia	\N	\N	\N	\N	\N	2012-05-22 13:06:44.882104+00	2012-05-22 13:06:44.88212+00	\N	\N
49	38	Bury St Edmunds	5285	2835	7	33	33	2012-05-22 13:06:44.889131+00	2012-05-22 13:06:44.889149+00	\N	\N
50	39	N England	\N	\N	\N	\N	\N	2012-05-22 13:06:44.891001+00	2012-05-22 13:06:44.891017+00	\N	\N
51	40	Barking	6075	2535	8	12	12	2012-05-22 13:06:44.899404+00	2012-05-22 13:06:44.899421+00	\N	\N
52	41	Rochester	5725	1685	3	19	19	2012-05-22 13:06:44.905043+00	2012-05-22 13:06:44.90506+00	\N	\N
53	42	Peterborough	5195	2995	6	29	29	2012-05-22 13:06:44.910785+00	2012-05-22 13:06:44.910801+00	\N	\N
54	43	Ely	5545	2805	6	4	4	2012-05-22 13:06:44.916358+00	2012-05-22 13:06:44.916374+00	\N	\N
55	44	Bodmin	2065	675	2	6	6	2012-05-22 13:06:44.921922+00	2012-05-22 13:06:44.921944+00	\N	\N
56	45	Lichfield	4115	3095	4	32	32	2012-05-22 13:06:44.927848+00	2012-05-22 13:06:44.927864+00	\N	\N
57	46	Wales	\N	\N	\N	\N	\N	2012-05-22 13:06:44.929842+00	2012-05-22 13:06:44.929858+00	\N	\N
58	47	W Midlands or Wales	\N	\N	\N	\N	\N	2012-05-22 13:06:44.931804+00	2012-05-22 13:06:44.93182+00	\N	\N
59	48	Minster-in-Thanet	6305	1645	3	19	19	2012-05-22 13:06:44.937484+00	2012-05-22 13:06:44.9375+00	\N	\N
60	49	Ireland	\N	\N	\N	\N	\N	2012-05-22 13:06:44.939332+00	2012-05-22 13:06:44.939348+00	\N	\N
61	50	SW England (St Germans?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.941115+00	2012-05-22 13:06:44.941131+00	\N	\N
62	51	Worcester or York	\N	\N	\N	\N	\N	2012-05-22 13:06:44.943005+00	2012-05-22 13:06:44.943021+00	\N	\N
63	52	W England (Worcester?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.944838+00	2012-05-22 13:06:44.944854+00	\N	\N
64	53	SE England (Canterbury?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.946785+00	2012-05-22 13:06:44.946801+00	\N	\N
65	54	Winchester (NM?)	4485	1295	1	14	14	2012-05-22 13:06:44.957298+00	2012-05-22 13:06:44.957315+00	\N	\N
66	55	S England (CaCC?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.961353+00	2012-05-22 13:06:44.961369+00	\N	\N
67	56	WiOM (or CaCC??)	\N	\N	\N	14	14	2012-05-22 13:06:44.966038+00	2012-05-22 13:06:44.966055+00	\N	\N
68	57	SW England (prob. WiNM)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.9678+00	2012-05-22 13:06:44.967816+00	\N	\N
69	58	CaCC? Winchester?	\N	\N	\N	\N	\N	2012-05-22 13:06:44.969632+00	2012-05-22 13:06:44.969649+00	\N	\N
70	59	Winchester? CaA?	\N	\N	\N	\N	\N	2012-05-22 13:06:44.971531+00	2012-05-22 13:06:44.971548+00	\N	\N
71	60	SE England (London?)	\N	\N	\N	\N	\N	2012-05-22 13:06:44.973388+00	2012-05-22 13:06:44.973404+00	\N	\N
72	61	CaCC (CaA?)	6145	1575	3	19	19	2012-05-22 13:06:44.979503+00	2012-05-22 13:06:44.979519+00	\N	\N
73	62	Canterbury or Rochester	\N	\N	\N	19	19	2012-05-22 13:06:44.984187+00	2012-05-22 13:06:44.984204+00	\N	\N
74	63	Peterborough or Ely	\N	\N	\N	\N	\N	2012-05-22 13:06:44.986099+00	2012-05-22 13:06:44.986116+00	\N	\N
75	64	Ramsey? Canterbury?	\N	\N	\N	\N	\N	2012-05-22 13:06:44.988056+00	2012-05-22 13:06:44.988072+00	\N	\N
76	65	Continent or England	\N	\N	\N	\N	\N	2012-05-22 13:06:44.990346+00	2012-05-22 13:06:44.990363+00	\N	\N
77	66	Abingdon (or Continent?)	4495	1975	1	28	28	2012-05-22 13:06:44.999799+00	2012-05-22 13:06:44.999816+00	\N	\N
78	67	CaA or Glastonbury?	\N	\N	\N	\N	\N	2012-05-22 13:06:45.001812+00	2012-05-22 13:06:45.001828+00	\N	\N
79	68	W Midlands or Northumbria?	\N	\N	\N	\N	\N	2012-05-22 13:06:45.003732+00	2012-05-22 13:06:45.003748+00	\N	\N
80	69	CaCC (or WiOM?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.005568+00	2012-05-22 13:06:45.005584+00	\N	\N
81	70	SW England (Winchester?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.007483+00	2012-05-22 13:06:45.007499+00	\N	\N
82	71	Worcester (and York?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.009385+00	2012-05-22 13:06:45.009401+00	\N	\N
83	72	S England (Winchester?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.01122+00	2012-05-22 13:06:45.011236+00	\N	\N
84	73	Abingdon or Canterbury	\N	\N	\N	\N	\N	2012-05-22 13:06:45.013053+00	2012-05-22 13:06:45.013069+00	\N	\N
85	74	Wessex, perhaps Winchester	\N	\N	\N	\N	\N	2012-05-22 13:06:45.014831+00	2012-05-22 13:06:45.014847+00	\N	\N
86	75	S England (prob. Kent)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.018707+00	2012-05-22 13:06:45.018723+00	\N	\N
87	76	Durham (or Wessex)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.021081+00	2012-05-22 13:06:45.021097+00	\N	\N
88	77	Lindisfarne or J-W?	\N	\N	\N	40	40	2012-05-22 13:06:45.026023+00	2012-05-22 13:06:45.02604+00	\N	\N
89	78	SE England, or London, St Pauls	\N	\N	\N	\N	\N	2012-05-22 13:06:45.027882+00	2012-05-22 13:06:45.027898+00	\N	\N
90	79	Mercia (Worcester?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.029748+00	2012-05-22 13:06:45.029764+00	\N	\N
91	80	Winchcombe	4025	2285	4	13	13	2012-05-22 13:06:45.035421+00	2012-05-22 13:06:45.035437+00	\N	\N
92	81	St Albans	5155	2075	8	16	16	2012-05-22 13:06:45.041469+00	2012-05-22 13:06:45.041485+00	\N	\N
93	82	W Midlands	\N	\N	\N	\N	\N	2012-05-22 13:06:45.043348+00	2012-05-22 13:06:45.043364+00	\N	\N
94	83	Malmesbury	3935	1875	1	38	38	2012-05-22 13:06:45.048964+00	2012-05-22 13:06:45.04898+00	\N	\N
95	84	Horton, Dorset	4035	1075	2	10	10	2012-05-22 13:06:45.054791+00	2012-05-22 13:06:45.054807+00	\N	\N
96	85	Westminster	5295	1795	8	23	23	2012-05-22 13:06:45.063918+00	2012-05-22 13:06:45.063934+00	\N	\N
97	86	Burton	4245	3225	4	32	32	2012-05-22 13:06:45.069716+00	2012-05-22 13:06:45.069732+00	\N	\N
98	87	Selsey	4855	935	3	35	35	2012-05-22 13:06:45.075339+00	2012-05-22 13:06:45.075355+00	\N	\N
99	88	Muchelney	3435	1245	2	31	31	2012-05-22 13:06:45.080962+00	2012-05-22 13:06:45.080978+00	\N	\N
100	89	Coventry	4335	2785	4	36	36	2012-05-22 13:06:45.088287+00	2012-05-22 13:06:45.088304+00	\N	\N
101	90	Abbotsbury	3575	855	\N	\N	\N	2012-05-22 13:06:45.090156+00	2012-05-22 13:06:45.090173+00	\N	\N
102	91	Evesham	4035	2435	4	39	39	2012-05-22 13:06:45.099675+00	2012-05-22 13:06:45.099692+00	\N	\N
103	92	Crediton	2835	1005	2	9	9	2012-05-22 13:06:45.105386+00	2012-05-22 13:06:45.105402+00	\N	\N
104	93	Cornwall (St Germans)	2355	575	2	6	6	2012-05-22 13:06:45.111317+00	2012-05-22 13:06:45.111333+00	\N	\N
105	94	Tavistock	2485	745	2	9	9	2012-05-22 13:06:45.116994+00	2012-05-22 13:06:45.11701+00	\N	\N
106	95	Ramsbury	4275	1715	1	38	38	2012-05-22 13:06:45.12287+00	2012-05-22 13:06:45.122886+00	\N	\N
107	96	Wells	3545	1455	2	31	31	2012-05-22 13:06:45.128713+00	2012-05-22 13:06:45.128729+00	\N	\N
108	97	Elmham	5985	3205	9	24	24	2012-05-22 13:06:45.134324+00	2012-05-22 13:06:45.134341+00	\N	\N
109	98	Milton	3805	1015	2	10	10	2012-05-22 13:06:45.140216+00	2012-05-22 13:06:45.140231+00	\N	\N
110	99	Chertsey	5045	1665	8	34	34	2012-05-22 13:06:45.145936+00	2012-05-22 13:06:45.145952+00	\N	\N
111	100	Italy (Rome?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.148024+00	2012-05-22 13:06:45.148061+00	\N	\N
112	101	Saint-Denis	\N	\N	\N	\N	\N	2012-05-22 13:06:45.150003+00	2012-05-22 13:06:45.150019+00	\N	\N
113	102	France (prob. Brittany, or SW France?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.151777+00	2012-05-22 13:06:45.151798+00	\N	\N
114	103	W France	\N	\N	\N	\N	\N	2012-05-22 13:06:45.157719+00	2012-05-22 13:06:45.157736+00	\N	\N
115	104	Germany	\N	\N	\N	\N	\N	2012-05-22 13:06:45.159516+00	2012-05-22 13:06:45.159532+00	\N	\N
116	105	NE France	\N	\N	\N	\N	\N	2012-05-22 13:06:45.161342+00	2012-05-22 13:06:45.161358+00	\N	\N
117	106	Arras	\N	\N	\N	\N	\N	2012-05-22 13:06:45.163148+00	2012-05-22 13:06:45.163164+00	\N	\N
118	107	Tours	\N	\N	\N	\N	\N	2012-05-22 13:06:45.164998+00	2012-05-22 13:06:45.165014+00	\N	\N
119	108	Landévennec (Brittany)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.166799+00	2012-05-22 13:06:45.166822+00	\N	\N
120	109	N France or Flanders	\N	\N	\N	\N	\N	2012-05-22 13:06:45.168787+00	2012-05-22 13:06:45.168803+00	\N	\N
121	110	N or NW France	\N	\N	\N	\N	\N	2012-05-22 13:06:45.170665+00	2012-05-22 13:06:45.170681+00	\N	\N
122	111	St-Vaast, Arras	\N	\N	\N	\N	\N	2012-05-22 13:06:45.172677+00	2012-05-22 13:06:45.172693+00	\N	\N
123	112	Roskilde	\N	\N	\N	\N	\N	2012-05-22 13:06:45.174711+00	2012-05-22 13:06:45.174727+00	\N	\N
124	113	NE France	\N	\N	\N	\N	\N	2012-05-22 13:06:45.176734+00	2012-05-22 13:06:45.17675+00	\N	\N
125	114	France	\N	\N	\N	\N	\N	2012-05-22 13:06:45.178677+00	2012-05-22 13:06:45.178693+00	\N	\N
126	115	N France or Germany	\N	\N	\N	\N	\N	2012-05-22 13:06:45.180516+00	2012-05-22 13:06:45.180532+00	\N	\N
127	116	France (Saint-Denis?) (or England?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.182344+00	2012-05-22 13:06:45.18236+00	\N	\N
128	117	N France or England?	\N	\N	\N	\N	\N	2012-05-22 13:06:45.184108+00	2012-05-22 13:06:45.184144+00	\N	\N
129	118	Pershore	3945	2455	4	39	39	2012-05-22 13:06:45.190288+00	2012-05-22 13:06:45.190305+00	\N	\N
130	119	N France or Brittany	\N	\N	\N	\N	\N	2012-05-22 13:06:45.192374+00	2012-05-22 13:06:45.19239+00	\N	\N
131	120	Rhiems	\N	\N	\N	\N	\N	2012-05-22 13:06:45.194412+00	2012-05-22 13:06:45.194428+00	\N	\N
132	121	N France	\N	\N	\N	\N	\N	2012-05-22 13:06:45.199799+00	2012-05-22 13:06:45.199816+00	\N	\N
133	122	Spain	\N	\N	\N	\N	\N	2012-05-22 13:06:45.201677+00	2012-05-22 13:06:45.201693+00	\N	\N
134	123	Italy	\N	\N	\N	\N	\N	2012-05-22 13:06:45.203499+00	2012-05-22 13:06:45.203515+00	\N	\N
136	125	Dorchester	4575	1945	1	10	10	2012-05-22 13:06:45.211288+00	2012-05-22 13:06:45.211304+00	\N	\N
137	126	Buckfast	\N	\N	2	\N	\N	2012-05-22 13:06:45.214999+00	2012-05-22 13:06:45.215015+00	\N	\N
138	127	Leominster	\N	\N	4	15	15	2012-05-22 13:06:45.220719+00	2012-05-22 13:06:45.220735+00	\N	\N
139	128	Biddlesden Priory, Bucks.	\N	\N	\N	3	3	2012-05-22 13:06:45.225647+00	2012-05-22 13:06:45.225662+00	\N	\N
140	129	Waltham Abbey	\N	\N	\N	\N	\N	2012-05-22 13:06:45.2275+00	2012-05-22 13:06:45.227516+00	\N	\N
141	130	Cirencester	\N	\N	\N	13	13	2012-05-22 13:06:45.232189+00	2012-05-22 13:06:45.232206+00	\N	\N
142	44097541	Unknown (late Exeter prov.)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.23436+00	2012-05-22 13:06:45.234376+00	\N	\N
143	247582990	Unknown (WiOM?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.236333+00	2012-05-22 13:06:45.236348+00	\N	\N
144	503267937	Unknown (Malms. prov)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.238285+00	2012-05-22 13:06:45.238301+00	\N	\N
145	517548000	Unknown (London??)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.240232+00	2012-05-22 13:06:45.240248+00	\N	\N
146	770744169	Unknown (Bury?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.242052+00	2012-05-22 13:06:45.242068+00	\N	\N
147	827153592	Unknown (Worces prov)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.244013+00	2012-05-22 13:06:45.244029+00	\N	\N
148	929321847	Unknown (S Eng?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.245978+00	2012-05-22 13:06:45.245993+00	\N	\N
149	1108586883	Unknown (Abingdon prov.)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.248044+00	2012-05-22 13:06:45.24806+00	\N	\N
150	1563058419	Unknown (Worces or York?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.250066+00	2012-05-22 13:06:45.250082+00	\N	\N
151	1622271496	Unknown (Ælfric)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.252022+00	2012-05-22 13:06:45.252056+00	\N	\N
152	2006268347	Unknown (later Durham)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.253969+00	2012-05-22 13:06:45.253984+00	\N	\N
153	\N	Karlsruhe	\N	\N	\N	\N	\N	2012-05-22 13:06:45.268399+00	2012-05-22 13:06:45.268416+00	\N	\N
154	\N	Redlynch	\N	\N	\N	\N	\N	2012-05-22 13:06:45.27333+00	2012-05-22 13:06:45.273346+00	\N	\N
155	\N	Spanberg	\N	\N	\N	\N	\N	2012-05-22 13:06:45.277521+00	2012-05-22 13:06:45.277537+00	\N	\N
156	\N	Aberdeen	\N	\N	\N	\N	\N	2012-05-22 13:06:45.281494+00	2012-05-22 13:06:45.28151+00	\N	\N
157	\N	Aberystwyth	\N	\N	\N	\N	\N	2012-05-22 13:06:45.286025+00	2012-05-22 13:06:45.286041+00	\N	\N
158	\N	Alençon	\N	\N	\N	\N	\N	2012-05-22 13:06:45.289885+00	2012-05-22 13:06:45.2899+00	\N	\N
159	\N	Amiens	\N	\N	\N	\N	\N	2012-05-22 13:06:45.297947+00	2012-05-22 13:06:45.297963+00	\N	\N
160	\N	Antwerp	\N	\N	\N	\N	\N	2012-05-22 13:06:45.302544+00	2012-05-22 13:06:45.30256+00	\N	\N
161	\N	Arendal	\N	\N	\N	\N	\N	2012-05-22 13:06:45.307481+00	2012-05-22 13:06:45.307497+00	\N	\N
162	\N	Avranches	\N	\N	\N	\N	\N	2012-05-22 13:06:45.316905+00	2012-05-22 13:06:45.316921+00	\N	\N
163	\N	Badminton	\N	\N	\N	\N	\N	2012-05-22 13:06:45.321093+00	2012-05-22 13:06:45.321109+00	\N	\N
164	\N	Bamberg	\N	\N	\N	\N	\N	2012-05-22 13:06:45.325283+00	2012-05-22 13:06:45.325298+00	\N	\N
165	\N	Basel	\N	\N	\N	\N	\N	2012-05-22 13:06:45.32971+00	2012-05-22 13:06:45.329727+00	\N	\N
166	\N	Bergen	\N	\N	\N	\N	\N	2012-05-22 13:06:45.3339+00	2012-05-22 13:06:45.333916+00	\N	\N
167	\N	Berlin	\N	\N	\N	\N	\N	2012-05-22 13:06:45.33838+00	2012-05-22 13:06:45.338396+00	\N	\N
168	\N	Bern	\N	\N	\N	\N	\N	2012-05-22 13:06:45.342974+00	2012-05-22 13:06:45.342989+00	\N	\N
169	\N	Besançon	\N	\N	\N	\N	\N	2012-05-22 13:06:45.346613+00	2012-05-22 13:06:45.346629+00	\N	\N
170	\N	Bloomington	\N	\N	\N	\N	\N	2012-05-22 13:06:45.350249+00	2012-05-22 13:06:45.350265+00	\N	\N
171	\N	Oxford	\N	\N	\N	\N	\N	2012-05-22 13:06:45.358246+00	2012-05-22 13:06:45.358261+00	\N	\N
172	\N	Boulogne-sur Mer	\N	\N	\N	\N	\N	2012-05-22 13:06:45.442138+00	2012-05-22 13:06:45.442154+00	\N	\N
173	\N	Braunschweig	\N	\N	\N	\N	\N	2012-05-22 13:06:45.44627+00	2012-05-22 13:06:45.446285+00	\N	\N
175	\N	Brussels	\N	\N	\N	\N	\N	2012-05-22 13:06:45.454284+00	2012-05-22 13:06:45.454299+00	\N	\N
176	\N	Bückeburg	\N	\N	\N	\N	\N	2012-05-22 13:06:45.464166+00	2012-05-22 13:06:45.464182+00	\N	\N
177	\N	Budapest	\N	\N	\N	\N	\N	2012-05-22 13:06:45.469601+00	2012-05-22 13:06:45.469617+00	\N	\N
178	\N	Cambrai	\N	\N	\N	\N	\N	2012-05-22 13:06:45.476615+00	2012-05-22 13:06:45.476631+00	\N	\N
180	\N	Châlons-en-Champagne (Châlons-sur-Marne)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.533882+00	2012-05-22 13:06:45.533898+00	\N	\N
181	\N	Chicago	\N	\N	\N	\N	\N	2012-05-22 13:06:45.538204+00	2012-05-22 13:06:45.538219+00	\N	\N
182	\N	Chichester	\N	\N	\N	\N	\N	2012-05-22 13:06:45.542544+00	2012-05-22 13:06:45.54256+00	\N	\N
183	\N	Christchurch	\N	\N	\N	\N	\N	2012-05-22 13:06:45.556371+00	2012-05-22 13:06:45.556387+00	\N	\N
184	\N	Coburg	\N	\N	\N	\N	\N	2012-05-22 13:06:45.560578+00	2012-05-22 13:06:45.560594+00	\N	\N
185	\N	Columbia	\N	\N	\N	\N	\N	2012-05-22 13:06:45.564718+00	2012-05-22 13:06:45.564734+00	\N	\N
186	\N	Copenhagen	\N	\N	\N	\N	\N	2012-05-22 13:06:45.568876+00	2012-05-22 13:06:45.568891+00	\N	\N
187	\N	Damme	\N	\N	\N	\N	\N	2012-05-22 13:06:45.581882+00	2012-05-22 13:06:45.581898+00	\N	\N
188	\N	Darmstadt	\N	\N	\N	\N	\N	2012-05-22 13:06:45.585848+00	2012-05-22 13:06:45.585864+00	\N	\N
190	\N	Dublin	\N	\N	\N	\N	\N	2012-05-22 13:06:45.594026+00	2012-05-22 13:06:45.594042+00	\N	\N
174	\N	Brockenhurst, Hampshire	\N	\N	\N	\N	\N	2012-05-22 13:06:45.4501+00	2013-10-24 09:51:34.564108+00	\N	\N
179	\N	Cambridge	\N	\N	\N	\N	\N	2012-05-22 13:06:45.480686+00	2013-10-24 13:37:27.017159+00	\N	\N
191	\N	Düsseldorf	\N	\N	\N	\N	\N	2012-05-22 13:06:45.611248+00	2012-05-22 13:06:45.611264+00	\N	\N
192	\N	Edinburgh	\N	\N	\N	\N	\N	2012-05-22 13:06:45.618023+00	2012-05-22 13:06:45.618039+00	\N	\N
193	\N	El Escorial	\N	\N	\N	\N	\N	2012-05-22 13:06:45.625096+00	2012-05-22 13:06:45.625112+00	\N	\N
194	\N	Épinal	\N	\N	\N	\N	\N	2012-05-22 13:06:45.629212+00	2012-05-22 13:06:45.629228+00	\N	\N
195	\N	Eton	\N	\N	\N	\N	\N	2012-05-22 13:06:45.633232+00	2012-05-22 13:06:45.633248+00	\N	\N
196	\N	Évreux	\N	\N	\N	\N	\N	2012-05-22 13:06:45.637481+00	2012-05-22 13:06:45.637497+00	\N	\N
197	\N	Florence	\N	\N	\N	\N	\N	2012-05-22 13:06:45.645366+00	2012-05-22 13:06:45.645382+00	\N	\N
198	\N	Freiburg i.B.	\N	\N	\N	\N	\N	2012-05-22 13:06:45.650003+00	2012-05-22 13:06:45.650019+00	\N	\N
199	\N	Fulda	\N	\N	\N	\N	\N	2012-05-22 13:06:45.654727+00	2012-05-22 13:06:45.654743+00	\N	\N
200	\N	Geneva (Cologny-Genève)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.662323+00	2012-05-22 13:06:45.662339+00	\N	\N
201	\N	Gerleve	\N	\N	\N	\N	\N	2012-05-22 13:06:45.666296+00	2012-05-22 13:06:45.666312+00	\N	\N
202	\N	Glasgow	\N	\N	\N	\N	\N	2012-05-22 13:06:45.670389+00	2012-05-22 13:06:45.670406+00	\N	\N
203	\N	Göteborg	\N	\N	\N	\N	\N	2012-05-22 13:06:45.677508+00	2012-05-22 13:06:45.677524+00	\N	\N
204	\N	Gotha	\N	\N	\N	\N	\N	2012-05-22 13:06:45.681756+00	2012-05-22 13:06:45.681772+00	\N	\N
206	\N	Haarlem	\N	\N	\N	\N	\N	2012-05-22 13:06:45.695828+00	2012-05-22 13:06:45.695844+00	\N	\N
207	\N	Hamburg	\N	\N	\N	\N	\N	2012-05-22 13:06:45.700007+00	2012-05-22 13:06:45.700023+00	\N	\N
208	\N	Hannover	\N	\N	\N	\N	\N	2012-05-22 13:06:45.704344+00	2012-05-22 13:06:45.70436+00	\N	\N
209	\N	Hauzenstein near Regensburg	\N	\N	\N	\N	\N	2012-05-22 13:06:45.708382+00	2012-05-22 13:06:45.708398+00	\N	\N
210	\N	Herrnstein near Siegburg	\N	\N	\N	\N	\N	2012-05-22 13:06:45.715403+00	2012-05-22 13:06:45.715419+00	\N	\N
211	\N	Hertford	\N	\N	\N	\N	\N	2012-05-22 13:06:45.719617+00	2012-05-22 13:06:45.719633+00	\N	\N
213	\N	Kassel	\N	\N	\N	\N	\N	2012-05-22 13:06:45.731579+00	2012-05-22 13:06:45.731594+00	\N	\N
215	\N	Köln (Cologne)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.73985+00	2012-05-22 13:06:45.739866+00	\N	\N
216	\N	Köln	\N	\N	\N	\N	\N	2012-05-22 13:06:45.74411+00	2012-05-22 13:06:45.744127+00	\N	\N
218	\N	Lawrence	\N	\N	\N	\N	\N	2012-05-22 13:06:45.756189+00	2012-05-22 13:06:45.756205+00	\N	\N
219	\N	Le Havre	\N	\N	\N	\N	\N	2012-05-22 13:06:45.760245+00	2012-05-22 13:06:45.760261+00	\N	\N
220	\N	Leeds	\N	\N	\N	\N	\N	2012-05-22 13:06:45.764371+00	2012-05-22 13:06:45.764388+00	\N	\N
221	\N	Leiden	\N	\N	\N	\N	\N	2012-05-22 13:06:45.768593+00	2012-05-22 13:06:45.768609+00	\N	\N
222	\N	Leipzig	\N	\N	\N	\N	\N	2012-05-22 13:06:45.772624+00	2012-05-22 13:06:45.77264+00	\N	\N
223	\N	Leuven (Louvain)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.776856+00	2012-05-22 13:06:45.776871+00	\N	\N
224	\N	Lincoln	\N	\N	\N	\N	\N	2012-05-22 13:06:45.784561+00	2012-05-22 13:06:45.784577+00	\N	\N
226	\N	Louvain-la-Neuve	\N	\N	\N	\N	\N	2012-05-22 13:06:45.874141+00	2012-05-22 13:06:45.874157+00	\N	\N
227	\N	Lund	\N	\N	\N	\N	\N	2012-05-22 13:06:45.878374+00	2012-05-22 13:06:45.87839+00	\N	\N
228	\N	Luzern	\N	\N	\N	\N	\N	2012-05-22 13:06:45.882375+00	2012-05-22 13:06:45.88239+00	\N	\N
229	\N	Maaseik	\N	\N	\N	\N	\N	2012-05-22 13:06:45.88661+00	2012-05-22 13:06:45.886626+00	\N	\N
230	\N	Maidstone	\N	\N	\N	\N	\N	2012-05-22 13:06:45.89093+00	2012-05-22 13:06:45.890946+00	\N	\N
232	\N	Manchester	\N	\N	\N	\N	\N	2012-05-22 13:06:45.903571+00	2012-05-22 13:06:45.903587+00	\N	\N
233	\N	Marburg	\N	\N	\N	\N	\N	2012-05-22 13:06:45.907781+00	2012-05-22 13:06:45.907796+00	\N	\N
234	\N	Miskolc	\N	\N	\N	\N	\N	2012-05-22 13:06:45.911788+00	2012-05-22 13:06:45.911804+00	\N	\N
235	\N	Monte Cassino	\N	\N	\N	\N	\N	2012-05-22 13:06:45.916404+00	2012-05-22 13:06:45.91642+00	\N	\N
236	\N	München	\N	\N	\N	\N	\N	2012-05-22 13:06:45.92076+00	2012-05-22 13:06:45.920776+00	\N	\N
237	\N	Münster in Westfalen	\N	\N	\N	\N	\N	2012-05-22 13:06:45.931206+00	2012-05-22 13:06:45.931222+00	\N	\N
238	\N	New Haven	\N	\N	\N	\N	\N	2012-05-22 13:06:45.938933+00	2012-05-22 13:06:45.938962+00	\N	\N
239	\N	New York	\N	\N	\N	\N	\N	2012-05-22 13:06:45.943429+00	2012-05-22 13:06:45.943444+00	\N	\N
240	\N	Orléans	\N	\N	\N	\N	\N	2012-05-22 13:06:45.956197+00	2012-05-22 13:06:45.956213+00	\N	\N
241	\N	Oslo and London	\N	\N	\N	\N	\N	2012-05-22 13:06:45.964297+00	2012-05-22 13:06:45.964313+00	\N	\N
242	\N	Oslo	\N	\N	\N	\N	\N	2012-05-22 13:06:45.96911+00	2012-05-22 13:06:45.969126+00	\N	\N
243	\N	Paris	\N	\N	\N	\N	\N	2012-05-22 13:06:46.031113+00	2012-05-22 13:06:46.031129+00	\N	\N
244	\N	Philadelphia	\N	\N	\N	\N	\N	2012-05-22 13:06:46.041714+00	2012-05-22 13:06:46.04173+00	\N	\N
245	\N	Prague	\N	\N	\N	\N	\N	2012-05-22 13:06:46.046095+00	2012-05-22 13:06:46.046111+00	\N	\N
247	\N	Regensburg	\N	\N	\N	\N	\N	2012-05-22 13:06:46.061163+00	2012-05-22 13:06:46.061179+00	\N	\N
248	\N	Rheims	\N	\N	\N	\N	\N	2012-05-22 13:06:46.065376+00	2012-05-22 13:06:46.065392+00	\N	\N
249	\N	Ripon	\N	\N	\N	\N	\N	2012-05-22 13:06:46.069546+00	2012-05-22 13:06:46.069561+00	\N	\N
250	\N	Rome	\N	\N	\N	\N	\N	2012-05-22 13:06:46.073865+00	2012-05-22 13:06:46.073881+00	\N	\N
251	\N	Rouen	\N	\N	\N	\N	\N	2012-05-22 13:06:46.078476+00	2012-05-22 13:06:46.078491+00	\N	\N
253	\N	Saint-Lô	\N	\N	\N	\N	\N	2012-05-22 13:06:46.089165+00	2012-05-22 13:06:46.089181+00	\N	\N
254	\N	Saint-Omer	\N	\N	\N	\N	\N	2012-05-22 13:06:46.097071+00	2012-05-22 13:06:46.097087+00	\N	\N
256	\N	Sankt Gallen	\N	\N	\N	\N	\N	2012-05-22 13:06:46.109328+00	2012-05-22 13:06:46.109343+00	\N	\N
257	\N	Sankt Paul in Kärnten	\N	\N	\N	\N	\N	2012-05-22 13:06:46.117024+00	2012-05-22 13:06:46.117039+00	\N	\N
258	\N	Shrewsbury	\N	\N	\N	\N	\N	2012-05-22 13:06:46.122754+00	2012-05-22 13:06:46.122769+00	\N	\N
259	\N	Sondershausen	\N	\N	\N	\N	\N	2012-05-22 13:06:46.130019+00	2012-05-22 13:06:46.130035+00	\N	\N
260	\N	St Petersburg (Leningrad)	\N	\N	\N	\N	\N	2012-05-22 13:06:46.134212+00	2012-05-22 13:06:46.134228+00	\N	\N
261	\N	Stockholm	\N	\N	\N	\N	\N	2012-05-22 13:06:46.138389+00	2012-05-22 13:06:46.138405+00	\N	\N
263	\N	Stuttgart	\N	\N	\N	\N	\N	2012-05-22 13:06:46.15619+00	2012-05-22 13:06:46.156206+00	\N	\N
264	\N	The Hague	\N	\N	\N	\N	\N	2012-05-22 13:06:46.160439+00	2012-05-22 13:06:46.160454+00	\N	\N
265	\N	Tokyo	\N	\N	\N	\N	\N	2012-05-22 13:06:46.166696+00	2012-05-22 13:06:46.166712+00	\N	\N
266	\N	Urbana	\N	\N	\N	\N	\N	2012-05-22 13:06:46.170888+00	2012-05-22 13:06:46.170905+00	\N	\N
268	\N	Utrecht	\N	\N	\N	\N	\N	2012-05-22 13:06:46.179349+00	2012-05-22 13:06:46.179365+00	\N	\N
269	\N	Valenciennes	\N	\N	\N	\N	\N	2012-05-22 13:06:46.183123+00	2012-05-22 13:06:46.183139+00	\N	\N
270	\N	Växjö	\N	\N	\N	\N	\N	2012-05-22 13:06:46.18706+00	2012-05-22 13:06:46.187076+00	\N	\N
271	\N	Vercelli	\N	\N	\N	\N	\N	2012-05-22 13:06:46.190956+00	2012-05-22 13:06:46.190972+00	\N	\N
272	\N	Warsaw	\N	\N	\N	\N	\N	2012-05-22 13:06:46.194968+00	2012-05-22 13:06:46.194984+00	\N	\N
274	\N	Weimar	\N	\N	\N	\N	\N	2012-05-22 13:06:46.206316+00	2012-05-22 13:06:46.206333+00	\N	\N
275	\N	Weinheim	\N	\N	\N	\N	\N	2012-05-22 13:06:46.210239+00	2012-05-22 13:06:46.210256+00	\N	\N
276	\N	Windsor	\N	\N	\N	\N	\N	2012-05-22 13:06:46.223952+00	2012-05-22 13:06:46.223968+00	\N	\N
277	\N	Wormsley	\N	\N	\N	\N	\N	2012-05-22 13:06:46.231384+00	2012-05-22 13:06:46.231399+00	\N	\N
278	\N	Wrisbergholzen (near Alfeld/Leine)	\N	\N	\N	\N	\N	2012-05-22 13:06:46.235454+00	2012-05-22 13:06:46.23547+00	\N	\N
279	\N	Wroclaw (Breslau)	\N	\N	\N	\N	\N	2012-05-22 13:06:46.240091+00	2012-05-22 13:06:46.240106+00	\N	\N
280	\N	Würzburg	\N	\N	\N	\N	\N	2012-05-22 13:06:46.244699+00	2012-05-22 13:06:46.244714+00	\N	\N
281	\N	Zürich	\N	\N	\N	\N	\N	2012-05-22 13:06:46.252283+00	2012-05-22 13:06:46.252299+00	\N	\N
282	\N	Burton-on-Trent	\N	\N	\N	\N	\N	2012-05-22 13:06:46.265235+00	2012-05-22 13:06:46.265251+00	\N	\N
283	\N	King's Lynn	\N	\N	\N	\N	\N	2012-05-22 13:06:46.268943+00	2012-05-22 13:06:46.268968+00	\N	\N
284	\N	Stafford	\N	\N	\N	\N	\N	2012-05-22 13:06:46.280127+00	2012-05-22 13:06:46.280143+00	\N	\N
285	\N	Taunton	\N	\N	\N	\N	\N	2012-05-22 13:06:46.285576+00	2012-05-22 13:06:46.285592+00	\N	\N
286	\N	Dorset	\N	\N	\N	\N	\N	2012-05-22 13:06:46.334986+00	2012-05-22 13:06:46.335002+00	\N	\N
287	\N	Dresden	\N	\N	\N	\N	\N	2012-05-22 13:06:46.338894+00	2012-05-22 13:06:46.33891+00	\N	\N
288	\N	Tournai	\N	\N	\N	\N	\N	2012-05-22 13:06:46.345795+00	2012-05-22 13:06:46.345811+00	\N	\N
289	\N	Vatican City	\N	\N	\N	\N	\N	2012-06-05 11:05:17.780527+00	2012-06-05 11:05:17.780558+00	\N	\N
135	124	Central Production (?)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.205497+00	2013-09-17 11:19:28.941241+00	\N	\N
273	\N	Washington, D.C.	\N	\N	\N	\N	\N	2012-05-22 13:06:46.202445+00	2013-10-24 09:13:48.298352+00	\N	\N
231	\N	Los Angeles, California (formerly Malibu)	\N	\N	\N	\N	\N	2012-05-22 13:06:45.899094+00	2013-10-24 09:25:08.033704+00	\N	\N
214	\N	Kingston Lacy, Dorset	\N	\N	\N	\N	\N	2012-05-22 13:06:45.735609+00	2013-10-24 09:41:54.768768+00	\N	\N
255	\N	San Marino, California	\N	\N	\N	\N	\N	2012-05-22 13:06:46.104206+00	2013-10-24 09:32:55.267166+00	\N	\N
225	\N	Longleat House, Wiltshire	\N	\N	\N	\N	\N	2012-05-22 13:06:45.87013+00	2013-10-24 09:35:50.616582+00	\N	\N
189	\N	Deene Park, near Kettering Northamptonshire	\N	\N	\N	\N	\N	2012-05-22 13:06:45.589992+00	2013-10-24 09:47:14.537605+00	\N	\N
217	\N	Langley Marish, Buckinghamshire	\N	\N	\N	\N	\N	2012-05-22 13:06:45.748315+00	2013-10-24 09:49:36.524265+00	\N	\N
252	\N	Rygnestad, Norway	\N	\N	\N	\N	\N	2012-05-22 13:06:46.082905+00	2013-10-24 09:55:13.68899+00	\N	\N
262	\N	Stonyhurst, Lancashire	\N	\N	\N	\N	\N	2012-05-22 13:06:46.146115+00	2013-10-24 10:02:02.709013+00	\N	\N
267	\N	Ushaw, Co. Durham	\N	\N	\N	\N	\N	2012-05-22 13:06:46.175242+00	2013-10-24 10:08:07.076238+00	\N	\N
205	\N	Grand Haven, Michigan	\N	\N	\N	\N	\N	2012-05-22 13:06:45.686157+00	2013-10-24 10:09:49.520545+00	\N	\N
246	\N	Princeton	\N	\N	\N	\N	\N	2012-05-22 13:06:46.050027+00	2013-10-24 13:36:46.60291+00	\N	\N
290	\N	Cambridge, Mass.	\N	\N	\N	\N	\N	2013-10-24 13:37:44.448181+00	2013-10-24 13:37:44.448211+00	\N	\N
212	\N	Jönköping	\N	\N	\N	\N	\N	2012-05-22 13:06:45.723543+00	2014-04-14 17:50:33.10719+00	\N	\N
291	\N	Abbey of Anvin, near Douai	\N	\N	\N	\N	\N	2014-09-10 11:59:31.915556+00	2014-09-10 11:59:31.915586+00	\N	\N
292	\N	Battle	\N	\N	\N	\N	\N	2014-09-10 11:59:33.77759+00	2014-09-10 11:59:33.77762+00	\N	\N
293	\N	Bruges	\N	\N	\N	\N	\N	2014-09-10 11:59:34.714869+00	2014-09-10 11:59:34.714897+00	\N	\N
294	\N	Bury	\N	\N	\N	\N	\N	2014-09-10 11:59:34.951049+00	2014-09-10 11:59:34.951079+00	\N	\N
295	\N	Flanders	\N	\N	\N	\N	\N	2014-09-10 11:59:48.345267+00	2014-09-10 11:59:48.345296+00	\N	\N
296	\N	Great Bedwin, Wiltshire	\N	\N	\N	\N	\N	2014-09-10 11:59:49.388734+00	2014-09-10 11:59:49.388762+00	\N	\N
297	\N	Jumièges	\N	\N	\N	\N	\N	2014-09-10 11:59:51.306388+00	2014-09-10 11:59:51.306417+00	\N	\N
298	\N	Normandy	\N	\N	\N	\N	\N	2014-09-10 11:59:55.486982+00	2014-09-10 11:59:55.487012+00	\N	\N
299	\N	Paris, Notre Dame Cathedral	\N	\N	\N	\N	\N	2014-09-10 11:59:57.939773+00	2014-09-10 11:59:57.939804+00	\N	\N
300	\N	Robert of Jumièges, Bishop of London (1044--51) and A'bishop of Ca (1051--2)	\N	\N	\N	\N	\N	2014-09-10 12:00:01.369616+00	2014-09-10 12:00:01.369646+00	\N	\N
301	\N	Saint-Bertin	\N	\N	\N	\N	\N	2014-09-10 12:00:03.45808+00	2014-09-10 12:00:03.458126+00	\N	\N
302	\N	Shaftesbury	\N	\N	\N	\N	\N	2014-09-10 12:00:04.192384+00	2014-09-10 12:00:04.192416+00	\N	\N
303	\N	Sigmaringen, Bibliothek	\N	\N	\N	\N	\N	2014-09-10 12:00:04.676408+00	2014-09-10 12:00:04.67644+00	\N	\N
304	\N	St Carilef, William Bishop of Durham (d. 1096)	\N	\N	\N	\N	\N	2014-09-10 12:00:06.083873+00	2014-09-10 12:00:06.08404+00	\N	\N
305	\N	St Vaas	\N	\N	\N	\N	\N	2014-09-10 12:00:06.597839+00	2014-09-10 12:00:06.597872+00	\N	\N
306	\N	Trier	\N	\N	\N	\N	\N	2014-09-10 12:00:08.125132+00	2014-09-10 12:00:08.125189+00	\N	\N
307	\N	Woman (anon.)	\N	\N	\N	\N	\N	2014-09-10 12:00:10.059938+00	2014-09-10 12:00:10.059971+00	\N	\N
\.


--
-- Name: digipal_place_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_place_id_seq', 307, true);


--
-- Data for Name: digipal_placeevidence; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_placeevidence (id, legacy_id, hand_id, place_id, place_description, reference_id, evidence, created, modified, historical_item_id, written_as) FROM stdin;
\.


--
-- Name: digipal_placeevidence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_placeevidence_id_seq', 1, false);


--
-- Data for Name: digipal_placetype; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_placetype (id, name, created, modified) FROM stdin;
\.


--
-- Name: digipal_placetype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_placetype_id_seq', 1, false);


--
-- Data for Name: digipal_proportion; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_proportion (id, legacy_id, hand_id, measurement_id, description, cue_height, value, created, modified) FROM stdin;
\.


--
-- Name: digipal_proportion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_proportion_id_seq', 1, false);


--
-- Data for Name: digipal_reference; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_reference (id, legacy_id, name, name_index, legacy_reference, full_reference, created, modified) FROM stdin;
\.


--
-- Name: digipal_reference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_reference_id_seq', 1, false);


--
-- Data for Name: digipal_region; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_region (id, name, created, modified) FROM stdin;
1	Wessex	2012-05-22 13:06:44.539091+00	2012-05-22 13:06:44.539107+00
2	South West	2012-05-22 13:06:44.541034+00	2012-05-22 13:06:44.54105+00
3	Kent	2012-05-22 13:06:44.542691+00	2012-05-22 13:06:44.542706+00
4	Mercia	2012-05-22 13:06:44.546113+00	2012-05-22 13:06:44.546128+00
5	Northumbria	2012-05-22 13:06:44.548616+00	2012-05-22 13:06:44.548632+00
6	Fenland	2012-05-22 13:06:44.550316+00	2012-05-22 13:06:44.550332+00
7	East Anglia	2012-05-22 13:06:44.551969+00	2012-05-22 13:06:44.552017+00
8	London vicinity	2012-05-22 13:06:44.557178+00	2012-05-22 13:06:44.557194+00
9	Fenlands	2012-05-22 13:06:44.558768+00	2012-05-22 13:06:44.558784+00
\.


--
-- Name: digipal_region_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_region_id_seq', 9, true);


--
-- Data for Name: digipal_repository; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_repository (id, legacy_id, name, short_name, place_id, url, comma, british_isles, digital_project, created, modified, copyright_notice, media_permission_id, type_id, part_of_id) FROM stdin;
1	\N	BL	\N	1	\N	\N	\N	\N	2015-03-13 18:43:34.362+00	2015-03-13 18:43:34.362+00	\N	\N	\N	\N
2	\N	Cambridge University Library	CUL	179		\N	\N	\N	2017-04-22 17:02:47.178043+00	2017-04-22 17:13:39.49026+00	<p>Copyright (C) Cambridge University Library. Licensed under Creative Commons Attribution-NonCommercial 3.0 Unported License (CC BY-NC 3.0).</p>	2	\N	\N
\.


--
-- Name: digipal_repository_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_repository_id_seq', 2, true);


--
-- Data for Name: digipal_requestlog; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_requestlog (id, request, created, result_count) FROM stdin;
1	http://localhost:32769/digipal/search/?from_link=true&s=1	2017-04-21 18:19:02.698018+00	1
2	http://localhost:32769/digipal/search/?from_link=true&s=1&result_type=graphs	2017-04-21 20:50:18.170825+00	11
3	http://localhost:32769/digipal/search/	2017-04-21 21:02:50.213815+00	-4
4	http://localhost:32859/digipal/search/?s=1&terms=&result_type=images&from_link=true	2017-08-29 20:23:00.241751+00	1
\.


--
-- Name: digipal_requestlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_requestlog_id_seq', 4, true);


--
-- Data for Name: digipal_scribe; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_scribe (id, legacy_id, name, date, scriptorium_id, created, modified, legacy_reference) FROM stdin;
\.


--
-- Name: digipal_scribe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_scribe_id_seq', 1, false);


--
-- Data for Name: digipal_scribe_reference; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_scribe_reference (id, scribe_id, reference_id) FROM stdin;
\.


--
-- Name: digipal_scribe_reference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_scribe_reference_id_seq', 1, false);


--
-- Data for Name: digipal_script; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_script (id, legacy_id, name, created, modified) FROM stdin;
1	\N	Caroline minuscule	2012-09-24 11:06:54.555+00	2012-09-24 11:06:54.555+00
2	999	English Vernacular minuscule	2012-09-24 11:09:12.937+00	2012-09-24 11:09:12.937+00
3	\N	Square minuscule	2012-11-27 14:42:35.196+00	2012-11-27 14:42:35.196+00
4	\N	Insular Cursive minuscule	2014-04-03 13:03:06.083+00	2014-04-03 13:03:06.083+00
\.


--
-- Data for Name: digipal_script_allographs; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_script_allographs (id, script_id, allograph_id) FROM stdin;
1	1	30
2	1	37
3	1	29
4	1	34
5	1	24
6	1	25
7	1	27
8	1	21
9	1	48
10	1	46
11	1	44
12	1	45
13	1	42
14	1	43
15	1	1
16	1	3
17	1	2
18	1	5
19	1	4
20	1	6
21	1	9
22	1	8
23	1	10
24	1	13
25	1	15
26	1	14
27	1	17
28	1	16
29	1	19
30	1	32
31	1	57
32	1	56
33	1	51
34	1	50
35	1	35
36	1	52
37	1	33
38	1	31
39	2	56
40	2	36
41	2	34
42	2	25
43	2	26
44	2	27
45	2	20
46	2	22
47	2	49
48	2	46
49	2	47
50	2	44
51	2	45
52	2	28
53	2	43
54	2	40
55	2	41
56	2	1
57	2	3
58	2	2
59	2	5
60	2	4
61	2	7
62	2	6
63	2	9
64	2	8
65	2	12
66	2	30
67	2	11
68	2	10
69	2	39
70	2	38
71	2	15
72	2	48
73	2	17
74	2	16
75	2	33
76	2	18
77	2	31
78	2	23
79	2	51
80	2	50
81	2	35
82	2	52
83	2	32
84	3	56
85	3	34
86	3	25
87	3	26
88	3	27
89	3	20
90	3	49
91	3	46
92	3	47
93	3	44
94	3	45
95	3	28
96	3	43
97	3	40
98	3	41
99	3	1
100	3	3
101	3	2
102	3	5
103	3	4
104	3	7
105	3	6
106	3	9
107	3	8
108	3	12
109	3	30
110	3	38
111	3	15
112	3	17
113	3	16
114	3	33
115	3	18
116	3	31
117	3	23
118	3	51
119	3	50
120	3	35
121	3	52
122	3	32
123	4	30
124	4	34
125	4	25
126	4	26
127	4	27
128	4	20
129	4	22
130	4	49
131	4	46
132	4	47
133	4	44
134	4	45
135	4	28
136	4	43
137	4	40
138	4	1
139	4	3
140	4	2
141	4	5
142	4	4
143	4	7
144	4	6
145	4	9
146	4	8
147	4	11
148	4	10
149	4	38
150	4	15
151	4	17
152	4	16
153	4	33
154	4	18
155	4	31
156	4	56
157	4	51
158	4	50
159	4	35
160	4	52
161	4	32
\.


--
-- Name: digipal_script_allographs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_script_allographs_id_seq', 161, true);


--
-- Name: digipal_script_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_script_id_seq', 4, true);


--
-- Data for Name: digipal_scriptcomponent; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_scriptcomponent (id, script_id, component_id, created, modified) FROM stdin;
\.


--
-- Data for Name: digipal_scriptcomponent_features; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_scriptcomponent_features (id, scriptcomponent_id, feature_id) FROM stdin;
\.


--
-- Name: digipal_scriptcomponent_features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_scriptcomponent_features_id_seq', 1, false);


--
-- Name: digipal_scriptcomponent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_scriptcomponent_id_seq', 1, false);


--
-- Data for Name: digipal_source; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_source (id, name, label, created, modified, priority, label_styled, label_slug) FROM stdin;
1	Cambridge University Digital Library	CU Digital Library	2017-04-22 17:05:15.80089+00	2017-04-22 17:05:15.800936+00	0		cu-digital-library
2	Gneuss, Handlist of Anglo-Saxon Manuscripts	Gneuss	2017-04-22 17:23:47.494598+00	2017-04-22 17:23:47.494625+00	0	Gneuss, _Handlist_	gneuss
\.


--
-- Name: digipal_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_source_id_seq', 2, true);


--
-- Data for Name: digipal_status; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_status (id, name, "default", created, modified) FROM stdin;
\.


--
-- Name: digipal_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_status_id_seq', 1, false);


--
-- Data for Name: digipal_stewartrecord; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_stewartrecord (id, scragg, repository, shelf_mark, fols, gneuss, sp, ker, locus, selected, adate, location, surrogates, contents, notes, em, glosses, minor, charter, cartulary, eel, stokes_db, ker_hand, import_messages, matched_hands) FROM stdin;
\.


--
-- Name: digipal_stewartrecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_stewartrecord_id_seq', 1, false);


--
-- Data for Name: digipal_text; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text (id, name, created, modified, legacy_id, date, url, date_sort) FROM stdin;
\.


--
-- Data for Name: digipal_text_categories; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_categories (id, text_id, category_id) FROM stdin;
\.


--
-- Name: digipal_text_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_categories_id_seq', 1, false);


--
-- Data for Name: digipal_text_entryhand; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_entryhand (id, item_part_id, entry_number, hand_label, "order", correction, certainty, created, modified) FROM stdin;
\.


--
-- Name: digipal_text_entryhand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_entryhand_id_seq', 1, false);


--
-- Name: digipal_text_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_id_seq', 1, false);


--
-- Data for Name: digipal_text_languages; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_languages (id, text_id, language_id) FROM stdin;
\.


--
-- Name: digipal_text_languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_languages_id_seq', 1, false);


--
-- Data for Name: digipal_text_textannotation; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_textannotation (id, annotation_id, elementid, created, modified) FROM stdin;
1	28	[["", "person"], ["type", "name"], ["@text", "salmus-david"]]	2017-08-29 20:50:07.962885+00	2017-08-29 20:50:07.962904+00
\.


--
-- Name: digipal_text_textannotation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_textannotation_id_seq', 1, true);


--
-- Data for Name: digipal_text_textcontent; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_textcontent (id, type_id, item_part_id, created, modified, text_id) FROM stdin;
3	1	2	2017-04-22 18:24:51.969586+00	2017-04-22 18:24:51.969649+00	\N
4	2	2	2017-04-22 18:24:51.972908+00	2017-04-22 18:24:51.972965+00	\N
\.


--
-- Name: digipal_text_textcontent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_textcontent_id_seq', 5, true);


--
-- Data for Name: digipal_text_textcontent_languages; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_textcontent_languages (id, textcontent_id, language_id) FROM stdin;
\.


--
-- Name: digipal_text_textcontent_languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_textcontent_languages_id_seq', 1, false);


--
-- Data for Name: digipal_text_textcontenttype; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_textcontenttype (id, name, created, modified, slug) FROM stdin;
1	Transcription	2017-04-21 18:20:56.680254+00	2017-04-21 18:20:56.680291+00	transcription
2	Translation	2017-04-21 18:21:04.44404+00	2017-04-21 18:21:04.444086+00	translation
\.


--
-- Name: digipal_text_textcontenttype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_textcontenttype_id_seq', 2, true);


--
-- Data for Name: digipal_text_textcontentxml; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_textcontentxml (id, status_id, text_content_id, created, modified, content, last_image_id) FROM stdin;
3	1	4	2017-04-22 18:24:51.994253+00	2017-04-22 21:43:43.710131+00	<p><span data-dpt="location" data-dpt-loctype="locus">8v</span></p>\n<p>Give ear, O Lord, to my words, understand my cry.</p>\n<p>Hearken to the voice of my prayer, O my King and my God.</p>\n<p>For to thee will I pray: O Lord, in the morning thou shalt hear my voice.</p>\n<p>In the morning I will stand before thee, and will see: because thou art not a God that willest iniquity.</p>\n<p>Neither shall the wicked dwell near thee</p>	\N
4	2	3	2017-04-22 18:24:51.995055+00	2017-08-29 20:29:23.803786+00	<p><span data-dpt="location" data-dpt-loctype="locus">8v</span></p>\n<p>in pace in id ipsum ob dormia<span data-dpt="ex" data-dpt-cat="chars">m</span> et requiescam ./<span data-dpt="lb" data-dpt-src="prj">&brvbar;</span>quoniam tu Domine <span data-dpt="supplied" data-dpt-cat="chars">singulariter</span> in <span data-dpt="del" data-dpt-cat="words">spe</span> constituisti me. <span data-dpt="lb" data-dpt-src="ms">|</span><span data-dpt="lb" data-dpt-src="prj">&brvbar;</span> <span data-dpt="person" data-dpt-cat="chars" data-dpt-type="name">SALMUS DAVID</span> :. <span data-dpt="lb" data-dpt-src="ms">|</span> Verba mea auribus perci<span data-dpt="lb" data-dpt-src="ms">|</span>pe domine .<span data-dpt="lb" data-dpt-src="prj">&brvbar;</span>intellege clamore<span data-dpt="ex" data-dpt-cat="chars">m</span> meum ./<span data-dpt="lb" data-dpt-src="prj">&brvbar;</span>intende uoci oratio<span data-dpt="lb" data-dpt-src="ms">|</span>nis mee ./<span data-dpt="lb" data-dpt-src="prj">&brvbar;</span>rex meus et deus meus :,<span data-dpt="lb" data-dpt-src="ms">|</span>Quoniam ad te orabo domine<span data-dpt="lb" data-dpt-src="ms">|</span>mane ./<span data-dpt="lb" data-dpt-src="prj">&brvbar;</span>et exaudies uocem meam :,<span data-dpt="lb" data-dpt-src="ms">|<span data-dpt="lb" data-dpt-src="prj">&brvbar;</span></span>Mane astabo tibi et uidebo ./<span data-dpt="lb" data-dpt-src="ms">|<span data-dpt="lb" data-dpt-src="prj">&brvbar;</span></span>quoniam non uolens deus<span data-dpt="lb" data-dpt-src="ms">|</span>iniquitatem tues<span data-dpt="lb" data-dpt-src="ms">|<span data-dpt="lb" data-dpt-src="prj">&brvbar;</span></span>&nbsp;Non&nbsp;habitabit iuxta te malign<span data-dpt="ex" data-dpt-cat="chars">us</span></p>	\N
\.


--
-- Name: digipal_text_textcontentxml_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_textcontentxml_id_seq', 4, true);


--
-- Name: digipal_text_textcontentxmlcopy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_textcontentxmlcopy_id_seq', 8, true);


--
-- Data for Name: digipal_text_textcontentxmlstatus; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_textcontentxmlstatus (id, name, created, modified, slug, sort_order) FROM stdin;
1	Draft	2016-09-27 22:11:23.852118+00	2016-09-27 22:11:23.852918+00	draft	10
2	Live	2016-09-27 22:11:23.854543+00	2016-09-27 22:11:23.855011+00	live	100
\.


--
-- Name: digipal_text_textcontentxmlstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_textcontentxmlstatus_id_seq', 2, true);


--
-- Data for Name: digipal_text_textpattern; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_text_textpattern (id, title, key, pattern, "order", description, created, modified) FROM stdin;
\.


--
-- Name: digipal_text_textpattern_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_text_textpattern_id_seq', 1, false);


--
-- Data for Name: digipal_textitempart; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY digipal_textitempart (id, locus, item_part_id, text_id, created, modified, date) FROM stdin;
\.


--
-- Name: digipal_textitempart_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('digipal_textitempart_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
1	2017-04-21 18:19:59.588769+00	1	31	1	Private [Private]	1	
2	2017-04-21 18:20:08.5723+00	1	78	1	BL IP1	2	Changed keywords. Changed locus, iipimage, custom_label and media_permission for image "BL IP1: 121v".
3	2017-04-21 18:20:56.682006+00	1	101	1	Transcription	1	
4	2017-04-21 18:21:04.445283+00	1	101	2	Translation	1	
5	2017-04-21 21:01:51.554748+00	1	97	1	Annotate scripts according to your alphabet	1	
6	2017-04-21 21:02:13.283003+00	1	97	2	Manipulate images in the Lightbox	1	
7	2017-04-21 21:22:28.635174+00	1	18	1	Blog	1	
8	2017-04-21 21:24:30.060596+00	1	17	1	First Blog Post	1	
9	2017-04-21 21:24:43.714333+00	1	18	2	News	1	
10	2017-04-21 21:25:01.595367+00	1	17	2	First News Item	1	
11	2017-04-21 21:25:29.498875+00	1	3	1	admin	2	Changed first_name.
12	2017-04-22 17:02:44.902912+00	1	31	2	CC BY-NC 3.0 [Full Resolution]	1	
13	2017-04-22 17:02:47.202051+00	1	68	2	CUL	1	
14	2017-04-22 17:03:21.591153+00	1	69	2	CUL Ff.1.23	1	
15	2017-04-22 17:05:15.804874+00	1	55	1	CU Digital Library	1	
16	2017-04-22 17:05:45.784251+00	1	54	2	document	1	
17	2017-04-22 17:06:04.842226+00	1	54	2	document Winchcombe Psalter	2	Changed name and date.
18	2017-04-22 17:07:36.545847+00	1	54	2	document Winchcombe Psalter	2	Changed description for description "document Winchcombe Psalter CU Digital Library".
19	2017-04-22 17:08:08.586598+00	1	85	1	BL IP1: 121v	3	
20	2017-04-22 17:08:27.557044+00	1	78	1	BL IP1	3	
21	2017-04-22 17:08:39.019683+00	1	69	1	BL IP1	3	
22	2017-04-22 17:08:48.88221+00	1	54	1	document	3	
23	2017-04-22 17:09:17.423832+00	1	52	2	manuscript	1	
24	2017-04-22 17:09:24.058381+00	1	50	1	codex	1	
25	2017-04-22 17:09:26.998061+00	1	54	2	manuscript Winchcombe Psalter	2	Changed historical_item_type and historical_item_format.
26	2017-04-22 17:10:21.780549+00	1	48	1	saec. xi1/4	1	
27	2017-04-22 17:12:34.106091+00	1	78	2	CUL Ff.1.23	2	Changed keywords. Added hand "Main Hand". Added image "CUL Ff.1.23: 8v".
28	2017-04-22 17:13:39.49203+00	1	68	2	CUL	2	Changed copyright_notice.
29	2017-04-22 17:17:19.240005+00	1	78	2	CUL Ff.1.23	2	Changed keywords. Changed images for hand "Main Hand".
30	2017-04-22 17:23:47.496722+00	1	55	2	Gneuss	1	
31	2017-04-22 17:23:59.962802+00	1	54	2	manuscript Gneuss 4 Winchcombe Psalter	2	Added catalogue number "Gneuss 4".
32	2017-04-22 17:45:58.110089+00	1	15	3	Fragments	1	
33	2017-04-22 17:47:53.566272+00	1	15	4	Fragments / footer	1	
34	2017-04-22 17:49:38.455284+00	1	15	5	Fragments / footer.logos	1	
35	2017-04-22 17:50:09.646631+00	1	15	4	Fragments / footer	2	Changed content and keywords.
36	2017-04-22 17:55:03.272643+00	1	15	5	Fragments / footer.logos	2	Changed content and keywords.
37	2017-04-22 17:57:05.407733+00	1	15	5	Fragments / footer.logos	2	Changed content and keywords.
38	2017-04-22 17:58:57.550862+00	1	15	5	Fragments / footer.logos	2	Changed content and keywords.
39	2017-04-22 17:59:13.641547+00	1	15	5	Fragments / footer.logos	2	Changed content and keywords.
40	2017-04-22 18:00:12.024184+00	1	15	5	Fragments / footer.logos	2	Changed content and keywords.
41	2017-04-22 18:02:20.786846+00	1	15	5	Fragments / footer.logos	2	Changed content and keywords.
42	2017-04-22 18:02:29.117935+00	1	15	4	Fragments / footer	2	Changed content and keywords.
43	2017-04-22 18:03:41.185865+00	1	15	4	Fragments / footer	2	Changed content and keywords.
44	2017-04-22 18:03:55.984424+00	1	15	5	Fragments / footer.logos	2	Changed status, content and keywords.
45	2017-04-22 18:04:07.693133+00	1	15	4	Fragments / footer	2	Changed content and keywords.
46	2017-04-22 18:06:38.046494+00	1	15	4	Fragments / footer	2	Changed content and keywords.
47	2017-04-22 18:06:42.953416+00	1	15	5	Fragments / footer.logos	2	Changed content and keywords.
48	2017-04-22 18:09:21.822293+00	1	15	5	Fragments / footer.logos	2	Changed content and keywords.
49	2017-04-22 18:10:14.348505+00	1	15	5	Fragments / footer.logos	2	Changed content and keywords.
50	2017-04-22 18:10:32.885354+00	1	15	4	Fragments / footer	2	Changed content and keywords.
51	2017-04-22 18:10:55.033731+00	1	15	6	About	1	
52	2017-04-22 18:14:31.536552+00	1	15	7	About / Privacy and Cookie Policy	1	
53	2017-04-22 18:16:29.213704+00	1	15	8	About / The DigiPal Framework	1	
54	2017-04-22 18:17:43.165117+00	1	16	9	Lightbox	1	
55	2017-08-29 20:01:39.934074+00	1	97	2	Manipulate images in the Lightbox	2	Changed image_file.
56	2017-08-29 21:00:53.710543+00	1	15	4	Fragments / footer	2	Changed content and keywords.
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 56, true);


--
-- Data for Name: django_comment_flags; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY django_comment_flags (id, user_id, comment_id, flag, flag_date) FROM stdin;
\.


--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('django_comment_flags_id_seq', 1, false);


--
-- Data for Name: django_comments; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY django_comments (id, content_type_id, object_pk, site_id, user_id, user_name, user_email, user_url, comment, submit_date, ip_address, is_public, is_removed) FROM stdin;
\.


--
-- Name: django_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('django_comments_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	auth	user
4	contenttypes	contenttype
5	redirects	redirect
6	sessions	session
7	sites	site
8	south	migrationhistory
9	admin	logentry
10	comments	comment
11	comments	commentflag
12	conf	setting
13	core	sitepermission
14	pages	page
15	pages	richtextpage
16	pages	link
17	blog	blogpost
18	blog	blogcategory
19	generic	threadedcomment
20	generic	keyword
21	generic	assignedkeyword
22	generic	rating
23	forms	form
24	forms	field
25	forms	formentry
26	forms	fieldentry
27	galleries	gallery
28	galleries	galleryimage
29	twitter	query
30	twitter	tweet
31	digipal	mediapermission
32	digipal	appearance
33	digipal	feature
34	digipal	component
35	digipal	componentfeature
36	digipal	aspect
37	digipal	ontographtype
38	digipal	ontograph
39	digipal	characterform
40	digipal	character
41	digipal	allograph
42	digipal	allographcomponent
43	digipal	text
44	digipal	script
45	digipal	scriptcomponent
46	digipal	reference
47	digipal	owner
48	digipal	date
49	digipal	category
50	digipal	format
51	digipal	hair
52	digipal	historicalitemtype
53	digipal	language
54	digipal	historicalitem
55	digipal	source
56	digipal	cataloguenumber
57	digipal	collation
58	digipal	decoration
59	digipal	description
60	digipal	layout
61	digipal	itemorigin
62	digipal	archive
63	digipal	region
64	digipal	county
65	digipal	placetype
66	digipal	place
67	digipal	ownertype
68	digipal	repository
69	digipal	currentitem
70	digipal	person
71	digipal	institutiontype
72	digipal	institution
73	digipal	scribe
74	digipal	idiograph
75	digipal	idiographcomponent
76	digipal	historicalitemdate
77	digipal	itemparttype
78	digipal	itempart
79	digipal	itempartitem
80	digipal	itempartauthenticity
81	digipal	authenticitycategory
82	digipal	textitempart
83	digipal	latinstyle
84	digipal	imageannotationstatus
85	digipal	image
86	digipal	hand
87	digipal	handdescription
88	digipal	alphabet
89	digipal	dateevidence
90	digipal	graph
91	digipal	graphcomponent
92	digipal	status
93	digipal	annotation
94	digipal	placeevidence
95	digipal	measurement
96	digipal	proportion
97	digipal	carouselitem
98	digipal	stewartrecord
99	digipal	requestlog
100	digipal	apitransform
101	digipal_text	textcontenttype
102	digipal_text	textcontent
103	digipal_text	textcontentxmlstatus
104	digipal_text	textcontentxmlcopy
105	digipal_text	textcontentxml
106	digipal_text	textannotation
107	digipal_text	entryhand
108	reversion	revision
109	reversion	version
110	digipal	hand_images
111	digipal	keyval
112	digipal_text	textpattern
113	django_comments	comment
114	django_comments	commentflag
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('django_content_type_id_seq', 114, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2017-08-29 20:43:50.614226+00
2	auth	0001_initial	2017-08-29 20:43:50.635631+00
3	admin	0001_initial	2017-08-29 20:43:50.651103+00
4	contenttypes	0002_remove_content_type_name	2017-08-29 20:43:50.694548+00
5	auth	0002_alter_permission_name_max_length	2017-08-29 20:43:50.714638+00
6	auth	0003_alter_user_email_max_length	2017-08-29 20:43:50.733854+00
7	auth	0004_alter_user_username_opts	2017-08-29 20:43:50.755282+00
8	auth	0005_alter_user_last_login_null	2017-08-29 20:43:50.773975+00
9	auth	0006_require_contenttypes_0002	2017-08-29 20:43:50.779635+00
10	sites	0001_initial	2017-08-29 20:43:50.790353+00
11	blog	0001_initial	2017-08-29 20:43:50.8182+00
12	blog	0002_auto_20150527_1555	2017-08-29 20:43:50.858377+00
13	conf	0001_initial	2017-08-29 20:43:50.893641+00
14	core	0001_initial	2017-08-29 20:43:50.920284+00
15	core	0002_auto_20150414_2140	2017-08-29 20:43:50.966494+00
16	digipal	0001_initial	2017-08-29 20:44:03.281318+00
17	digipal	0002_auto_20170705_0056	2017-08-29 20:44:31.971387+00
18	digipal	0003_auto_20170717_2037	2017-08-29 20:44:32.751365+00
19	digipal_text	0001_initial	2017-08-29 20:44:35.671205+00
20	digipal_text	0002_auto_20170705_0056	2017-08-29 20:44:37.734076+00
21	django_comments	0001_initial	2017-08-29 20:44:38.696913+00
22	django_comments	0002_update_user_email_field_length	2017-08-29 20:44:38.903555+00
23	django_comments	0003_add_submit_date_index	2017-08-29 20:44:39.130731+00
24	pages	0001_initial	2017-08-29 20:44:39.382746+00
25	forms	0001_initial	2017-08-29 20:44:40.267144+00
26	forms	0002_auto_20141227_0224	2017-08-29 20:44:40.880142+00
27	forms	0003_emailfield	2017-08-29 20:44:41.099504+00
28	forms	0004_auto_20150517_0510	2017-08-29 20:44:41.398569+00
29	forms	0005_auto_20151026_1600	2017-08-29 20:44:41.660376+00
30	galleries	0001_initial	2017-08-29 20:44:42.111446+00
31	galleries	0002_auto_20141227_0224	2017-08-29 20:44:42.349894+00
32	generic	0001_initial	2017-08-29 20:44:43.878014+00
33	generic	0002_auto_20141227_0224	2017-08-29 20:44:44.140681+00
34	pages	0002_auto_20141227_0224	2017-08-29 20:44:44.674298+00
35	pages	0003_auto_20150527_1555	2017-08-29 20:44:44.961002+00
36	redirects	0001_initial	2017-08-29 20:44:45.596689+00
37	reversion	0001_initial	2017-08-29 20:44:46.062352+00
38	reversion	0002_auto_20141216_1509	2017-08-29 20:44:46.356981+00
39	sessions	0001_initial	2017-08-29 20:44:46.380526+00
40	twitter	0001_initial	2017-08-29 20:44:46.407208+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('django_migrations_id_seq', 40, true);


--
-- Data for Name: django_redirect; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY django_redirect (id, site_id, old_path, new_path) FROM stdin;
\.


--
-- Name: django_redirect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('django_redirect_id_seq', 1, false);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
wslfdrygmv5phkhfzk1knt6t65nzzkcg	NjczODBhYTc1MzZlMDAxYmU5MmY0YzY3YjM5ZjgyNDQ0NjkyMWNjNTp7fQ==	2017-05-05 21:28:56.531668+00
7ti54ikep4e29mlh73n9w588ndhhr231	MDg2MmQyZGNiYmE4MWFlOWE3ZDA3ZDczMzI3NGE0M2JhM2YxOGViYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2017-05-06 16:59:03.342957+00
3tmwqlxwrcd4leq4z3y8brve21w5a4lr	NjczODBhYTc1MzZlMDAxYmU5MmY0YzY3YjM5ZjgyNDQ0NjkyMWNjNTp7fQ==	2017-09-12 12:49:04.617437+00
142e3qnn2j0fa0q57hxc21ackn4zhxtg	NjczODBhYTc1MzZlMDAxYmU5MmY0YzY3YjM5ZjgyNDQ0NjkyMWNjNTp7fQ==	2017-09-12 12:49:06.112485+00
v2bqoorccp8g9t4ljgxm4h7828sc8vt2	NjczODBhYTc1MzZlMDAxYmU5MmY0YzY3YjM5ZjgyNDQ0NjkyMWNjNTp7fQ==	2017-09-12 18:30:33.843536+00
q6cyuucbwix6mibc268xt6g2eym18gjp	MDg2MmQyZGNiYmE4MWFlOWE3ZDA3ZDczMzI3NGE0M2JhM2YxOGViYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2017-09-12 18:44:37.748361+00
85ug3wdwrefkv65hkre2be7v3k8d4md2	MDg2MmQyZGNiYmE4MWFlOWE3ZDA3ZDczMzI3NGE0M2JhM2YxOGViYzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2017-09-12 19:58:03.904643+00
so6tgvilgddwp7vnao0xmyiq88syvchd	N2RjOWJiMTczNjhiNzg5YTI1MWExZGViMWQzOTM5MDA3ODFmYzJiMzp7Il9hdXRoX3VzZXJfaGFzaCI6ImViYTRmNjc5YWNkNTQ4NTBhMTRmNWE2MGQ1MGI0MTdiNWM0MDVmZGMiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2017-09-12 20:48:33.315442+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY django_site (id, domain, name) FROM stdin;
1	127.0.0.1:8000	Default
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Data for Name: forms_field; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY forms_field (_order, form_id, "default", required, label, visible, help_text, choices, id, placeholder_text, field_type) FROM stdin;
\.


--
-- Name: forms_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('forms_field_id_seq', 1, false);


--
-- Data for Name: forms_fieldentry; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY forms_fieldentry (entry_id, field_id, id, value) FROM stdin;
\.


--
-- Name: forms_fieldentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('forms_fieldentry_id_seq', 1, false);


--
-- Data for Name: forms_form; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY forms_form (email_message, page_ptr_id, email_copies, button_text, response, content, send_email, email_subject, email_from) FROM stdin;
\.


--
-- Data for Name: forms_formentry; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY forms_formentry (entry_time, id, form_id) FROM stdin;
\.


--
-- Name: forms_formentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('forms_formentry_id_seq', 1, false);


--
-- Data for Name: galleries_gallery; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY galleries_gallery (page_ptr_id, content, zip_import) FROM stdin;
\.


--
-- Data for Name: galleries_galleryimage; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY galleries_galleryimage (id, _order, gallery_id, file, description) FROM stdin;
\.


--
-- Name: galleries_galleryimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('galleries_galleryimage_id_seq', 1, false);


--
-- Data for Name: generic_assignedkeyword; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY generic_assignedkeyword (content_type_id, id, keyword_id, object_pk, _order) FROM stdin;
\.


--
-- Name: generic_assignedkeyword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('generic_assignedkeyword_id_seq', 1, false);


--
-- Data for Name: generic_keyword; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY generic_keyword (slug, id, title, site_id) FROM stdin;
\.


--
-- Name: generic_keyword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('generic_keyword_id_seq', 1, false);


--
-- Data for Name: generic_rating; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY generic_rating (content_type_id, id, value, object_pk, rating_date, user_id) FROM stdin;
\.


--
-- Name: generic_rating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('generic_rating_id_seq', 1, false);


--
-- Data for Name: generic_threadedcomment; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY generic_threadedcomment (by_author, comment_ptr_id, replied_to_id, rating_count, rating_average, rating_sum) FROM stdin;
\.


--
-- Data for Name: pages_link; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY pages_link (page_ptr_id) FROM stdin;
2
1
9
\.


--
-- Data for Name: pages_page; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY pages_page (status, _order, parent_id, description, title, short_url, login_required, id, expiry_date, publish_date, titles, content_model, slug, keywords_string, site_id, gen_description, in_menus, _meta_title, in_sitemap, created, updated) FROM stdin;
2	0	6	This website is based on the DigiPal Framework. This is generic, open-source software for the analysis and presentation of palaeographical and related materials and texts. It was first developed as part of the Digital Resource and Database for Palaeography, Manuscript Studies and Diplomatic (DigiPal), a project funded by the European Research Council to bring digital technology to bear on scholarly discussion of medieval handwriting. A large part of this work has been the development of a freely-available generalised framework for the online presentation of images with structured annotations and data which allows scholars to search for, view, and organise detailed characteristics of handwriting or other material in both verbal and visual form. It was then extended as part of subsequent projects, particularly Models of Authority and the Conqueror's Commissioners, both of which were funded by the Arts and Humanities Research Council (AHRC, UK). To date it is being used for the following material:	The DigiPal Framework	\N	f	8	\N	2017-04-22 18:16:29.184715+00	About / The DigiPal Framework	richtextpage	about/the-digipal-framework		1	t	1,2,3		t	2017-04-22 18:16:29.194644+00	2017-04-22 18:16:29.2029+00
2	1	6	The DigiPal Framework uses cookies to give you a more personal browsing experience. Cookies are small files stored on your computer that remember some of your preferences and actions on the site. DigiPal Framework cookies are not used to identify you personally. 	Privacy and Cookie Policy	\N	f	7	\N	2017-04-22 18:14:31.484838+00	About / Privacy and Cookie Policy	richtextpage	about/privacy-and-cookie-policy		1	t	1,2,3		t	2017-04-22 18:14:31.502977+00	2017-04-22 18:14:31.522067+00
2	0	\N	Search	Search	\N	f	1	\N	2015-03-13 13:26:19+00	Search	link	/digipal/search/facets/?page=1&result_type=images&view=grid		1	t	1	\N	f	2015-03-13 13:26:19.104+00	2015-03-13 13:28:36.855+00
2	1	\N	Collection	Collection	\N	f	2	\N	2015-03-13 13:27:26.999+00	Collection	link	digipal/collection/		1	t	1	\N	f	2015-03-13 13:27:27.001+00	2015-03-13 13:27:27.001+00
2	2	\N	Lightbox	Lightbox	\N	f	9	\N	2017-04-22 18:17:43.159991+00	Lightbox	link	/lightbox/		1	t	1,2,3	\N	f	2017-04-22 18:17:43.161205+00	2017-04-22 18:17:43.161205+00
1	3	\N	Fragments	Fragments	\N	f	3	\N	2017-04-22 17:45:58.081905+00	Fragments	richtextpage	fragments		1	t			t	2017-04-22 17:45:58.087017+00	2017-04-22 17:45:58.087017+00
2	4	\N	x	About	\N	f	6	\N	2017-04-22 18:10:55.013797+00	About	richtextpage	about		1	t	1,2,3		t	2017-04-22 18:10:55.021648+00	2017-04-22 18:10:55.021648+00
1	1	3		footer.logos	\N	f	5	\N	2017-04-22 17:49:38+00	Fragments / footer.logos	richtextpage	fragments/footerlogos		1	t	1,2,3		t	2017-04-22 17:49:38.430765+00	2017-04-22 18:10:14.337083+00
2	0	3	FOOOTER The DigiPal Framework is developed by the Department of Digital Humanities at King's College London. It has received funding from the European Union Seventh Framework Programme (FP7) under Grant Agreement no. 263751 (DigiPal), and the Arts and Humanities Research Council (AHRC) under Grant Reference n° AH/L008041/1 (Models of Authority) and AH/L013975/1 (Exon Domesday). For further information including the software source see https://github.com/kcl-ddh/digipal/wiki.	footer	\N	f	4	\N	2017-04-22 17:47:53+00	Fragments / footer	richtextpage	fragments/footer		1	t	1,2,3		t	2017-04-22 17:47:53.526007+00	2017-08-29 21:00:53.704262+00
\.


--
-- Name: pages_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('pages_page_id_seq', 9, true);


--
-- Data for Name: pages_richtextpage; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY pages_richtextpage (content, page_ptr_id) FROM stdin;
	3
<p><img src="/media/uploads/images/ddh.png" width="57"><img src="/media/uploads/images/erc-logo.gif" width="60"><img src="/media/uploads/images/europ_flag.png" height="55" width="81"><img src="/media/uploads/images/fp7logo.png" height="60" width="74"><img src="/media/uploads/images/ahrc_logo.gif" height="46" width="200"></p>	5
<p>x</p>	6
<p>The DigiPal Framework uses cookies to give you a more personal browsing experience. Cookies are small files stored on your computer that remember some of your preferences and actions on the site. DigiPal Framework cookies are not used to identify you personally. </p>\n<p><strong>By accessing and using this site you consent to the use of cookies on your device as described below unless you have disabled them. You can change your cookie settings at any time but parts of our site will not function correctly without them</strong>.</p>\n<p><a href="http://www.aboutcookies.org/">General introduction to cookies and how to manage them</a> (third party website).</p>\n<h2>Cookies set by the DigiPal Framework</h2>\n<p>There are three main types of cookies:</p>\n<ul>\n<li><strong>strictly necessary</strong> cookie: without it your device may fail to display essential parts of the site</li>\n<li><strong>functionality cookie</strong>: enhances the functionality of website by storing your preferences or actions</li>\n<li><strong>performance cookie</strong>: helps to improve the performance of the website, providing a better user experience</li>\n</ul>\n<p>Cookies are also categorised according to their provenance. A cookie is either set directly by the Models of Authority site or through services or resources hosted on another web site. The later is called a '<strong>third party</strong> cookie'.</p>\n<h3>Security Cookie</h3>\n<p>We implement a well established measure of prevention against malicious browser requests trying to impersonate your actions (also called <a href="http://en.wikipedia.org/wiki/Cross-site_request_forgery">Cross Site Request Forgery</a>).</p>\n<ul>\n<li>Cookie names: csrftoken</li>\n<li>Type: strictly necessary cookie</li>\n</ul>\n<h3>Collections</h3>\n<p>You can collect and organise the images you find across the website into personal collections. The collections you have created are stored as cookies in your browser so you can continue using them the next time you visit the site.</p>\n<ul>\n<li>Cookie names: collection, selectedCollection</li>\n<li>Type: functionality cookie</li>\n</ul>\n<h3>Manuscript viewer settings</h3>\n<p>The manuscript viewer has a lot of customisable parameters to control how the annotations are displayed over the manuscript. These settings are saved in your browser local storage as cookies.</p>\n<ul>\n<li>Cookie names: digipal_settings</li>\n<li>Type: functionality cookie</li>\n</ul>\n<h3>Google Analytics (third-party cookies)</h3>\n<p>The DigiPal Framework can be set up with Google Analytics software to learn how users navigate through the website. This may be doneto help make sure the site is meeting the needs of its users and to help make improvements. <strong>The DigiPal framework does not use Google Analytics unless the person who set up this Framework has explicitly chosen to add them</strong>.</p>\n<p>Google Analytics stores information about:</p>\n<ul>\n<li>the pages you visit on Models of Authority - how long you spend on each page</li>\n<li>how you got to the site</li>\n<li>what you click on while you’re visiting the site</li>\n</ul>\n<p>This doesn't collect or store your personal information (e.g. your name or address), so the information stored by Google Analytics can’t be used to identify who you are.</p>\n<p>If you wish to opt out of this then see 'Changing your Cookie Settings' below.</p>\n<ul>\n<li>Cookie names: <em>utma, _utmb, _utmc, _utmz, ga</em>nextpage_params</li>\n<li>Type: performance cookie</li>\n</ul>\n<h3>Sharing Collections and Annotations (third-party cookies)</h3>\n<p>When you decide to share your collections and image annotations with other users we use Google URL Shortener service to generate a short URL that is easy for you to copy, paste and send to other people. This Google service sets a few cookies as well.</p>\n<ul>\n<li>Cookie names: GAPS, NID</li>\n<li>Type: functionality cookie</li>\n</ul>\n<h3>Disqus (third-party cookies)</h3>\n<p>The DigiPal Framework is set up to use a third party component to allow the web users to write comments under the Blog and News articles. This component sets its own cookies to identify your browser and interaction history and the connection between the DigiPal Framework and their service. More information is available on the <a href="https://help.disqus.com/customer/portal/articles/466259-privacy-policy">Disqus Privacy Policy page</a>.</p>\n<ul>\n<li>Cookie names: <em>_utma, _</em>utmb, <em>_utmc, _</em>utmv, <em>_utmz, _</em>qca, disqus<em>unique, _</em>id</li>\n<li>Type: functionality cookie</li>\n</ul>\n<h3>Other third-party cookies</h3>\n<p>Some Blog and News articles may contain pictures, videos, and media players which are hosted on other web servers (e.g. YouTube). These servers can set their own cookies on your device. The DigiPal Framework does not control the dissemination of these cookies and you should check the relevant third-party websites for more information.</p>\n<h2>Changing your cookie settings</h2>\n<p>There are different ways to enable or disable cookies from being set. All mainstream Internet browsers (e.g. Internet Explorer, Chrome, FireFox, Safari) offer a settings screen to delete cookies or change which types of cookies can be stored on your device.</p>\n<p><a href="http://tools.google.com/dlpage/gaoptout">Google also lets you opt-out from its Google Analytics data collection</a>.</p>\n<p>For more detailed information and instructions we invite you to visit the <a href="http://www.aboutcookies.org/default.aspx">aboutcookies.org site</a>.</p>	7
<p>This website is based on the DigiPal Framework. This is generic, open-source software for the analysis and presentation of palaeographical and related materials and texts. It was first developed as part of the Digital Resource and Database for Palaeography, Manuscript Studies and Diplomatic (DigiPal), a project funded by the European Research Council to bring digital technology to bear on scholarly discussion of medieval handwriting. A large part of this work has been the development of a freely-available generalised framework for the online presentation of images with structured annotations and data which allows scholars to search for, view, and organise detailed characteristics of handwriting or other material in both verbal and visual form. It was then extended as part of subsequent projects, particularly Models of Authority and the Conqueror's Commissioners, both of which were funded by the Arts and Humanities Research Council (AHRC, UK). To date it is being used for the following material:</p>\n<ul>\n<li><a href="http://digipal.eu/">Writing in Old English from the eleventh century (DigiPal)</a></li>\n<li>Fragments of manuscripts from Scandinavia written in the eleventh century (ScandiPal)</li>\n<li>The decoration and script of fifteenth-century manuscripts in Hebrew from the Iberian Peninsula (SephardiPal)</li>\n<li>Inscriptions in Greek, Latin and both from the province of Thracia (InsPal)</li>\n<li>Inscriptions on medieval coins in the Bibliothèque Nationale de France (PIM)</li>\n<li><a href="http://www.exondomesday.ac.uk/">The palaeography and codicology of the Exon Domesday Book (Exon Domesday/The Conqueror's Commissioners)</a></li>\n<li><a href="https://www.modelsofauthority.ac.uk/">Twelfth-century cursive charters from Scotland (Models of Authority)</a></li>\n<li>'Proof-of-concept' experiments have also been done using the framework on Chinese, Mayan hieroglyphs, modern (20th-century) draft manuscripts, Cuneiform, early West Semitic scripts, and an analysis of halos in Renaissance painting.</li>\n</ul>\n<p>The DigiPal Project formally ended on 30 September 2014, but the framework is still being updated and extended as part of the follow-on projects listed above.</p>\n<p>For further information, including the full source code and documentation, see the <a href="https://github.com/kcl-ddh/digipal/">DigiPal project on GitHub</a>.</p>	8
<p>FOOOTER The DigiPal Framework is developed by the <a href="http://www.kcl.ac.uk/ddh">Department of Digital Humanities</a> at <a href="http://www.kcl.ac.uk/">King's College London</a>. It has received funding from the European Union Seventh Framework Programme (FP7) under <a href="http://cordis.europa.eu/projects/rcn/96097_en.html">Grant Agreement no. 263751</a> (<a href="http://www.digipal.eu/">DigiPal</a>), and the Arts and Humanities Research Council (AHRC) under <a href="http://gtr.rcuk.ac.uk/project/C7110EC4-6F46-43B3-AC95-067B5F9634C5">Grant Reference n° AH/L008041/1</a> (<a href="http://www.modelsofauthority.ac.uk/">Models of Authority</a>) and <a href="http://gtr.rcuk.ac.uk/project/6E1A6C8B-E9BE-4AC7-A524-2414DA697F49">AH/L013975/1</a> (<a href="http://www.exondomesday.ac.uk/">Exon Domesday</a>). For further information including the software source see <a href="https://github.com/kcl-ddh/digipal/wiki">https://github.com/kcl-ddh/digipal/wiki</a>.</p>\n<p>This site uses Cookies. For further details see our <a href="/about/privacy-and-cookie-policy/">Privacy and Cookie Policy</a>.</p>	4
\.


--
-- Data for Name: reversion_revision; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY reversion_revision (id, date_created, user_id, comment, manager_slug) FROM stdin;
1	2017-04-21 18:19:59.594425+00	1	Initial version.	default
2	2017-04-21 18:20:08.581067+00	1	Changed keywords. Changed locus, iipimage, custom_label and media_permission for image "BL IP1: 121v".	default
3	2017-04-21 18:20:56.68451+00	1	Initial version.	default
4	2017-04-21 18:21:04.447955+00	1	Initial version.	default
5	2017-04-21 21:01:51.560122+00	1	Initial version.	default
6	2017-04-21 21:02:13.288937+00	1	Initial version.	default
7	2017-04-22 17:02:44.92521+00	1	Initial version.	default
8	2017-04-22 17:02:47.205361+00	1	Initial version.	default
9	2017-04-22 17:03:21.60505+00	1	Initial version.	default
10	2017-04-22 17:05:15.807455+00	1	Initial version.	default
11	2017-04-22 17:05:45.850221+00	1	Initial version.	default
12	2017-04-22 17:06:04.870092+00	1	Changed name and date.	default
13	2017-04-22 17:07:36.570143+00	1	Changed description for description "document Winchcombe Psalter CU Digital Library".	default
14	2017-04-22 17:09:17.426392+00	1	Initial version.	default
15	2017-04-22 17:09:24.062711+00	1	Initial version.	default
16	2017-04-22 17:09:27.040254+00	1	Changed historical_item_type and historical_item_format.	default
17	2017-04-22 17:10:21.787705+00	1	Initial version.	default
18	2017-04-22 17:12:34.113254+00	1	Changed keywords. Added hand "Main Hand". Added image "CUL Ff.1.23: 8v".	default
19	2017-04-22 17:13:39.494588+00	1	Changed copyright_notice.	default
20	2017-04-22 17:17:19.246981+00	1	Changed keywords. Changed images for hand "Main Hand".	default
21	2017-04-22 17:23:47.500146+00	1	Initial version.	default
22	2017-04-22 17:23:59.991891+00	1	Added catalogue number "Gneuss 4".	default
23	2017-08-29 20:01:39.939995+00	1	Changed image_file.	default
\.


--
-- Name: reversion_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('reversion_revision_id_seq', 23, true);


--
-- Data for Name: reversion_version; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY reversion_version (id, revision_id, object_id, content_type_id, format, serialized_data, object_repr, object_id_int) FROM stdin;
1	1	1	31	json	[{"pk": 1, "model": "digipal.mediapermission", "fields": {"display_message": "", "permission": 100, "label": "Private"}}]	Private [Private]	1
2	2	1	78	json	[{"pk": 1, "model": "digipal.itempart", "fields": {"pagination": false, "group": null, "created": "2015-03-13T18:43:34.367Z", "notes": "", "modified": "2017-04-21T18:20:04.095Z", "locus": "", "current_item": 1, "display_label": "BL IP1", "owners": [], "keywords_string": "", "type": null, "group_locus": ""}}]	BL IP1	1
3	3	1	101	json	[{"pk": 1, "model": "digipal_text.textcontenttype", "fields": {"created": "2017-04-21T18:20:56.680Z", "name": "Transcription", "modified": "2017-04-21T18:20:56.680Z", "slug": "transcription"}}]	Transcription	1
4	4	2	101	json	[{"pk": 2, "model": "digipal_text.textcontenttype", "fields": {"created": "2017-04-21T18:21:04.444Z", "name": "Translation", "modified": "2017-04-21T18:21:04.444Z", "slug": "translation"}}]	Translation	2
5	5	1	97	json	[{"pk": 1, "model": "digipal.carouselitem", "fields": {"image_alt": "", "title": "Annotate scripts according to your alphabet", "image": "", "created": "2017-04-21T21:01:51.553Z", "modified": "2017-04-21T21:01:51.553Z", "sort_order": 1, "link": "", "image_file": "uploads/images/MultiPal_Screenshot.jpg", "image_title": ""}}]	Annotate scripts according to your alphabet	1
6	6	2	97	json	[{"pk": 2, "model": "digipal.carouselitem", "fields": {"image_alt": "", "title": "Manipulate images in the Lightbox", "image": "", "created": "2017-04-21T21:02:13.277Z", "modified": "2017-04-21T21:02:13.277Z", "sort_order": 2, "link": "", "image_file": "uploads/images/3._Lightbox_Screenshot-_Eadwig.tiff", "image_title": ""}}]	Manipulate images in the Lightbox	2
7	7	2	31	json	[{"pk": 2, "model": "digipal.mediapermission", "fields": {"display_message": "<p>This image is licensed under a Creative Commons Attribution-NonCommercial 3.0 Unported License (CC BY-NC 3.0)</p>", "permission": 300, "label": "CC BY-NC 3.0"}}]	CC BY-NC 3.0 [Full Resolution]	2
8	8	2	68	json	[{"pk": 2, "model": "digipal.repository", "fields": {"part_of": null, "name": "Cambridge University Library", "short_name": "CUL", "created": "2017-04-22T17:02:47.178Z", "url": "", "digital_project": null, "modified": "2017-04-22T17:02:47.178Z", "place": 179, "legacy_id": null, "british_isles": null, "comma": null, "media_permission": 2, "type": null, "copyright_notice": "<p>Copyright (C) Cambridge University Library. Images made available for download are licensed under a Creative Commons Attribution-NonCommercial 3.0 Unported License (CC BY-NC 3.0).</p>"}}]	CUL	2
9	9	2	69	json	[{"pk": 2, "model": "digipal.currentitem", "fields": {"owners": [], "legacy_id": null, "repository": 2, "created": "2017-04-22T17:03:21.551Z", "modified": "2017-04-22T17:03:21.551Z", "display_label": "CUL Ff.1.23", "shelfmark": "Ff.1.23", "description": ""}}]	CUL Ff.1.23	2
10	9	2	78	json	[{"pk": 2, "model": "digipal.itempart", "fields": {"pagination": false, "group": null, "created": "2017-04-22T17:03:21.563Z", "notes": "", "modified": "2017-04-22T17:03:21.563Z", "locus": "", "current_item": 2, "display_label": "CUL Ff.1.23", "owners": [], "keywords_string": "", "type": null, "group_locus": ""}}]	CUL Ff.1.23	2
11	10	1	55	json	[{"pk": 1, "model": "digipal.source", "fields": {"name": "Cambridge University Digital Library", "created": "2017-04-22T17:05:15.800Z", "modified": "2017-04-22T17:05:15.800Z", "label_slug": "cu-digital-library", "label": "CU Digital Library", "priority": 0, "label_styled": ""}}]	CU Digital Library	1
12	11	1	79	json	[{"pk": 1, "model": "digipal.itempartitem", "fields": {"historical_item": 2, "created": "2017-04-22T17:05:45.762Z", "modified": "2017-04-22T17:05:45.762Z", "item_part": 2, "locus": ""}}]	,  (Ff.1.23)	1
13	11	2	54	json	[{"pk": 2, "model": "digipal.historicalitem", "fields": {"owners": [], "legacy_id": null, "language": null, "created": "2017-04-22T17:05:45.739Z", "url": "", "modified": "2017-04-22T17:05:45.739Z", "historical_item_format": null, "hair": null, "vernacular": null, "display_label": "document", "date_sort": null, "date": "", "historical_item_type": 1, "legacy_reference": "", "neumed": null, "catalogue_number": "", "categories": [], "name": ""}}]	document	2
14	11	1	59	json	[{"pk": 1, "model": "digipal.description", "fields": {"historical_item": 2, "description": "<p>Cambridge University Library MS Ff.1.23, known as the&nbsp;<em>Winchcombe Psalter</em>, principally comprises a copy of the Psalms in Latin and Old English, dated between 1025 and 1050. In addition, the manuscript contains two sets of prayers on folios&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">4r</a>&nbsp;and&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">276r-281v</a>); Canticles, on folios&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">251r-274r</a>, and a Litany (folios&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">274r-276r</a>). A sixteenth-century table of incipits has been added on folios&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">2v-3r</a>.&nbsp;<a href=\\"http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/\\">http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/</a></p>\\r\\n<p>&nbsp;</p>", "created": "2017-04-22T17:05:45.770Z", "text": null, "modified": "2017-04-22T17:05:45.770Z", "comments": "", "summary": "", "source": 1}}]	document CU Digital Library	1
15	12	1	79	json	[{"pk": 1, "model": "digipal.itempartitem", "fields": {"historical_item": 2, "created": "2017-04-22T17:05:45.762Z", "modified": "2017-04-22T17:05:45.762Z", "item_part": 2, "locus": ""}}]	Winchcombe Psalter,  (Ff.1.23)	1
16	12	2	54	json	[{"pk": 2, "model": "digipal.historicalitem", "fields": {"owners": [], "legacy_id": null, "language": null, "created": "2017-04-22T17:05:45.739Z", "url": "", "modified": "2017-04-22T17:06:04.827Z", "historical_item_format": null, "hair": null, "vernacular": null, "display_label": "document Winchcombe Psalter", "date_sort": null, "date": "s. xi1/4", "historical_item_type": 1, "legacy_reference": "", "neumed": null, "catalogue_number": "", "categories": [], "name": "Winchcombe Psalter"}}]	document Winchcombe Psalter	2
17	12	1	59	json	[{"pk": 1, "model": "digipal.description", "fields": {"historical_item": 2, "description": "<p>Cambridge University Library MS Ff.1.23, known as the&nbsp;<em>Winchcombe Psalter</em>, principally comprises a copy of the Psalms in Latin and Old English, dated between 1025 and 1050. In addition, the manuscript contains two sets of prayers on folios&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">4r</a>&nbsp;and&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">276r-281v</a>); Canticles, on folios&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">251r-274r</a>, and a Litany (folios&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">274r-276r</a>). A sixteenth-century table of incipits has been added on folios&nbsp;<a href=\\"/admin/digipal/historicalitem/add/\\">2v-3r</a>.&nbsp;<a href=\\"http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/\\">http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/</a></p>\\r\\n<p>&nbsp;</p>", "created": "2017-04-22T17:05:45.770Z", "text": null, "modified": "2017-04-22T17:05:45.770Z", "comments": "", "summary": "", "source": 1}}]	document Winchcombe Psalter CU Digital Library	1
18	13	1	79	json	[{"pk": 1, "model": "digipal.itempartitem", "fields": {"historical_item": 2, "created": "2017-04-22T17:05:45.762Z", "modified": "2017-04-22T17:05:45.762Z", "item_part": 2, "locus": ""}}]	Winchcombe Psalter,  (Ff.1.23)	1
19	13	2	54	json	[{"pk": 2, "model": "digipal.historicalitem", "fields": {"owners": [], "legacy_id": null, "language": null, "created": "2017-04-22T17:05:45.739Z", "url": "", "modified": "2017-04-22T17:07:36.531Z", "historical_item_format": null, "hair": null, "vernacular": null, "display_label": "document Winchcombe Psalter", "date_sort": null, "date": "s. xi1/4", "historical_item_type": 1, "legacy_reference": "", "neumed": null, "catalogue_number": "", "categories": [], "name": "Winchcombe Psalter"}}]	document Winchcombe Psalter	2
20	13	1	59	json	[{"pk": 1, "model": "digipal.description", "fields": {"historical_item": 2, "description": "<p>Cambridge University Library MS Ff.1.23, known as the&nbsp;<em>Winchcombe Psalter</em>, principally comprises a copy of the Psalms in Latin and Old English, dated between 1025 and 1050. In addition, the manuscript contains two sets of prayers on folios&nbsp;4r&nbsp;and&nbsp;276r-281v); Canticles, on folios&nbsp;251r-274r, and a Litany (folios&nbsp;274r-276r). A sixteenth-century table of incipits has been added on folios&nbsp;2v-3r. [For the full description see&nbsp;<a href=\\"http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/\\">http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/</a>]</p>\\r\\n<p>&nbsp;</p>", "created": "2017-04-22T17:05:45.770Z", "text": null, "modified": "2017-04-22T17:07:36.542Z", "comments": "", "summary": "", "source": 1}}]	document Winchcombe Psalter CU Digital Library	1
21	14	2	52	json	[{"pk": 2, "model": "digipal.historicalitemtype", "fields": {"name": "manuscript", "modified": "2017-04-22T17:09:17.420Z", "created": "2017-04-22T17:09:17.420Z"}}]	manuscript	2
22	15	1	50	json	[{"pk": 1, "model": "digipal.format", "fields": {"modified": "2017-04-22T17:09:24.055Z", "name": "codex", "legacy_id": null, "created": "2017-04-22T17:09:24.055Z"}}]	codex	1
23	16	1	79	json	[{"pk": 1, "model": "digipal.itempartitem", "fields": {"historical_item": 2, "created": "2017-04-22T17:05:45.762Z", "modified": "2017-04-22T17:05:45.762Z", "item_part": 2, "locus": ""}}]	Winchcombe Psalter,  (Ff.1.23)	1
24	16	2	54	json	[{"pk": 2, "model": "digipal.historicalitem", "fields": {"owners": [], "legacy_id": null, "language": null, "created": "2017-04-22T17:05:45.739Z", "url": "", "modified": "2017-04-22T17:09:26.982Z", "historical_item_format": 1, "hair": null, "vernacular": null, "display_label": "manuscript Winchcombe Psalter", "date_sort": null, "date": "s. xi1/4", "historical_item_type": 2, "legacy_reference": "", "neumed": null, "catalogue_number": "", "categories": [], "name": "Winchcombe Psalter"}}]	manuscript Winchcombe Psalter	2
25	16	1	59	json	[{"pk": 1, "model": "digipal.description", "fields": {"historical_item": 2, "description": "<p>Cambridge University Library MS Ff.1.23, known as the&nbsp;<em>Winchcombe Psalter</em>, principally comprises a copy of the Psalms in Latin and Old English, dated between 1025 and 1050. In addition, the manuscript contains two sets of prayers on folios&nbsp;4r&nbsp;and&nbsp;276r-281v); Canticles, on folios&nbsp;251r-274r, and a Litany (folios&nbsp;274r-276r). A sixteenth-century table of incipits has been added on folios&nbsp;2v-3r. [For the full description see&nbsp;<a href=\\"http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/\\">http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/</a>]</p>\\r\\n<p>&nbsp;</p>", "created": "2017-04-22T17:05:45.770Z", "text": null, "modified": "2017-04-22T17:07:36.542Z", "comments": "", "summary": "", "source": 1}}]	manuscript Winchcombe Psalter CU Digital Library	1
26	17	1	48	json	[{"pk": 1, "model": "digipal.date", "fields": {"additional_band": null, "min_weight": 1000.0, "weight": 1012.5, "created": "2017-04-22T17:10:21.767Z", "modified": "2017-04-22T17:10:21.767Z", "evidence": "", "s_xi": null, "band": null, "sort_order": null, "legacy_id": null, "date": "saec. xi1/4", "post_conquest": null, "legacy_reference": "", "max_weight": 1025.0}}]	saec. xi1/4	1
27	18	2	78	json	[{"pk": 2, "model": "digipal.itempart", "fields": {"pagination": false, "group": null, "created": "2017-04-22T17:03:21.563Z", "notes": "", "modified": "2017-04-22T17:12:32.697Z", "locus": "", "current_item": 2, "display_label": "CUL Ff.1.23", "owners": [], "keywords_string": "", "type": null, "group_locus": ""}}]	CUL Ff.1.23	2
28	19	2	68	json	[{"pk": 2, "model": "digipal.repository", "fields": {"part_of": null, "name": "Cambridge University Library", "short_name": "CUL", "created": "2017-04-22T17:02:47.178Z", "url": "", "digital_project": null, "modified": "2017-04-22T17:13:39.490Z", "place": 179, "legacy_id": null, "british_isles": null, "comma": null, "media_permission": 2, "type": null, "copyright_notice": "<p>Copyright (C) Cambridge University Library. Licensed under Creative Commons Attribution-NonCommercial 3.0 Unported License (CC BY-NC 3.0).</p>"}}]	CUL	2
29	20	2	78	json	[{"pk": 2, "model": "digipal.itempart", "fields": {"pagination": false, "group": null, "created": "2017-04-22T17:03:21.563Z", "notes": "", "modified": "2017-04-22T17:17:19.205Z", "locus": "", "current_item": 2, "display_label": "CUL Ff.1.23", "owners": [], "keywords_string": "", "type": null, "group_locus": ""}}]	CUL Ff.1.23	2
30	21	2	55	json	[{"pk": 2, "model": "digipal.source", "fields": {"name": "Gneuss, Handlist of Anglo-Saxon Manuscripts", "created": "2017-04-22T17:23:47.494Z", "modified": "2017-04-22T17:23:47.494Z", "label_slug": "gneuss", "label": "Gneuss", "priority": 0, "label_styled": "Gneuss, _Handlist_"}}]	Gneuss	2
31	22	1	79	json	[{"pk": 1, "model": "digipal.itempartitem", "fields": {"historical_item": 2, "created": "2017-04-22T17:05:45.762Z", "modified": "2017-04-22T17:05:45.762Z", "item_part": 2, "locus": ""}}]	Winchcombe Psalter,  (Ff.1.23)	1
32	22	2	54	json	[{"pk": 2, "model": "digipal.historicalitem", "fields": {"owners": [], "legacy_id": null, "language": null, "created": "2017-04-22T17:05:45.739Z", "url": "", "modified": "2017-04-22T17:23:59.955Z", "historical_item_format": 1, "hair": null, "vernacular": null, "display_label": "manuscript Gneuss 4 Winchcombe Psalter", "date_sort": null, "date": "s. xi1/4", "historical_item_type": 2, "legacy_reference": "", "neumed": null, "catalogue_number": "Gneuss 4", "categories": [], "name": "Winchcombe Psalter"}}]	manuscript Gneuss 4 Winchcombe Psalter	2
33	22	1	56	json	[{"pk": 1, "model": "digipal.cataloguenumber", "fields": {"historical_item": 2, "created": "2017-04-22T17:23:59.940Z", "url": "", "text": null, "number": "4", "modified": "2017-04-22T17:23:59.940Z", "source": 2, "number_slug": "4"}}]	Gneuss 4	1
34	22	1	59	json	[{"pk": 1, "model": "digipal.description", "fields": {"historical_item": 2, "description": "<p>Cambridge University Library MS Ff.1.23, known as the&nbsp;<em>Winchcombe Psalter</em>, principally comprises a copy of the Psalms in Latin and Old English, dated between 1025 and 1050. In addition, the manuscript contains two sets of prayers on folios&nbsp;4r&nbsp;and&nbsp;276r-281v); Canticles, on folios&nbsp;251r-274r, and a Litany (folios&nbsp;274r-276r). A sixteenth-century table of incipits has been added on folios&nbsp;2v-3r. [For the full description see&nbsp;<a href=\\"http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/\\">http://cudl.lib.cam.ac.uk/view/MS-FF-00001-00023/</a>]</p>\\r\\n<p>&nbsp;</p>", "created": "2017-04-22T17:05:45.770Z", "text": null, "modified": "2017-04-22T17:07:36.542Z", "comments": "", "summary": "", "source": 1}}]	manuscript Gneuss 4 Winchcombe Psalter CU Digital Library	1
35	23	2	97	json	[{"pk": 2, "model": "digipal.carouselitem", "fields": {"image_alt": "", "title": "Manipulate images in the Lightbox", "image": "", "created": "2017-04-21T21:02:13.277Z", "modified": "2017-08-29T20:01:39.932Z", "sort_order": 2, "link": "", "image_file": "uploads/images/3._Lightbox_Screenshot-_Eadwig.png", "image_title": ""}}]	Manipulate images in the Lightbox	2
\.


--
-- Name: reversion_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('reversion_version_id_seq', 35, true);


--
-- Data for Name: south_migrationhistory; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY south_migrationhistory (id, app_name, migration, applied) FROM stdin;
1	conf	0001_initial	2016-09-27 22:10:49.772205+00
2	conf	0002_auto__add_field_setting_site	2016-09-27 22:10:49.801388+00
3	conf	0003_update_site_setting	2016-09-27 22:10:49.810337+00
4	conf	0004_ssl_account_settings_rename	2016-09-27 22:10:49.815748+00
5	core	0001_initial	2016-09-27 22:10:50.065413+00
6	pages	0001_initial	2016-09-27 22:10:50.141827+00
7	pages	0002_auto__del_field_page__keywords__add_field_page_keywords_string__chg_fi	2016-09-27 22:10:50.19233+00
8	blog	0001_initial	2016-09-27 22:10:50.311453+00
9	blog	0002_auto	2016-09-27 22:10:50.364013+00
10	blog	0003_categories	2016-09-27 22:10:50.404438+00
11	blog	0004_auto__del_field_blogpost_category	2016-09-27 22:10:50.419694+00
12	blog	0005_auto__del_comment__add_field_blogpost_comments_count__chg_field_blogpo	2016-09-27 22:10:50.464493+00
13	blog	0006_auto__del_field_blogpost__keywords__add_field_blogpost_keywords_string	2016-09-27 22:10:50.50631+00
14	core	0002_auto__del_keyword	2016-09-27 22:10:50.514938+00
15	core	0003_auto__add_sitepermission	2016-09-27 22:10:50.563949+00
16	core	0004_set_site_permissions	2016-09-27 22:10:50.597749+00
17	core	0005_auto__chg_field_sitepermission_user__del_unique_sitepermission_user	2016-09-27 22:10:50.626285+00
18	generic	0001_initial	2016-09-27 22:10:51.003445+00
19	generic	0002_auto__add_keyword__add_assignedkeyword	2016-09-27 22:10:51.060748+00
20	generic	0003_auto__add_rating	2016-09-27 22:10:51.122825+00
21	generic	0004_auto__chg_field_rating_object_pk__chg_field_assignedkeyword_object_pk	2016-09-27 22:10:51.164066+00
22	generic	0005_keyword_site	2016-09-27 22:10:51.1898+00
23	generic	0006_move_keywords	2016-09-27 22:10:51.216945+00
24	generic	0007_auto__add_field_assignedkeyword__order	2016-09-27 22:10:51.241091+00
25	generic	0008_set_keyword_order	2016-09-27 22:10:51.258972+00
26	generic	0009_auto__chg_field_keyword_title__chg_field_keyword_slug	2016-09-27 22:10:51.308839+00
27	generic	0009_auto__del_field_threadedcomment_email_hash	2016-09-27 22:10:51.349649+00
28	generic	0010_auto__chg_field_keyword_slug__chg_field_keyword_title	2016-09-27 22:10:51.397915+00
29	generic	0011_auto__add_field_threadedcomment_rating_count__add_field_threadedcommen	2016-09-27 22:10:51.447736+00
30	generic	0012_auto__add_field_rating_rating_date	2016-09-27 22:10:51.466056+00
31	generic	0013_auto__add_field_threadedcomment_rating_sum	2016-09-27 22:10:51.495287+00
32	generic	0014_auto__add_field_rating_user	2016-09-27 22:10:51.52145+00
33	blog	0007_auto__add_field_blogpost_site	2016-09-27 22:10:51.859661+00
34	blog	0008_auto__add_field_blogpost_rating_average__add_field_blogpost_rating_cou	2016-09-27 22:10:51.941047+00
35	blog	0009_auto__chg_field_blogpost_content	2016-09-27 22:10:51.993925+00
36	blog	0010_category_site_allow_comments	2016-09-27 22:10:52.068233+00
37	blog	0011_comment_site_data	2016-09-27 22:10:52.104069+00
38	blog	0012_auto__add_field_blogpost_featured_image	2016-09-27 22:10:52.124757+00
39	blog	0013_auto__chg_field_blogpost_featured_image	2016-09-27 22:10:52.155743+00
40	blog	0014_auto__add_field_blogpost_gen_description	2016-09-27 22:10:52.205065+00
41	blog	0015_auto__chg_field_blogcategory_title__chg_field_blogcategory_slug__chg_f	2016-09-27 22:10:52.394613+00
42	blog	0016_add_field_blogpost__meta_title	2016-09-27 22:10:52.413625+00
43	blog	0017_add_field_blogpost__related_posts	2016-09-27 22:10:52.463889+00
44	blog	0018_auto__add_field_blogpost_in_sitemap	2016-09-27 22:10:52.53791+00
45	blog	0019_auto__add_field_blogpost_rating_sum	2016-09-27 22:10:52.60348+00
46	blog	0020_auto__add_field_blogpost_created__add_field_blogpost_updated	2016-09-27 22:10:52.647141+00
47	forms	0001_initial	2016-09-27 22:10:53.028441+00
48	forms	0002_auto__add_field_field_placeholder_text	2016-09-27 22:10:53.060057+00
49	forms	0003_auto__chg_field_field_field_type	2016-09-27 22:10:53.091906+00
50	forms	0004_auto__chg_field_form_response__chg_field_form_content	2016-09-27 22:10:53.128179+00
51	forms	0005_auto__chg_field_fieldentry_value	2016-09-27 22:10:53.151442+00
52	pages	0003_auto__add_field_page_site	2016-09-27 22:10:53.401966+00
53	pages	0004_auto__del_contentpage__add_richtextpage	2016-09-27 22:10:53.41556+00
54	pages	0005_rename_contentpage	2016-09-27 22:10:53.426195+00
55	pages	0006_auto__add_field_page_gen_description	2016-09-27 22:10:53.461051+00
56	pages	0007_auto__chg_field_page_slug__chg_field_page_title	2016-09-27 22:10:53.50579+00
57	pages	0008_auto__add_link	2016-09-27 22:10:53.524004+00
58	pages	0009_add_field_page_in_menus	2016-09-27 22:10:53.555764+00
59	pages	0010_set_menus	2016-09-27 22:10:53.59416+00
60	pages	0011_delete_nav_flags	2016-09-27 22:10:53.606874+00
61	pages	0012_add_field_page__meta_title	2016-09-27 22:10:53.618557+00
62	pages	0013_auto__add_field_page_in_sitemap	2016-09-27 22:10:53.662652+00
63	pages	0014_auto__add_field_page_created__add_field_page_updated	2016-09-27 22:10:53.687324+00
64	galleries	0001_initial	2016-09-27 22:10:54.066912+00
65	twitter	0001_initial	2016-09-27 22:10:54.47399+00
66	twitter	0002_auto__chg_field_query_value	2016-09-27 22:10:54.525136+00
67	digipal	0001_initial	2016-09-27 22:10:57.141005+00
68	digipal	0002_auto__add_field_repository_copyright_notice	2016-09-27 22:10:57.278876+00
69	digipal	0003_auto__add_field_page_side__add_field_page_folio_number__add_field_page	2016-09-27 22:10:57.425496+00
70	digipal	0004_page_number_and_side	2016-09-27 22:10:57.552234+00
71	digipal	0005_page_iipimage	2016-09-27 22:10:57.680898+00
72	digipal	0006_auto__chg_field_page_item_part	2016-09-27 22:10:57.963956+00
73	digipal	0007_auto__add_field_itempart_pagination	2016-09-27 22:10:58.139664+00
74	digipal	0008_auto__add_field_scribe_legacy_reference__add_field_date_legacy_referen	2016-09-27 22:10:58.397249+00
75	digipal	0009_auto__add_mediapermission__add_field_repository_media_permission__add_	2016-09-27 22:10:58.572812+00
76	digipal	0010_auto__chg_field_dateevidence_evidence__chg_field_scribe_legacy_referen	2016-09-27 22:10:58.816475+00
77	digipal	0011_auto__add_stewartrecord	2016-09-27 22:10:58.966618+00
78	digipal	0012_auto__del_field_stewartrecord_hand__del_field_stewartrecord_stokes__ad	2016-09-27 22:10:59.716189+00
79	digipal	0013_auto__chg_field_stewartrecord_em__chg_field_stewartrecord_contents__ch	2016-09-27 22:11:00.132511+00
80	digipal	0014_auto__add_field_stewartrecord_hand_id	2016-09-27 22:11:00.286195+00
81	digipal	0015_auto__add_field_stewartrecord_import_message	2016-09-27 22:11:00.652769+00
82	digipal	0016_auto__add_field_hand_ker	2016-09-27 22:11:00.813218+00
83	digipal	0017_hand_descriptions	2016-09-27 22:11:00.964715+00
84	digipal	0018_auto__del_field_hand_description__del_field_hand_em_description__del_f	2016-09-27 22:11:01.115314+00
85	digipal	0019_auto__add_requestlog	2016-09-27 22:11:01.273026+00
86	digipal	0020_auto__del_page__add_itempartitem__add_itemparttype__add_image__add_fie	2016-09-27 22:11:01.528995+00
87	digipal	0021_multiple_his_and_nested_parts	2016-09-27 22:11:01.722081+00
88	digipal	0022_auto__del_field_itempart_historical_item	2016-09-27 22:11:02.088854+00
89	digipal	0023_auto__add_field_layout_item_part__chg_field_layout_historical_item	2016-09-27 22:11:02.309843+00
90	digipal	0024_auto__add_placetype__add_field_place_type	2016-09-27 22:11:02.515128+00
91	digipal	0025_auto	2016-09-27 22:11:02.736466+00
92	digipal	0026_auto__del_field_owner_content_type__del_field_owner_object_id__add_fie	2016-09-27 22:11:02.97752+00
93	digipal	0027_auto__chg_field_itempart_current_item	2016-09-27 22:11:03.211897+00
94	digipal	0028_auto__add_field_graph_group	2016-09-27 22:11:03.37873+00
95	digipal	0029_auto__chg_field_character_unicode_point__del_unique_character_unicode_	2016-09-27 22:11:03.585039+00
96	digipal	0030_auto__add_textitempart__add_unique_textitempart_item_part_text__add_te	2016-09-27 22:11:03.857205+00
97	digipal	0031_auto__add_field_text_date__add_field_text_url	2016-09-27 22:11:04.155986+00
98	digipal	0032_auto__add_field_description_comments__add_field_description_summary__c	2016-09-27 22:11:04.636951+00
99	digipal	0033_auto__add_field_ontograph_sort_order	2016-09-27 22:11:04.826461+00
100	digipal	0034_auto__chg_field_image_caption	2016-09-27 22:11:05.020903+00
101	digipal	0035_auto__add_field_image_transcription__add_field_image_internal_notes	2016-09-27 22:11:05.198214+00
102	digipal	0036_auto__add_field_itempart_group_locus	2016-09-27 22:11:05.380316+00
103	digipal	0037_auto__chg_field_itempart_display_label	2016-09-27 22:11:05.580917+00
104	digipal	0038_auto__add_imageannotationstatus__add_field_image_annotation_status	2016-09-27 22:11:05.785004+00
105	digipal	0039_auto__add_field_componentfeature_set_by_default__add_field_componentfe	2016-09-27 22:11:06.041349+00
106	digipal	0040_auto__chg_field_repository_copyright_notice__chg_field_mediapermission	2016-09-27 22:11:06.351519+00
107	digipal	0041_desc_to_html	2016-09-27 22:11:06.539296+00
108	digipal	0042_auto__add_carouselitem	2016-09-27 22:11:06.736755+00
109	digipal	0043_auto__chg_field_carouselitem_image__chg_field_carouselitem_link	2016-09-27 22:11:06.983552+00
110	digipal	0044_auto__add_characterform__chg_field_character_form	2016-09-27 22:11:07.645523+00
111	digipal	0045_auto__chg_field_character_form__add_field_annotation_rotation__add_fie	2016-09-27 22:11:08.006154+00
112	digipal	0046_auto__add_field_source_priority	2016-09-27 22:11:08.263827+00
113	digipal	0047_auto__del_unique_annotation_image_vector_id	2016-09-27 22:11:08.529193+00
114	digipal	0048_auto__add_field_itemorigin_place__add_field_itemorigin_institution	2016-09-27 22:11:08.767867+00
115	digipal	0049_itemorigin_generic_to_fk	2016-09-27 22:11:09.002524+00
116	digipal	0050_auto__del_field_itemorigin_content_type__del_field_itemorigin_object_i	2016-09-27 22:11:09.236376+00
117	digipal	0051_auto__chg_field_annotation_display_note__chg_field_annotation_internal	2016-09-27 22:11:09.517851+00
118	digipal	0052_auto__add_apitransform	2016-09-27 22:11:09.792465+00
119	digipal	0053_auto__add_field_apitransform_mimetype__add_field_apitransform_sample_r	2016-09-27 22:11:10.137501+00
120	digipal	0054_auto__add_field_stewartrecord_matched_hands	2016-09-27 22:11:10.404341+00
121	digipal	0055_auto__add_ownertype__add_field_repository_type__add_field_owner_reposi	2016-09-27 22:11:10.697492+00
122	digipal	0056_auto__add_field_repository_part_of	2016-09-27 22:11:10.951761+00
123	digipal	0057_data_owner_types	2016-09-27 22:11:11.222019+00
124	digipal	0058_data_repo_owner_types	2016-09-27 22:11:11.930075+00
125	digipal	0059_auto__add_field_apitransform_webpage	2016-09-27 22:11:12.26796+00
126	digipal	0060_auto__add_field_annotation_holes	2016-09-27 22:11:12.511892+00
127	digipal	0061_auto__add_field_allograph_hidden	2016-09-27 22:11:12.879635+00
128	digipal	0062_auto__add_field_carouselitem_image_file	2016-09-27 22:11:13.192234+00
129	digipal	0063_auto__chg_field_carouselitem_image__add_field_cataloguenumber_url__chg	2016-09-27 22:11:13.50916+00
130	digipal	0064_auto__add_field_owner_display_label	2016-09-27 22:11:13.806966+00
131	digipal	0065_update_owner_display_label	2016-09-27 22:11:14.085899+00
132	digipal	0066_auto__chg_field_image_iipimage	2016-09-27 22:11:14.362127+00
133	digipal	0067_auto__add_field_image_size	2016-09-27 22:11:14.632505+00
134	digipal	0068_auto__add_field_dateevidence_firm_date__add_field_source_label_styled_	2016-09-27 22:11:14.913852+00
135	digipal	0069_auto__chg_field_source_label__chg_field_source_label_styled	2016-09-27 22:11:15.296362+00
136	digipal	0070_auto__add_field_itempart_notes	2016-09-27 22:11:15.57942+00
137	digipal	0071_auto__del_field_dateevidence_firm_date__add_field_dateevidence_histori	2016-09-27 22:11:15.940868+00
138	digipal	0072_auto__add_field_itempart_keywords_string__add_field_image_keywords_str	2016-09-27 22:11:16.249672+00
139	digipal	0073_auto__chg_field_dateevidence_evidence	2016-09-27 22:11:16.562206+00
140	digipal	0074_auto__add_field_handdescription_label	2016-09-27 22:11:16.815273+00
141	digipal	0075_auto__add_field_mediapermission_permission	2016-09-27 22:11:17.077765+00
142	digipal	0076_permission__is_private__2__perm	2016-09-27 22:11:17.860304+00
143	digipal	0077_auto__del_field_mediapermission_is_private	2016-09-27 22:11:18.13519+00
144	digipal	0078_auto__add_field_annotation_clientid	2016-09-27 22:11:18.419432+00
145	digipal	0079_auto__add_field_historicalitem_date_sort	2016-09-27 22:11:18.698478+00
146	digipal	0080_corrected_dates	2016-09-27 22:11:18.96725+00
147	digipal	0081_auto__add_field_image_quire	2016-09-27 22:11:19.238697+00
148	digipal	0082_auto__add_field_cataloguenumber_number_slug__add_field_source_label_sl	2016-09-27 22:11:19.519142+00
149	digipal	0083_add_catnum_slugs	2016-09-27 22:11:19.792353+00
150	digipal	0084_auto__add_field_image_page_boundaries	2016-09-27 22:11:20.055537+00
151	digipal	0085_auto__add_field_annotation_type	2016-09-27 22:11:20.345717+00
152	digipal	0086_unify_coordinates	2016-09-27 22:11:20.626998+00
153	digipal	0087_auto__add_itempartauthenticity__add_unique_itempartauthenticity_item_p	2016-09-27 22:11:21.004278+00
154	digipal	0088_auto__del_field_itempartauthenticity_slug__del_field_itempartauthentic	2016-09-27 22:11:21.316543+00
155	digipal	0089_auto__chg_field_annotation_cutout	2016-09-27 22:11:21.622592+00
156	digipal_text	0001_initial	2016-09-27 22:11:22.887874+00
157	digipal_text	0002_auto__chg_field_textcontenttype_name	2016-09-27 22:11:23.002988+00
158	digipal_text	0003_auto__add_field_textcontent_text	2016-09-27 22:11:23.091928+00
159	digipal_text	0004_auto__add_field_textcontentxml_content__add_field_textcontentxml_last_	2016-09-27 22:11:23.202245+00
160	digipal_text	0005_auto__add_field_textcontenttype_slug__add_field_textcontentxmlstatus_s	2016-09-27 22:11:23.370564+00
161	digipal_text	0006_auto__add_textcontentxmlcopy	2016-09-27 22:11:23.504441+00
162	digipal_text	0007_auto__add_field_textcontentxmlcopy_ahash	2016-09-27 22:11:23.605695+00
163	digipal_text	0008_auto__add_field_textcontentxmlstatus_sort_order	2016-09-27 22:11:23.741924+00
164	digipal_text	0009_initial_status	2016-09-27 22:11:23.856766+00
165	digipal_text	0010_auto__chg_field_textcontentxml_status	2016-09-27 22:11:23.975451+00
166	digipal_text	0011_auto__add_textannotation__add_unique_textannotation_annotation_element	2016-09-27 22:11:24.203677+00
167	digipal_text	0012_auto__chg_field_textcontent_type__chg_field_textcontent_item_part__add	2016-09-27 22:11:24.447094+00
168	digipal_text	0013_auto__del_unique_textcontentxmlcopy_content__add_unique_textcontentxml	2016-09-27 22:11:24.660841+00
169	digipal_text	0014_auto__chg_field_textcontentxml_text_content__add_unique_textcontentxml	2016-09-27 22:11:24.893166+00
170	digipal_text	0015_auto__add_entryhand__add_unique_entryhand_item_part_entry_number_hand_	2016-09-27 22:11:25.161103+00
171	reversion	0001_initial	2016-09-27 22:11:25.376645+00
172	reversion	0002_auto__add_field_version_type	2016-09-27 22:11:25.435913+00
173	reversion	0003_auto__add_field_version_object_id_int	2016-09-27 22:11:25.496168+00
174	reversion	0004_populate_object_id_int	2016-09-27 22:11:25.522941+00
175	reversion	0005_auto__add_field_revision_manager_slug	2016-09-27 22:11:25.577907+00
176	reversion	0006_remove_delete_revisions	2016-09-27 22:11:25.619971+00
177	reversion	0007_auto__del_field_version_type	2016-09-27 22:11:25.645166+00
178	reversion	0008_auto__add_index_revision_date_created	2016-09-27 22:11:25.674449+00
\.


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('south_migrationhistory_id_seq', 178, true);


--
-- Data for Name: twitter_query; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY twitter_query (interested, type, id, value) FROM stdin;
\.


--
-- Name: twitter_query_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('twitter_query_id_seq', 1, false);


--
-- Data for Name: twitter_tweet; Type: TABLE DATA; Schema: public; Owner: app_digipal
--

COPY twitter_tweet (retweeter_profile_image_url, text, created_at, remote_id, retweeter_user_name, profile_image_url, full_name, query_id, user_name, id, retweeter_full_name) FROM stdin;
\.


--
-- Name: twitter_tweet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_digipal
--

SELECT pg_catalog.setval('twitter_tweet_id_seq', 1, false);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: blog_blogcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogcategory
    ADD CONSTRAINT blog_blogcategory_pkey PRIMARY KEY (id);


--
-- Name: blog_blogpost_categories_blogpost_id_79f2a5569187bd14_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost_categories_blogpost_id_79f2a5569187bd14_uniq UNIQUE (blogpost_id, blogcategory_id);


--
-- Name: blog_blogpost_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_blogpost_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost
    ADD CONSTRAINT blog_blogpost_pkey PRIMARY KEY (id);


--
-- Name: blog_blogpost_related_po_from_blogpost_id_3007eb9b6b16df8b_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_related_po_from_blogpost_id_3007eb9b6b16df8b_uniq UNIQUE (from_blogpost_id, to_blogpost_id);


--
-- Name: blog_blogpost_related_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_related_posts_pkey PRIMARY KEY (id);


--
-- Name: conf_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY conf_setting
    ADD CONSTRAINT conf_setting_pkey PRIMARY KEY (id);


--
-- Name: core_sitepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY core_sitepermission
    ADD CONSTRAINT core_sitepermission_pkey PRIMARY KEY (id);


--
-- Name: core_sitepermission_sit_sitepermission_id_31fc3b7b7e3badd5_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY core_sitepermission_sites
    ADD CONSTRAINT core_sitepermission_sit_sitepermission_id_31fc3b7b7e3badd5_uniq UNIQUE (sitepermission_id, site_id);


--
-- Name: core_sitepermission_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY core_sitepermission_sites
    ADD CONSTRAINT core_sitepermission_sites_pkey PRIMARY KEY (id);


--
-- Name: core_sitepermission_user_id_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY core_sitepermission
    ADD CONSTRAINT core_sitepermission_user_id_key UNIQUE (user_id);


--
-- Name: digipal_allograph_aspects_allograph_id_4b3207b4c61b3b49_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allograph_aspects
    ADD CONSTRAINT digipal_allograph_aspects_allograph_id_4b3207b4c61b3b49_uniq UNIQUE (allograph_id, aspect_id);


--
-- Name: digipal_allograph_aspects_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allograph_aspects
    ADD CONSTRAINT digipal_allograph_aspects_pkey PRIMARY KEY (id);


--
-- Name: digipal_allograph_name_60798fd305198374_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allograph
    ADD CONSTRAINT digipal_allograph_name_60798fd305198374_uniq UNIQUE (name, character_id);


--
-- Name: digipal_allograph_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allograph
    ADD CONSTRAINT digipal_allograph_pkey PRIMARY KEY (id);


--
-- Name: digipal_allographco_allographcomponent_id_2fdd3c9bae0cc1f1_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allographcomponent_features
    ADD CONSTRAINT digipal_allographco_allographcomponent_id_2fdd3c9bae0cc1f1_uniq UNIQUE (allographcomponent_id, feature_id);


--
-- Name: digipal_allographcomponent_features_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allographcomponent_features
    ADD CONSTRAINT digipal_allographcomponent_features_pkey PRIMARY KEY (id);


--
-- Name: digipal_allographcomponent_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allographcomponent
    ADD CONSTRAINT digipal_allographcomponent_pkey PRIMARY KEY (id);


--
-- Name: digipal_alphabet_hands_alphabet_id_662a1e1db928a377_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_hands
    ADD CONSTRAINT digipal_alphabet_hands_alphabet_id_662a1e1db928a377_uniq UNIQUE (alphabet_id, hand_id);


--
-- Name: digipal_alphabet_hands_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_hands
    ADD CONSTRAINT digipal_alphabet_hands_pkey PRIMARY KEY (id);


--
-- Name: digipal_alphabet_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet
    ADD CONSTRAINT digipal_alphabet_name_key UNIQUE (name);


--
-- Name: digipal_alphabet_ontographs_alphabet_id_554c9d224844bb33_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_ontographs
    ADD CONSTRAINT digipal_alphabet_ontographs_alphabet_id_554c9d224844bb33_uniq UNIQUE (alphabet_id, ontograph_id);


--
-- Name: digipal_alphabet_ontographs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_ontographs
    ADD CONSTRAINT digipal_alphabet_ontographs_pkey PRIMARY KEY (id);


--
-- Name: digipal_alphabet_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet
    ADD CONSTRAINT digipal_alphabet_pkey PRIMARY KEY (id);


--
-- Name: digipal_annotation_graph_id_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_annotation
    ADD CONSTRAINT digipal_annotation_graph_id_key UNIQUE (graph_id);


--
-- Name: digipal_annotation_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_annotation
    ADD CONSTRAINT digipal_annotation_pkey PRIMARY KEY (id);


--
-- Name: digipal_apitransform_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_apitransform
    ADD CONSTRAINT digipal_apitransform_pkey PRIMARY KEY (id);


--
-- Name: digipal_apitransform_slug_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_apitransform
    ADD CONSTRAINT digipal_apitransform_slug_key UNIQUE (slug);


--
-- Name: digipal_apitransform_title_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_apitransform
    ADD CONSTRAINT digipal_apitransform_title_key UNIQUE (title);


--
-- Name: digipal_appearance_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_appearance
    ADD CONSTRAINT digipal_appearance_pkey PRIMARY KEY (id);


--
-- Name: digipal_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_archive
    ADD CONSTRAINT digipal_archive_pkey PRIMARY KEY (id);


--
-- Name: digipal_aspect_features_aspect_id_45c6cbad27f58ba7_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_aspect_features
    ADD CONSTRAINT digipal_aspect_features_aspect_id_45c6cbad27f58ba7_uniq UNIQUE (aspect_id, feature_id);


--
-- Name: digipal_aspect_features_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_aspect_features
    ADD CONSTRAINT digipal_aspect_features_pkey PRIMARY KEY (id);


--
-- Name: digipal_aspect_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_aspect
    ADD CONSTRAINT digipal_aspect_name_key UNIQUE (name);


--
-- Name: digipal_aspect_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_aspect
    ADD CONSTRAINT digipal_aspect_pkey PRIMARY KEY (id);


--
-- Name: digipal_authenticitycategory_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_authenticitycategory
    ADD CONSTRAINT digipal_authenticitycategory_name_key UNIQUE (name);


--
-- Name: digipal_authenticitycategory_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_authenticitycategory
    ADD CONSTRAINT digipal_authenticitycategory_pkey PRIMARY KEY (id);


--
-- Name: digipal_carouselitem_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_carouselitem
    ADD CONSTRAINT digipal_carouselitem_pkey PRIMARY KEY (id);


--
-- Name: digipal_cataloguenumber_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_cataloguenumber
    ADD CONSTRAINT digipal_cataloguenumber_pkey PRIMARY KEY (id);


--
-- Name: digipal_cataloguenumber_source_id_5930e00c9cc7bb_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_cataloguenumber
    ADD CONSTRAINT digipal_cataloguenumber_source_id_5930e00c9cc7bb_uniq UNIQUE (source_id, text_id, number, historical_item_id);


--
-- Name: digipal_category_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_category
    ADD CONSTRAINT digipal_category_name_key UNIQUE (name);


--
-- Name: digipal_category_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_category
    ADD CONSTRAINT digipal_category_pkey PRIMARY KEY (id);


--
-- Name: digipal_character_components_character_id_1b523e3f0bae4ccd_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character_components
    ADD CONSTRAINT digipal_character_components_character_id_1b523e3f0bae4ccd_uniq UNIQUE (character_id, component_id);


--
-- Name: digipal_character_components_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character_components
    ADD CONSTRAINT digipal_character_components_pkey PRIMARY KEY (id);


--
-- Name: digipal_character_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character
    ADD CONSTRAINT digipal_character_name_key UNIQUE (name);


--
-- Name: digipal_character_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character
    ADD CONSTRAINT digipal_character_pkey PRIMARY KEY (id);


--
-- Name: digipal_characterform_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_characterform
    ADD CONSTRAINT digipal_characterform_name_key UNIQUE (name);


--
-- Name: digipal_characterform_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_characterform
    ADD CONSTRAINT digipal_characterform_pkey PRIMARY KEY (id);


--
-- Name: digipal_collation_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_collation
    ADD CONSTRAINT digipal_collation_pkey PRIMARY KEY (id);


--
-- Name: digipal_component_features_component_id_21fedf5478617c03_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_component_features
    ADD CONSTRAINT digipal_component_features_component_id_21fedf5478617c03_uniq UNIQUE (component_id, feature_id);


--
-- Name: digipal_component_features_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_component_features
    ADD CONSTRAINT digipal_component_features_pkey PRIMARY KEY (id);


--
-- Name: digipal_component_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_component
    ADD CONSTRAINT digipal_component_name_key UNIQUE (name);


--
-- Name: digipal_component_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_component
    ADD CONSTRAINT digipal_component_pkey PRIMARY KEY (id);


--
-- Name: digipal_county_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_county
    ADD CONSTRAINT digipal_county_name_key UNIQUE (name);


--
-- Name: digipal_county_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_county
    ADD CONSTRAINT digipal_county_pkey PRIMARY KEY (id);


--
-- Name: digipal_currentitem_owners_currentitem_id_1caca3c5ef1809d3_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_currentitem_owners
    ADD CONSTRAINT digipal_currentitem_owners_currentitem_id_1caca3c5ef1809d3_uniq UNIQUE (currentitem_id, owner_id);


--
-- Name: digipal_currentitem_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_currentitem_owners
    ADD CONSTRAINT digipal_currentitem_owners_pkey PRIMARY KEY (id);


--
-- Name: digipal_currentitem_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_currentitem
    ADD CONSTRAINT digipal_currentitem_pkey PRIMARY KEY (id);


--
-- Name: digipal_currentitem_repository_id_26373c79ce7d91df_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_currentitem
    ADD CONSTRAINT digipal_currentitem_repository_id_26373c79ce7d91df_uniq UNIQUE (repository_id, shelfmark);


--
-- Name: digipal_date_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_date
    ADD CONSTRAINT digipal_date_pkey PRIMARY KEY (id);


--
-- Name: digipal_dateevidence_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_dateevidence
    ADD CONSTRAINT digipal_dateevidence_pkey PRIMARY KEY (id);


--
-- Name: digipal_decoration_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_decoration
    ADD CONSTRAINT digipal_decoration_pkey PRIMARY KEY (id);


--
-- Name: digipal_description_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_description
    ADD CONSTRAINT digipal_description_pkey PRIMARY KEY (id);


--
-- Name: digipal_description_source_id_52aa5e9c55e6ac65_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_description
    ADD CONSTRAINT digipal_description_source_id_52aa5e9c55e6ac65_uniq UNIQUE (source_id, text_id, historical_item_id);


--
-- Name: digipal_feature_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_feature
    ADD CONSTRAINT digipal_feature_name_key UNIQUE (name);


--
-- Name: digipal_feature_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_feature
    ADD CONSTRAINT digipal_feature_pkey PRIMARY KEY (id);


--
-- Name: digipal_format_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_format
    ADD CONSTRAINT digipal_format_name_key UNIQUE (name);


--
-- Name: digipal_format_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_format
    ADD CONSTRAINT digipal_format_pkey PRIMARY KEY (id);


--
-- Name: digipal_graph_aspects_graph_id_5a6bee2136d62dbf_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph_aspects
    ADD CONSTRAINT digipal_graph_aspects_graph_id_5a6bee2136d62dbf_uniq UNIQUE (graph_id, aspect_id);


--
-- Name: digipal_graph_aspects_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph_aspects
    ADD CONSTRAINT digipal_graph_aspects_pkey PRIMARY KEY (id);


--
-- Name: digipal_graph_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph
    ADD CONSTRAINT digipal_graph_pkey PRIMARY KEY (id);


--
-- Name: digipal_graphcomponent__graphcomponent_id_10ac817652129971_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graphcomponent_features
    ADD CONSTRAINT digipal_graphcomponent__graphcomponent_id_10ac817652129971_uniq UNIQUE (graphcomponent_id, feature_id);


--
-- Name: digipal_graphcomponent_features_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graphcomponent_features
    ADD CONSTRAINT digipal_graphcomponent_features_pkey PRIMARY KEY (id);


--
-- Name: digipal_graphcomponent_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graphcomponent
    ADD CONSTRAINT digipal_graphcomponent_pkey PRIMARY KEY (id);


--
-- Name: digipal_hair_label_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hair
    ADD CONSTRAINT digipal_hair_label_key UNIQUE (label);


--
-- Name: digipal_hair_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hair
    ADD CONSTRAINT digipal_hair_pkey PRIMARY KEY (id);


--
-- Name: digipal_hand_pages_hand_id_751fe6cc4410dccb_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand_images
    ADD CONSTRAINT digipal_hand_pages_hand_id_751fe6cc4410dccb_uniq UNIQUE (hand_id, image_id);


--
-- Name: digipal_hand_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand_images
    ADD CONSTRAINT digipal_hand_pages_pkey PRIMARY KEY (id);


--
-- Name: digipal_hand_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT digipal_hand_pkey PRIMARY KEY (id);


--
-- Name: digipal_handdescription_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_handdescription
    ADD CONSTRAINT digipal_handdescription_pkey PRIMARY KEY (id);


--
-- Name: digipal_historicalitem__historicalitem_id_4066e470403531ed_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_categories
    ADD CONSTRAINT digipal_historicalitem__historicalitem_id_4066e470403531ed_uniq UNIQUE (historicalitem_id, category_id);


--
-- Name: digipal_historicalitem__historicalitem_id_73e4288db86a7e89_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_owners
    ADD CONSTRAINT digipal_historicalitem__historicalitem_id_73e4288db86a7e89_uniq UNIQUE (historicalitem_id, owner_id);


--
-- Name: digipal_historicalitem_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_categories
    ADD CONSTRAINT digipal_historicalitem_categories_pkey PRIMARY KEY (id);


--
-- Name: digipal_historicalitem_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_owners
    ADD CONSTRAINT digipal_historicalitem_owners_pkey PRIMARY KEY (id);


--
-- Name: digipal_historicalitem_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem
    ADD CONSTRAINT digipal_historicalitem_pkey PRIMARY KEY (id);


--
-- Name: digipal_historicalitemdate_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitemdate
    ADD CONSTRAINT digipal_historicalitemdate_pkey PRIMARY KEY (id);


--
-- Name: digipal_historicalitemtype_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitemtype
    ADD CONSTRAINT digipal_historicalitemtype_pkey PRIMARY KEY (id);


--
-- Name: digipal_idiograph_aspects_idiograph_id_37c29800229491b3_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiograph_aspects
    ADD CONSTRAINT digipal_idiograph_aspects_idiograph_id_37c29800229491b3_uniq UNIQUE (idiograph_id, aspect_id);


--
-- Name: digipal_idiograph_aspects_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiograph_aspects
    ADD CONSTRAINT digipal_idiograph_aspects_pkey PRIMARY KEY (id);


--
-- Name: digipal_idiograph_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiograph
    ADD CONSTRAINT digipal_idiograph_pkey PRIMARY KEY (id);


--
-- Name: digipal_idiographco_idiographcomponent_id_4f822faf06b23e49_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiographcomponent_features
    ADD CONSTRAINT digipal_idiographco_idiographcomponent_id_4f822faf06b23e49_uniq UNIQUE (idiographcomponent_id, feature_id);


--
-- Name: digipal_idiographcomponent_features_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiographcomponent_features
    ADD CONSTRAINT digipal_idiographcomponent_features_pkey PRIMARY KEY (id);


--
-- Name: digipal_idiographcomponent_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiographcomponent
    ADD CONSTRAINT digipal_idiographcomponent_pkey PRIMARY KEY (id);


--
-- Name: digipal_imageannotationstatus_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_imageannotationstatus
    ADD CONSTRAINT digipal_imageannotationstatus_name_key UNIQUE (name);


--
-- Name: digipal_imageannotationstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_imageannotationstatus
    ADD CONSTRAINT digipal_imageannotationstatus_pkey PRIMARY KEY (id);


--
-- Name: digipal_institution_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_institution
    ADD CONSTRAINT digipal_institution_pkey PRIMARY KEY (id);


--
-- Name: digipal_institutiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_institutiontype
    ADD CONSTRAINT digipal_institutiontype_pkey PRIMARY KEY (id);


--
-- Name: digipal_itemorigin_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itemorigin
    ADD CONSTRAINT digipal_itemorigin_pkey PRIMARY KEY (id);


--
-- Name: digipal_itempart_owners_itempart_id_5528c2aa9c73c8f5_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart_owners
    ADD CONSTRAINT digipal_itempart_owners_itempart_id_5528c2aa9c73c8f5_uniq UNIQUE (itempart_id, owner_id);


--
-- Name: digipal_itempart_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart_owners
    ADD CONSTRAINT digipal_itempart_owners_pkey PRIMARY KEY (id);


--
-- Name: digipal_itempart_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart
    ADD CONSTRAINT digipal_itempart_pkey PRIMARY KEY (id);


--
-- Name: digipal_itempartauthenticity_item_part_id_47f6a7c669f3f627_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartauthenticity
    ADD CONSTRAINT digipal_itempartauthenticity_item_part_id_47f6a7c669f3f627_uniq UNIQUE (item_part_id, category_id, source_id);


--
-- Name: digipal_itempartauthenticity_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartauthenticity
    ADD CONSTRAINT digipal_itempartauthenticity_pkey PRIMARY KEY (id);


--
-- Name: digipal_itempartitem_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartitem
    ADD CONSTRAINT digipal_itempartitem_pkey PRIMARY KEY (id);


--
-- Name: digipal_itemparttype_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itemparttype
    ADD CONSTRAINT digipal_itemparttype_name_key UNIQUE (name);


--
-- Name: digipal_itemparttype_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itemparttype
    ADD CONSTRAINT digipal_itemparttype_pkey PRIMARY KEY (id);


--
-- Name: digipal_keyval_key_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_keyval
    ADD CONSTRAINT digipal_keyval_key_key UNIQUE (key);


--
-- Name: digipal_keyval_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_keyval
    ADD CONSTRAINT digipal_keyval_pkey PRIMARY KEY (id);


--
-- Name: digipal_language_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_language
    ADD CONSTRAINT digipal_language_name_key UNIQUE (name);


--
-- Name: digipal_language_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_language
    ADD CONSTRAINT digipal_language_pkey PRIMARY KEY (id);


--
-- Name: digipal_latinstyle_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_latinstyle
    ADD CONSTRAINT digipal_latinstyle_pkey PRIMARY KEY (id);


--
-- Name: digipal_layout_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_layout
    ADD CONSTRAINT digipal_layout_pkey PRIMARY KEY (id);


--
-- Name: digipal_measurement_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_measurement
    ADD CONSTRAINT digipal_measurement_pkey PRIMARY KEY (id);


--
-- Name: digipal_mediapermission_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_mediapermission
    ADD CONSTRAINT digipal_mediapermission_pkey PRIMARY KEY (id);


--
-- Name: digipal_ontograph_name_265c31552bc69539_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_ontograph
    ADD CONSTRAINT digipal_ontograph_name_265c31552bc69539_uniq UNIQUE (name, ontograph_type_id);


--
-- Name: digipal_ontograph_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_ontograph
    ADD CONSTRAINT digipal_ontograph_pkey PRIMARY KEY (id);


--
-- Name: digipal_ontographtype_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_ontographtype
    ADD CONSTRAINT digipal_ontographtype_name_key UNIQUE (name);


--
-- Name: digipal_ontographtype_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_ontographtype
    ADD CONSTRAINT digipal_ontographtype_pkey PRIMARY KEY (id);


--
-- Name: digipal_owner_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_owner
    ADD CONSTRAINT digipal_owner_pkey PRIMARY KEY (id);


--
-- Name: digipal_ownertype_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_ownertype
    ADD CONSTRAINT digipal_ownertype_pkey PRIMARY KEY (id);


--
-- Name: digipal_page_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_image
    ADD CONSTRAINT digipal_page_pkey PRIMARY KEY (id);


--
-- Name: digipal_person_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_person
    ADD CONSTRAINT digipal_person_name_key UNIQUE (name);


--
-- Name: digipal_person_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_person
    ADD CONSTRAINT digipal_person_pkey PRIMARY KEY (id);


--
-- Name: digipal_place_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_place
    ADD CONSTRAINT digipal_place_pkey PRIMARY KEY (id);


--
-- Name: digipal_placeevidence_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_placeevidence
    ADD CONSTRAINT digipal_placeevidence_pkey PRIMARY KEY (id);


--
-- Name: digipal_placetype_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_placetype
    ADD CONSTRAINT digipal_placetype_pkey PRIMARY KEY (id);


--
-- Name: digipal_proportion_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_proportion
    ADD CONSTRAINT digipal_proportion_pkey PRIMARY KEY (id);


--
-- Name: digipal_reference_name_100f1428066baa8c_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_reference
    ADD CONSTRAINT digipal_reference_name_100f1428066baa8c_uniq UNIQUE (name, name_index);


--
-- Name: digipal_reference_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_reference
    ADD CONSTRAINT digipal_reference_pkey PRIMARY KEY (id);


--
-- Name: digipal_region_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_region
    ADD CONSTRAINT digipal_region_name_key UNIQUE (name);


--
-- Name: digipal_region_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_region
    ADD CONSTRAINT digipal_region_pkey PRIMARY KEY (id);


--
-- Name: digipal_repository_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_repository
    ADD CONSTRAINT digipal_repository_pkey PRIMARY KEY (id);


--
-- Name: digipal_requestlog_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_requestlog
    ADD CONSTRAINT digipal_requestlog_pkey PRIMARY KEY (id);


--
-- Name: digipal_scribe_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scribe
    ADD CONSTRAINT digipal_scribe_name_key UNIQUE (name);


--
-- Name: digipal_scribe_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scribe
    ADD CONSTRAINT digipal_scribe_pkey PRIMARY KEY (id);


--
-- Name: digipal_scribe_reference_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scribe_reference
    ADD CONSTRAINT digipal_scribe_reference_pkey PRIMARY KEY (id);


--
-- Name: digipal_scribe_reference_scribe_id_4c0edc26647a0f9d_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scribe_reference
    ADD CONSTRAINT digipal_scribe_reference_scribe_id_4c0edc26647a0f9d_uniq UNIQUE (scribe_id, reference_id);


--
-- Name: digipal_script_allographs_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_script_allographs
    ADD CONSTRAINT digipal_script_allographs_pkey PRIMARY KEY (id);


--
-- Name: digipal_script_allographs_script_id_10f72c9e70e2519_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_script_allographs
    ADD CONSTRAINT digipal_script_allographs_script_id_10f72c9e70e2519_uniq UNIQUE (script_id, allograph_id);


--
-- Name: digipal_script_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_script
    ADD CONSTRAINT digipal_script_pkey PRIMARY KEY (id);


--
-- Name: digipal_scriptcomponent_features_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scriptcomponent_features
    ADD CONSTRAINT digipal_scriptcomponent_features_pkey PRIMARY KEY (id);


--
-- Name: digipal_scriptcomponent_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scriptcomponent
    ADD CONSTRAINT digipal_scriptcomponent_pkey PRIMARY KEY (id);


--
-- Name: digipal_scriptcomponent_scriptcomponent_id_7a1a2f2734cd999_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scriptcomponent_features
    ADD CONSTRAINT digipal_scriptcomponent_scriptcomponent_id_7a1a2f2734cd999_uniq UNIQUE (scriptcomponent_id, feature_id);


--
-- Name: digipal_source_label_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_source
    ADD CONSTRAINT digipal_source_label_key UNIQUE (label);


--
-- Name: digipal_source_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_source
    ADD CONSTRAINT digipal_source_name_key UNIQUE (name);


--
-- Name: digipal_source_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_source
    ADD CONSTRAINT digipal_source_pkey PRIMARY KEY (id);


--
-- Name: digipal_status_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_status
    ADD CONSTRAINT digipal_status_name_key UNIQUE (name);


--
-- Name: digipal_status_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_status
    ADD CONSTRAINT digipal_status_pkey PRIMARY KEY (id);


--
-- Name: digipal_stewartrecord_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_stewartrecord
    ADD CONSTRAINT digipal_stewartrecord_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_categories
    ADD CONSTRAINT digipal_text_categories_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_categories_text_id_2f28f4b1877a5d69_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_categories
    ADD CONSTRAINT digipal_text_categories_text_id_2f28f4b1877a5d69_uniq UNIQUE (text_id, category_id);


--
-- Name: digipal_text_entryhand_item_part_id_7315d68a2369bb35_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_entryhand
    ADD CONSTRAINT digipal_text_entryhand_item_part_id_7315d68a2369bb35_uniq UNIQUE (item_part_id, entry_number, hand_label, "order", correction);


--
-- Name: digipal_text_entryhand_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_entryhand
    ADD CONSTRAINT digipal_text_entryhand_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_languages_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_languages
    ADD CONSTRAINT digipal_text_languages_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_languages_text_id_226c2b5c0566249f_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_languages
    ADD CONSTRAINT digipal_text_languages_text_id_226c2b5c0566249f_uniq UNIQUE (text_id, language_id);


--
-- Name: digipal_text_name_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text
    ADD CONSTRAINT digipal_text_name_uniq UNIQUE (name);


--
-- Name: digipal_text_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text
    ADD CONSTRAINT digipal_text_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_textannotation_annotation_id_ace38c747c2b414_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textannotation
    ADD CONSTRAINT digipal_text_textannotation_annotation_id_ace38c747c2b414_uniq UNIQUE (annotation_id, elementid);


--
-- Name: digipal_text_textannotation_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textannotation
    ADD CONSTRAINT digipal_text_textannotation_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_textcontent_item_part_id_13494d9cc4c7cecd_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent
    ADD CONSTRAINT digipal_text_textcontent_item_part_id_13494d9cc4c7cecd_uniq UNIQUE (item_part_id, type_id);


--
-- Name: digipal_text_textcontent_l_textcontent_id_7f15c6885917f53e_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent_languages
    ADD CONSTRAINT digipal_text_textcontent_l_textcontent_id_7f15c6885917f53e_uniq UNIQUE (textcontent_id, language_id);


--
-- Name: digipal_text_textcontent_languages_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent_languages
    ADD CONSTRAINT digipal_text_textcontent_languages_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_textcontent_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent
    ADD CONSTRAINT digipal_text_textcontent_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_textcontenttype_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontenttype
    ADD CONSTRAINT digipal_text_textcontenttype_name_key UNIQUE (name);


--
-- Name: digipal_text_textcontenttype_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontenttype
    ADD CONSTRAINT digipal_text_textcontenttype_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_textcontentxml_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxml
    ADD CONSTRAINT digipal_text_textcontentxml_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_textcontentxml_text_content_id_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxml
    ADD CONSTRAINT digipal_text_textcontentxml_text_content_id_uniq UNIQUE (text_content_id);


--
-- Name: digipal_text_textcontentxmlcopy_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxmlcopy
    ADD CONSTRAINT digipal_text_textcontentxmlcopy_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_textcontentxmlcopy_source_id_112d7bdb8b83fa28_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxmlcopy
    ADD CONSTRAINT digipal_text_textcontentxmlcopy_source_id_112d7bdb8b83fa28_uniq UNIQUE (source_id, ahash);


--
-- Name: digipal_text_textcontentxmlstatus_name_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxmlstatus
    ADD CONSTRAINT digipal_text_textcontentxmlstatus_name_key UNIQUE (name);


--
-- Name: digipal_text_textcontentxmlstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxmlstatus
    ADD CONSTRAINT digipal_text_textcontentxmlstatus_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_textpattern_key_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textpattern
    ADD CONSTRAINT digipal_text_textpattern_key_key UNIQUE (key);


--
-- Name: digipal_text_textpattern_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textpattern
    ADD CONSTRAINT digipal_text_textpattern_pkey PRIMARY KEY (id);


--
-- Name: digipal_text_textpattern_title_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textpattern
    ADD CONSTRAINT digipal_text_textpattern_title_key UNIQUE (title);


--
-- Name: digipal_textitempart_item_part_id_54a67d5d6a0c9393_uniq; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_textitempart
    ADD CONSTRAINT digipal_textitempart_item_part_id_54a67d5d6a0c9393_uniq UNIQUE (item_part_id, text_id);


--
-- Name: digipal_textitempart_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_textitempart
    ADD CONSTRAINT digipal_textitempart_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags_user_id_comment_id_flag_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_comment_id_flag_key UNIQUE (user_id, comment_id, flag);


--
-- Name: django_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comments_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_model_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_redirect_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_redirect
    ADD CONSTRAINT django_redirect_pkey PRIMARY KEY (id);


--
-- Name: django_redirect_site_id_old_path_key; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_redirect
    ADD CONSTRAINT django_redirect_site_id_old_path_key UNIQUE (site_id, old_path);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: forms_field_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_field
    ADD CONSTRAINT forms_field_pkey PRIMARY KEY (id);


--
-- Name: forms_fieldentry_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_fieldentry
    ADD CONSTRAINT forms_fieldentry_pkey PRIMARY KEY (id);


--
-- Name: forms_form_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_form
    ADD CONSTRAINT forms_form_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: forms_formentry_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_formentry
    ADD CONSTRAINT forms_formentry_pkey PRIMARY KEY (id);


--
-- Name: galleries_gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY galleries_gallery
    ADD CONSTRAINT galleries_gallery_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: galleries_galleryimage_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY galleries_galleryimage
    ADD CONSTRAINT galleries_galleryimage_pkey PRIMARY KEY (id);


--
-- Name: generic_assignedkeyword_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_assignedkeyword
    ADD CONSTRAINT generic_assignedkeyword_pkey PRIMARY KEY (id);


--
-- Name: generic_keyword_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_keyword
    ADD CONSTRAINT generic_keyword_pkey PRIMARY KEY (id);


--
-- Name: generic_rating_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_rating
    ADD CONSTRAINT generic_rating_pkey PRIMARY KEY (id);


--
-- Name: generic_threadedcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_threadedcomment
    ADD CONSTRAINT generic_threadedcomment_pkey PRIMARY KEY (comment_ptr_id);


--
-- Name: pages_contentpage_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY pages_richtextpage
    ADD CONSTRAINT pages_contentpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: pages_link_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY pages_link
    ADD CONSTRAINT pages_link_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: pages_page_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY pages_page
    ADD CONSTRAINT pages_page_pkey PRIMARY KEY (id);


--
-- Name: reversion_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY reversion_revision
    ADD CONSTRAINT reversion_revision_pkey PRIMARY KEY (id);


--
-- Name: reversion_version_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY reversion_version
    ADD CONSTRAINT reversion_version_pkey PRIMARY KEY (id);


--
-- Name: south_migrationhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY south_migrationhistory
    ADD CONSTRAINT south_migrationhistory_pkey PRIMARY KEY (id);


--
-- Name: twitter_query_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY twitter_query
    ADD CONSTRAINT twitter_query_pkey PRIMARY KEY (id);


--
-- Name: twitter_tweet_pkey; Type: CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY twitter_tweet
    ADD CONSTRAINT twitter_tweet_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX auth_group_name_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX auth_user_username_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: blog_blogcategory_site_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX blog_blogcategory_site_id ON blog_blogcategory USING btree (site_id);


--
-- Name: blog_blogpost_categories_blogcategory_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX blog_blogpost_categories_blogcategory_id ON blog_blogpost_categories USING btree (blogcategory_id);


--
-- Name: blog_blogpost_categories_blogpost_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX blog_blogpost_categories_blogpost_id ON blog_blogpost_categories USING btree (blogpost_id);


--
-- Name: blog_blogpost_publish_date_1015da2554a8e97f_uniq; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX blog_blogpost_publish_date_1015da2554a8e97f_uniq ON blog_blogpost USING btree (publish_date);


--
-- Name: blog_blogpost_related_posts_from_blogpost_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX blog_blogpost_related_posts_from_blogpost_id ON blog_blogpost_related_posts USING btree (from_blogpost_id);


--
-- Name: blog_blogpost_related_posts_to_blogpost_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX blog_blogpost_related_posts_to_blogpost_id ON blog_blogpost_related_posts USING btree (to_blogpost_id);


--
-- Name: blog_blogpost_site_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX blog_blogpost_site_id ON blog_blogpost USING btree (site_id);


--
-- Name: blog_blogpost_user_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX blog_blogpost_user_id ON blog_blogpost USING btree (user_id);


--
-- Name: conf_setting_site_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX conf_setting_site_id ON conf_setting USING btree (site_id);


--
-- Name: core_sitepermission_sites_site_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX core_sitepermission_sites_site_id ON core_sitepermission_sites USING btree (site_id);


--
-- Name: core_sitepermission_sites_sitepermission_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX core_sitepermission_sites_sitepermission_id ON core_sitepermission_sites USING btree (sitepermission_id);


--
-- Name: digipal_allograph_aspects_allograph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_allograph_aspects_allograph_id ON digipal_allograph_aspects USING btree (allograph_id);


--
-- Name: digipal_allograph_aspects_aspect_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_allograph_aspects_aspect_id ON digipal_allograph_aspects USING btree (aspect_id);


--
-- Name: digipal_allograph_character_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_allograph_character_id ON digipal_allograph USING btree (character_id);


--
-- Name: digipal_allographcomponent_allograph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_allographcomponent_allograph_id ON digipal_allographcomponent USING btree (allograph_id);


--
-- Name: digipal_allographcomponent_component_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_allographcomponent_component_id ON digipal_allographcomponent USING btree (component_id);


--
-- Name: digipal_allographcomponent_features_allographcomponent_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_allographcomponent_features_allographcomponent_id ON digipal_allographcomponent_features USING btree (allographcomponent_id);


--
-- Name: digipal_allographcomponent_features_feature_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_allographcomponent_features_feature_id ON digipal_allographcomponent_features USING btree (feature_id);


--
-- Name: digipal_alphabet_hands_alphabet_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_alphabet_hands_alphabet_id ON digipal_alphabet_hands USING btree (alphabet_id);


--
-- Name: digipal_alphabet_hands_hand_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_alphabet_hands_hand_id ON digipal_alphabet_hands USING btree (hand_id);


--
-- Name: digipal_alphabet_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_alphabet_name_like ON digipal_alphabet USING btree (name varchar_pattern_ops);


--
-- Name: digipal_alphabet_ontographs_alphabet_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_alphabet_ontographs_alphabet_id ON digipal_alphabet_ontographs USING btree (alphabet_id);


--
-- Name: digipal_alphabet_ontographs_ontograph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_alphabet_ontographs_ontograph_id ON digipal_alphabet_ontographs USING btree (ontograph_id);


--
-- Name: digipal_annotation_after_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_annotation_after_id ON digipal_annotation USING btree (after_id);


--
-- Name: digipal_annotation_author_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_annotation_author_id ON digipal_annotation USING btree (author_id);


--
-- Name: digipal_annotation_before_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_annotation_before_id ON digipal_annotation USING btree (before_id);


--
-- Name: digipal_annotation_clientid; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_annotation_clientid ON digipal_annotation USING btree (clientid);


--
-- Name: digipal_annotation_clientid_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_annotation_clientid_like ON digipal_annotation USING btree (clientid varchar_pattern_ops);


--
-- Name: digipal_annotation_page_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_annotation_page_id ON digipal_annotation USING btree (image_id);


--
-- Name: digipal_annotation_status_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_annotation_status_id ON digipal_annotation USING btree (status_id);


--
-- Name: digipal_annotation_type; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_annotation_type ON digipal_annotation USING btree (type);


--
-- Name: digipal_annotation_type_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_annotation_type_like ON digipal_annotation USING btree (type varchar_pattern_ops);


--
-- Name: digipal_apitransform_slug_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_apitransform_slug_like ON digipal_apitransform USING btree (slug varchar_pattern_ops);


--
-- Name: digipal_apitransform_title_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_apitransform_title_like ON digipal_apitransform USING btree (title varchar_pattern_ops);


--
-- Name: digipal_archive_content_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_archive_content_type_id ON digipal_archive USING btree (content_type_id);


--
-- Name: digipal_archive_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_archive_historical_item_id ON digipal_archive USING btree (historical_item_id);


--
-- Name: digipal_aspect_features_aspect_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_aspect_features_aspect_id ON digipal_aspect_features USING btree (aspect_id);


--
-- Name: digipal_aspect_features_feature_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_aspect_features_feature_id ON digipal_aspect_features USING btree (feature_id);


--
-- Name: digipal_aspect_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_aspect_name_like ON digipal_aspect USING btree (name varchar_pattern_ops);


--
-- Name: digipal_authenticitycategory_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_authenticitycategory_name_like ON digipal_authenticitycategory USING btree (name varchar_pattern_ops);


--
-- Name: digipal_authenticitycategory_slug; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_authenticitycategory_slug ON digipal_authenticitycategory USING btree (slug);


--
-- Name: digipal_authenticitycategory_slug_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_authenticitycategory_slug_like ON digipal_authenticitycategory USING btree (slug varchar_pattern_ops);


--
-- Name: digipal_cataloguenumber_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_cataloguenumber_historical_item_id ON digipal_cataloguenumber USING btree (historical_item_id);


--
-- Name: digipal_cataloguenumber_number_slug; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_cataloguenumber_number_slug ON digipal_cataloguenumber USING btree (number_slug);


--
-- Name: digipal_cataloguenumber_number_slug_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_cataloguenumber_number_slug_like ON digipal_cataloguenumber USING btree (number_slug varchar_pattern_ops);


--
-- Name: digipal_cataloguenumber_source_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_cataloguenumber_source_id ON digipal_cataloguenumber USING btree (source_id);


--
-- Name: digipal_cataloguenumber_text_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_cataloguenumber_text_id ON digipal_cataloguenumber USING btree (text_id);


--
-- Name: digipal_category_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_category_name_like ON digipal_category USING btree (name varchar_pattern_ops);


--
-- Name: digipal_character_components_character_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_character_components_character_id ON digipal_character_components USING btree (character_id);


--
-- Name: digipal_character_components_component_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_character_components_component_id ON digipal_character_components USING btree (component_id);


--
-- Name: digipal_character_form_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_character_form_id ON digipal_character USING btree (form_id);


--
-- Name: digipal_character_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_character_name_like ON digipal_character USING btree (name varchar_pattern_ops);


--
-- Name: digipal_character_ontograph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_character_ontograph_id ON digipal_character USING btree (ontograph_id);


--
-- Name: digipal_character_unicode_point_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_character_unicode_point_like ON digipal_character USING btree (unicode_point varchar_pattern_ops);


--
-- Name: digipal_characterform_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_characterform_name_like ON digipal_characterform USING btree (name varchar_pattern_ops);


--
-- Name: digipal_collation_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_collation_historical_item_id ON digipal_collation USING btree (historical_item_id);


--
-- Name: digipal_component_features_component_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_component_features_component_id ON digipal_component_features USING btree (component_id);


--
-- Name: digipal_component_features_feature_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_component_features_feature_id ON digipal_component_features USING btree (feature_id);


--
-- Name: digipal_component_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_component_name_like ON digipal_component USING btree (name varchar_pattern_ops);


--
-- Name: digipal_county_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_county_name_like ON digipal_county USING btree (name varchar_pattern_ops);


--
-- Name: digipal_currentitem_owners_currentitem_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_currentitem_owners_currentitem_id ON digipal_currentitem_owners USING btree (currentitem_id);


--
-- Name: digipal_currentitem_owners_owner_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_currentitem_owners_owner_id ON digipal_currentitem_owners USING btree (owner_id);


--
-- Name: digipal_currentitem_repository_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_currentitem_repository_id ON digipal_currentitem USING btree (repository_id);


--
-- Name: digipal_dateevidence_date_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_dateevidence_date_id ON digipal_dateevidence USING btree (date_id);


--
-- Name: digipal_dateevidence_hand_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_dateevidence_hand_id ON digipal_dateevidence USING btree (hand_id);


--
-- Name: digipal_dateevidence_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_dateevidence_historical_item_id ON digipal_dateevidence USING btree (historical_item_id);


--
-- Name: digipal_dateevidence_reference_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_dateevidence_reference_id ON digipal_dateevidence USING btree (reference_id);


--
-- Name: digipal_decoration_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_decoration_historical_item_id ON digipal_decoration USING btree (historical_item_id);


--
-- Name: digipal_description_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_description_historical_item_id ON digipal_description USING btree (historical_item_id);


--
-- Name: digipal_description_source_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_description_source_id ON digipal_description USING btree (source_id);


--
-- Name: digipal_description_text_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_description_text_id ON digipal_description USING btree (text_id);


--
-- Name: digipal_feature_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_feature_name_like ON digipal_feature USING btree (name varchar_pattern_ops);


--
-- Name: digipal_format_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_format_name_like ON digipal_format USING btree (name varchar_pattern_ops);


--
-- Name: digipal_graph_aspects_aspect_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_graph_aspects_aspect_id ON digipal_graph_aspects USING btree (aspect_id);


--
-- Name: digipal_graph_aspects_graph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_graph_aspects_graph_id ON digipal_graph_aspects USING btree (graph_id);


--
-- Name: digipal_graph_group_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_graph_group_id ON digipal_graph USING btree (group_id);


--
-- Name: digipal_graph_hand_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_graph_hand_id ON digipal_graph USING btree (hand_id);


--
-- Name: digipal_graph_idiograph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_graph_idiograph_id ON digipal_graph USING btree (idiograph_id);


--
-- Name: digipal_graphcomponent_component_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_graphcomponent_component_id ON digipal_graphcomponent USING btree (component_id);


--
-- Name: digipal_graphcomponent_features_feature_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_graphcomponent_features_feature_id ON digipal_graphcomponent_features USING btree (feature_id);


--
-- Name: digipal_graphcomponent_features_graphcomponent_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_graphcomponent_features_graphcomponent_id ON digipal_graphcomponent_features USING btree (graphcomponent_id);


--
-- Name: digipal_graphcomponent_graph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_graphcomponent_graph_id ON digipal_graphcomponent USING btree (graph_id);


--
-- Name: digipal_hair_label_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hair_label_like ON digipal_hair USING btree (label varchar_pattern_ops);


--
-- Name: digipal_hand_appearance_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_appearance_id ON digipal_hand USING btree (appearance_id);


--
-- Name: digipal_hand_assigned_date_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_assigned_date_id ON digipal_hand USING btree (assigned_date_id);


--
-- Name: digipal_hand_assigned_place_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_assigned_place_id ON digipal_hand USING btree (assigned_place_id);


--
-- Name: digipal_hand_glossed_text_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_glossed_text_id ON digipal_hand USING btree (glossed_text_id);


--
-- Name: digipal_hand_item_part_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_item_part_id ON digipal_hand USING btree (item_part_id);


--
-- Name: digipal_hand_latin_style_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_latin_style_id ON digipal_hand USING btree (latin_style_id);


--
-- Name: digipal_hand_pages_hand_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_pages_hand_id ON digipal_hand_images USING btree (hand_id);


--
-- Name: digipal_hand_pages_page_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_pages_page_id ON digipal_hand_images USING btree (image_id);


--
-- Name: digipal_hand_scribe_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_scribe_id ON digipal_hand USING btree (scribe_id);


--
-- Name: digipal_hand_script_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_script_id ON digipal_hand USING btree (script_id);


--
-- Name: digipal_hand_stewart_record_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_hand_stewart_record_id ON digipal_hand USING btree (stewart_record_id);


--
-- Name: digipal_handdescription_hand_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_handdescription_hand_id ON digipal_handdescription USING btree (hand_id);


--
-- Name: digipal_handdescription_source_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_handdescription_source_id ON digipal_handdescription USING btree (source_id);


--
-- Name: digipal_historicalitem_categories_category_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitem_categories_category_id ON digipal_historicalitem_categories USING btree (category_id);


--
-- Name: digipal_historicalitem_categories_historicalitem_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitem_categories_historicalitem_id ON digipal_historicalitem_categories USING btree (historicalitem_id);


--
-- Name: digipal_historicalitem_hair_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitem_hair_id ON digipal_historicalitem USING btree (hair_id);


--
-- Name: digipal_historicalitem_historical_item_format_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitem_historical_item_format_id ON digipal_historicalitem USING btree (historical_item_format_id);


--
-- Name: digipal_historicalitem_historical_item_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitem_historical_item_type_id ON digipal_historicalitem USING btree (historical_item_type_id);


--
-- Name: digipal_historicalitem_language_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitem_language_id ON digipal_historicalitem USING btree (language_id);


--
-- Name: digipal_historicalitem_owners_historicalitem_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitem_owners_historicalitem_id ON digipal_historicalitem_owners USING btree (historicalitem_id);


--
-- Name: digipal_historicalitem_owners_owner_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitem_owners_owner_id ON digipal_historicalitem_owners USING btree (owner_id);


--
-- Name: digipal_historicalitemdate_date_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitemdate_date_id ON digipal_historicalitemdate USING btree (date_id);


--
-- Name: digipal_historicalitemdate_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_historicalitemdate_historical_item_id ON digipal_historicalitemdate USING btree (historical_item_id);


--
-- Name: digipal_idiograph_allograph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_idiograph_allograph_id ON digipal_idiograph USING btree (allograph_id);


--
-- Name: digipal_idiograph_aspects_aspect_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_idiograph_aspects_aspect_id ON digipal_idiograph_aspects USING btree (aspect_id);


--
-- Name: digipal_idiograph_aspects_idiograph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_idiograph_aspects_idiograph_id ON digipal_idiograph_aspects USING btree (idiograph_id);


--
-- Name: digipal_idiograph_scribe_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_idiograph_scribe_id ON digipal_idiograph USING btree (scribe_id);


--
-- Name: digipal_idiographcomponent_component_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_idiographcomponent_component_id ON digipal_idiographcomponent USING btree (component_id);


--
-- Name: digipal_idiographcomponent_features_feature_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_idiographcomponent_features_feature_id ON digipal_idiographcomponent_features USING btree (feature_id);


--
-- Name: digipal_idiographcomponent_features_idiographcomponent_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_idiographcomponent_features_idiographcomponent_id ON digipal_idiographcomponent_features USING btree (idiographcomponent_id);


--
-- Name: digipal_idiographcomponent_idiograph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_idiographcomponent_idiograph_id ON digipal_idiographcomponent USING btree (idiograph_id);


--
-- Name: digipal_image_annotation_status_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_image_annotation_status_id ON digipal_image USING btree (annotation_status_id);


--
-- Name: digipal_imageannotationstatus_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_imageannotationstatus_name_like ON digipal_imageannotationstatus USING btree (name varchar_pattern_ops);


--
-- Name: digipal_institution_founder_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_institution_founder_id ON digipal_institution USING btree (founder_id);


--
-- Name: digipal_institution_institution_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_institution_institution_type_id ON digipal_institution USING btree (institution_type_id);


--
-- Name: digipal_institution_patron_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_institution_patron_id ON digipal_institution USING btree (patron_id);


--
-- Name: digipal_institution_place_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_institution_place_id ON digipal_institution USING btree (place_id);


--
-- Name: digipal_institution_reformer_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_institution_reformer_id ON digipal_institution USING btree (reformer_id);


--
-- Name: digipal_itemorigin_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itemorigin_historical_item_id ON digipal_itemorigin USING btree (historical_item_id);


--
-- Name: digipal_itemorigin_institution_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itemorigin_institution_id ON digipal_itemorigin USING btree (institution_id);


--
-- Name: digipal_itemorigin_place_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itemorigin_place_id ON digipal_itemorigin USING btree (place_id);


--
-- Name: digipal_itempart_current_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempart_current_item_id ON digipal_itempart USING btree (current_item_id);


--
-- Name: digipal_itempart_group_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempart_group_id ON digipal_itempart USING btree (group_id);


--
-- Name: digipal_itempart_owners_itempart_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempart_owners_itempart_id ON digipal_itempart_owners USING btree (itempart_id);


--
-- Name: digipal_itempart_owners_owner_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempart_owners_owner_id ON digipal_itempart_owners USING btree (owner_id);


--
-- Name: digipal_itempart_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempart_type_id ON digipal_itempart USING btree (type_id);


--
-- Name: digipal_itempartauthenticity_category_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempartauthenticity_category_id ON digipal_itempartauthenticity USING btree (category_id);


--
-- Name: digipal_itempartauthenticity_item_part_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempartauthenticity_item_part_id ON digipal_itempartauthenticity USING btree (item_part_id);


--
-- Name: digipal_itempartauthenticity_source_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempartauthenticity_source_id ON digipal_itempartauthenticity USING btree (source_id);


--
-- Name: digipal_itempartitem_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempartitem_historical_item_id ON digipal_itempartitem USING btree (historical_item_id);


--
-- Name: digipal_itempartitem_item_part_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itempartitem_item_part_id ON digipal_itempartitem USING btree (item_part_id);


--
-- Name: digipal_itemparttype_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_itemparttype_name_like ON digipal_itemparttype USING btree (name varchar_pattern_ops);


--
-- Name: digipal_language_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_language_name_like ON digipal_language USING btree (name varchar_pattern_ops);


--
-- Name: digipal_layout_hair_arrangement_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_layout_hair_arrangement_id ON digipal_layout USING btree (hair_arrangement_id);


--
-- Name: digipal_layout_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_layout_historical_item_id ON digipal_layout USING btree (historical_item_id);


--
-- Name: digipal_layout_item_part_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_layout_item_part_id ON digipal_layout USING btree (item_part_id);


--
-- Name: digipal_ontograph_ontograph_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_ontograph_ontograph_type_id ON digipal_ontograph USING btree (ontograph_type_id);


--
-- Name: digipal_ontographtype_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_ontographtype_name_like ON digipal_ontographtype USING btree (name varchar_pattern_ops);


--
-- Name: digipal_owner_institution_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_owner_institution_id ON digipal_owner USING btree (institution_id);


--
-- Name: digipal_owner_person_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_owner_person_id ON digipal_owner USING btree (person_id);


--
-- Name: digipal_owner_repository_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_owner_repository_id ON digipal_owner USING btree (repository_id);


--
-- Name: digipal_page_item_part_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_page_item_part_id ON digipal_image USING btree (item_part_id);


--
-- Name: digipal_page_media_permission_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_page_media_permission_id ON digipal_image USING btree (media_permission_id);


--
-- Name: digipal_person_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_person_name_like ON digipal_person USING btree (name varchar_pattern_ops);


--
-- Name: digipal_place_current_county_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_place_current_county_id ON digipal_place USING btree (current_county_id);


--
-- Name: digipal_place_historical_county_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_place_historical_county_id ON digipal_place USING btree (historical_county_id);


--
-- Name: digipal_place_region_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_place_region_id ON digipal_place USING btree (region_id);


--
-- Name: digipal_place_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_place_type_id ON digipal_place USING btree (type_id);


--
-- Name: digipal_placeevidence_hand_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_placeevidence_hand_id ON digipal_placeevidence USING btree (hand_id);


--
-- Name: digipal_placeevidence_historical_item_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_placeevidence_historical_item_id ON digipal_placeevidence USING btree (historical_item_id);


--
-- Name: digipal_placeevidence_place_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_placeevidence_place_id ON digipal_placeevidence USING btree (place_id);


--
-- Name: digipal_placeevidence_reference_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_placeevidence_reference_id ON digipal_placeevidence USING btree (reference_id);


--
-- Name: digipal_proportion_hand_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_proportion_hand_id ON digipal_proportion USING btree (hand_id);


--
-- Name: digipal_proportion_measurement_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_proportion_measurement_id ON digipal_proportion USING btree (measurement_id);


--
-- Name: digipal_region_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_region_name_like ON digipal_region USING btree (name varchar_pattern_ops);


--
-- Name: digipal_repository_media_permission_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_repository_media_permission_id ON digipal_repository USING btree (media_permission_id);


--
-- Name: digipal_repository_part_of_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_repository_part_of_id ON digipal_repository USING btree (part_of_id);


--
-- Name: digipal_repository_place_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_repository_place_id ON digipal_repository USING btree (place_id);


--
-- Name: digipal_repository_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_repository_type_id ON digipal_repository USING btree (type_id);


--
-- Name: digipal_scribe_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_scribe_name_like ON digipal_scribe USING btree (name varchar_pattern_ops);


--
-- Name: digipal_scribe_reference_reference_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_scribe_reference_reference_id ON digipal_scribe_reference USING btree (reference_id);


--
-- Name: digipal_scribe_reference_scribe_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_scribe_reference_scribe_id ON digipal_scribe_reference USING btree (scribe_id);


--
-- Name: digipal_scribe_scriptorium_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_scribe_scriptorium_id ON digipal_scribe USING btree (scriptorium_id);


--
-- Name: digipal_script_allographs_allograph_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_script_allographs_allograph_id ON digipal_script_allographs USING btree (allograph_id);


--
-- Name: digipal_script_allographs_script_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_script_allographs_script_id ON digipal_script_allographs USING btree (script_id);


--
-- Name: digipal_scriptcomponent_component_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_scriptcomponent_component_id ON digipal_scriptcomponent USING btree (component_id);


--
-- Name: digipal_scriptcomponent_features_feature_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_scriptcomponent_features_feature_id ON digipal_scriptcomponent_features USING btree (feature_id);


--
-- Name: digipal_scriptcomponent_features_scriptcomponent_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_scriptcomponent_features_scriptcomponent_id ON digipal_scriptcomponent_features USING btree (scriptcomponent_id);


--
-- Name: digipal_scriptcomponent_script_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_scriptcomponent_script_id ON digipal_scriptcomponent USING btree (script_id);


--
-- Name: digipal_source_label_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_source_label_like ON digipal_source USING btree (label varchar_pattern_ops);


--
-- Name: digipal_source_label_slug; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_source_label_slug ON digipal_source USING btree (label_slug);


--
-- Name: digipal_source_label_slug_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_source_label_slug_like ON digipal_source USING btree (label_slug varchar_pattern_ops);


--
-- Name: digipal_source_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_source_name_like ON digipal_source USING btree (name varchar_pattern_ops);


--
-- Name: digipal_status_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_status_name_like ON digipal_status USING btree (name varchar_pattern_ops);


--
-- Name: digipal_text_categories_category_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_categories_category_id ON digipal_text_categories USING btree (category_id);


--
-- Name: digipal_text_categories_text_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_categories_text_id ON digipal_text_categories USING btree (text_id);


--
-- Name: digipal_text_entryhand_correction; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_entryhand_correction ON digipal_text_entryhand USING btree (correction);


--
-- Name: digipal_text_entryhand_entry_number; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_entryhand_entry_number ON digipal_text_entryhand USING btree (entry_number);


--
-- Name: digipal_text_entryhand_entry_number_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_entryhand_entry_number_like ON digipal_text_entryhand USING btree (entry_number varchar_pattern_ops);


--
-- Name: digipal_text_entryhand_hand_label; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_entryhand_hand_label ON digipal_text_entryhand USING btree (hand_label);


--
-- Name: digipal_text_entryhand_hand_label_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_entryhand_hand_label_like ON digipal_text_entryhand USING btree (hand_label varchar_pattern_ops);


--
-- Name: digipal_text_entryhand_item_part_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_entryhand_item_part_id ON digipal_text_entryhand USING btree (item_part_id);


--
-- Name: digipal_text_entryhand_order; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_entryhand_order ON digipal_text_entryhand USING btree ("order");


--
-- Name: digipal_text_languages_language_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_languages_language_id ON digipal_text_languages USING btree (language_id);


--
-- Name: digipal_text_languages_text_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_languages_text_id ON digipal_text_languages USING btree (text_id);


--
-- Name: digipal_text_textannotation_annotation_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textannotation_annotation_id ON digipal_text_textannotation USING btree (annotation_id);


--
-- Name: digipal_text_textcontent_item_part_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontent_item_part_id ON digipal_text_textcontent USING btree (item_part_id);


--
-- Name: digipal_text_textcontent_languages_language_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontent_languages_language_id ON digipal_text_textcontent_languages USING btree (language_id);


--
-- Name: digipal_text_textcontent_languages_textcontent_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontent_languages_textcontent_id ON digipal_text_textcontent_languages USING btree (textcontent_id);


--
-- Name: digipal_text_textcontent_text_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontent_text_id ON digipal_text_textcontent USING btree (text_id);


--
-- Name: digipal_text_textcontent_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontent_type_id ON digipal_text_textcontent USING btree (type_id);


--
-- Name: digipal_text_textcontenttype_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontenttype_name_like ON digipal_text_textcontenttype USING btree (name varchar_pattern_ops);


--
-- Name: digipal_text_textcontenttype_slug; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontenttype_slug ON digipal_text_textcontenttype USING btree (slug);


--
-- Name: digipal_text_textcontenttype_slug_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontenttype_slug_like ON digipal_text_textcontenttype USING btree (slug varchar_pattern_ops);


--
-- Name: digipal_text_textcontentxml_last_image_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontentxml_last_image_id ON digipal_text_textcontentxml USING btree (last_image_id);


--
-- Name: digipal_text_textcontentxml_status_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontentxml_status_id ON digipal_text_textcontentxml USING btree (status_id);


--
-- Name: digipal_text_textcontentxml_text_content_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontentxml_text_content_id ON digipal_text_textcontentxml USING btree (text_content_id);


--
-- Name: digipal_text_textcontentxmlcopy_source_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontentxmlcopy_source_id ON digipal_text_textcontentxmlcopy USING btree (source_id);


--
-- Name: digipal_text_textcontentxmlstatus_name_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontentxmlstatus_name_like ON digipal_text_textcontentxmlstatus USING btree (name varchar_pattern_ops);


--
-- Name: digipal_text_textcontentxmlstatus_slug; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontentxmlstatus_slug ON digipal_text_textcontentxmlstatus USING btree (slug);


--
-- Name: digipal_text_textcontentxmlstatus_slug_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_text_textcontentxmlstatus_slug_like ON digipal_text_textcontentxmlstatus USING btree (slug varchar_pattern_ops);


--
-- Name: digipal_textitempart_item_part_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_textitempart_item_part_id ON digipal_textitempart USING btree (item_part_id);


--
-- Name: digipal_textitempart_text_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX digipal_textitempart_text_id ON digipal_textitempart USING btree (text_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_comment_flags_comment_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_comment_flags_comment_id ON django_comment_flags USING btree (comment_id);


--
-- Name: django_comment_flags_flag; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_comment_flags_flag ON django_comment_flags USING btree (flag);


--
-- Name: django_comment_flags_flag_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_comment_flags_flag_like ON django_comment_flags USING btree (flag varchar_pattern_ops);


--
-- Name: django_comment_flags_user_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_comment_flags_user_id ON django_comment_flags USING btree (user_id);


--
-- Name: django_comments_content_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_comments_content_type_id ON django_comments USING btree (content_type_id);


--
-- Name: django_comments_site_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_comments_site_id ON django_comments USING btree (site_id);


--
-- Name: django_comments_submit_date_12b4e916a37b5c82_uniq; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_comments_submit_date_12b4e916a37b5c82_uniq ON django_comments USING btree (submit_date);


--
-- Name: django_comments_user_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_comments_user_id ON django_comments USING btree (user_id);


--
-- Name: django_redirect_old_path; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_redirect_old_path ON django_redirect USING btree (old_path);


--
-- Name: django_redirect_old_path_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_redirect_old_path_like ON django_redirect USING btree (old_path varchar_pattern_ops);


--
-- Name: django_redirect_site_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_redirect_site_id ON django_redirect USING btree (site_id);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX django_session_session_key_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: forms_field_form_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX forms_field_form_id ON forms_field USING btree (form_id);


--
-- Name: forms_fieldentry_entry_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX forms_fieldentry_entry_id ON forms_fieldentry USING btree (entry_id);


--
-- Name: forms_formentry_form_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX forms_formentry_form_id ON forms_formentry USING btree (form_id);


--
-- Name: galleries_galleryimage_gallery_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX galleries_galleryimage_gallery_id ON galleries_galleryimage USING btree (gallery_id);


--
-- Name: generic_assignedkeyword_content_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX generic_assignedkeyword_content_type_id ON generic_assignedkeyword USING btree (content_type_id);


--
-- Name: generic_assignedkeyword_keyword_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX generic_assignedkeyword_keyword_id ON generic_assignedkeyword USING btree (keyword_id);


--
-- Name: generic_keyword_site_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX generic_keyword_site_id ON generic_keyword USING btree (site_id);


--
-- Name: generic_rating_content_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX generic_rating_content_type_id ON generic_rating USING btree (content_type_id);


--
-- Name: generic_rating_user_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX generic_rating_user_id ON generic_rating USING btree (user_id);


--
-- Name: generic_threadedcomment_replied_to_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX generic_threadedcomment_replied_to_id ON generic_threadedcomment USING btree (replied_to_id);


--
-- Name: pages_page_parent_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX pages_page_parent_id ON pages_page USING btree (parent_id);


--
-- Name: pages_page_publish_date_4b581dded15f4cdf_uniq; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX pages_page_publish_date_4b581dded15f4cdf_uniq ON pages_page USING btree (publish_date);


--
-- Name: pages_page_site_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX pages_page_site_id ON pages_page USING btree (site_id);


--
-- Name: reversion_revision_date_created; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX reversion_revision_date_created ON reversion_revision USING btree (date_created);


--
-- Name: reversion_revision_manager_slug; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX reversion_revision_manager_slug ON reversion_revision USING btree (manager_slug);


--
-- Name: reversion_revision_manager_slug_like; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX reversion_revision_manager_slug_like ON reversion_revision USING btree (manager_slug varchar_pattern_ops);


--
-- Name: reversion_revision_user_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX reversion_revision_user_id ON reversion_revision USING btree (user_id);


--
-- Name: reversion_version_content_type_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX reversion_version_content_type_id ON reversion_version USING btree (content_type_id);


--
-- Name: reversion_version_object_id_int; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX reversion_version_object_id_int ON reversion_version USING btree (object_id_int);


--
-- Name: reversion_version_revision_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX reversion_version_revision_id ON reversion_version USING btree (revision_id);


--
-- Name: twitter_tweet_query_id; Type: INDEX; Schema: public; Owner: app_digipal
--

CREATE INDEX twitter_tweet_query_id ON twitter_tweet USING btree (query_id);


--
-- Name: D8272c0c845536cc87a3d483d63b21f6; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allographcomponent_features
    ADD CONSTRAINT "D8272c0c845536cc87a3d483d63b21f6" FOREIGN KEY (allographcomponent_id) REFERENCES digipal_allographcomponent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: after_id_refs_id_a195d453; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_annotation
    ADD CONSTRAINT after_id_refs_id_a195d453 FOREIGN KEY (after_id) REFERENCES digipal_allograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allograph_id_refs_id_e75127c7; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allographcomponent
    ADD CONSTRAINT allograph_id_refs_id_e75127c7 FOREIGN KEY (allograph_id) REFERENCES digipal_allograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allograph_id_refs_id_e85ec36c; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_script_allographs
    ADD CONSTRAINT allograph_id_refs_id_e85ec36c FOREIGN KEY (allograph_id) REFERENCES digipal_allograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: allograph_id_refs_id_f02d3abf; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiograph
    ADD CONSTRAINT allograph_id_refs_id_f02d3abf FOREIGN KEY (allograph_id) REFERENCES digipal_allograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: annotation_id_refs_id_3e2f18b6; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textannotation
    ADD CONSTRAINT annotation_id_refs_id_3e2f18b6 FOREIGN KEY (annotation_id) REFERENCES digipal_annotation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: annotation_status_id_refs_id_4aa83520; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_image
    ADD CONSTRAINT annotation_status_id_refs_id_4aa83520 FOREIGN KEY (annotation_status_id) REFERENCES digipal_imageannotationstatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: appearance_id_refs_id_d4a1da4e; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT appearance_id_refs_id_d4a1da4e FOREIGN KEY (appearance_id) REFERENCES digipal_appearance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: aspect_id_refs_id_418bf40d; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_aspect_features
    ADD CONSTRAINT aspect_id_refs_id_418bf40d FOREIGN KEY (aspect_id) REFERENCES digipal_aspect(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: assigned_date_id_refs_id_12312e8f; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT assigned_date_id_refs_id_12312e8f FOREIGN KEY (assigned_date_id) REFERENCES digipal_date(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: assigned_place_id_refs_id_5d22b62d; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT assigned_place_id_refs_id_5d22b62d FOREIGN KEY (assigned_place_id) REFERENCES digipal_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: author_id_refs_id_91c5a886; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_annotation
    ADD CONSTRAINT author_id_refs_id_91c5a886 FOREIGN KEY (author_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: before_id_refs_id_a195d453; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_annotation
    ADD CONSTRAINT before_id_refs_id_a195d453 FOREIGN KEY (before_id) REFERENCES digipal_allograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blogcategory_id_refs_id_91693b1c; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_categories
    ADD CONSTRAINT blogcategory_id_refs_id_91693b1c FOREIGN KEY (blogcategory_id) REFERENCES blog_blogcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blogpost_id_refs_id_6a2ad936; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_categories
    ADD CONSTRAINT blogpost_id_refs_id_6a2ad936 FOREIGN KEY (blogpost_id) REFERENCES blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: category_id_refs_id_47dac8d7; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartauthenticity
    ADD CONSTRAINT category_id_refs_id_47dac8d7 FOREIGN KEY (category_id) REFERENCES digipal_authenticitycategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: character_id_refs_id_d12e219a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allograph
    ADD CONSTRAINT character_id_refs_id_d12e219a FOREIGN KEY (character_id) REFERENCES digipal_character(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: comment_ptr_id_refs_id_d4c241e5; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_threadedcomment
    ADD CONSTRAINT comment_ptr_id_refs_id_d4c241e5 FOREIGN KEY (comment_ptr_id) REFERENCES django_comments(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: component_id_refs_id_10d1fa92; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allographcomponent
    ADD CONSTRAINT component_id_refs_id_10d1fa92 FOREIGN KEY (component_id) REFERENCES digipal_component(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: component_id_refs_id_14a98178; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_component_features
    ADD CONSTRAINT component_id_refs_id_14a98178 FOREIGN KEY (component_id) REFERENCES digipal_component(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: component_id_refs_id_15daa9d1; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiographcomponent
    ADD CONSTRAINT component_id_refs_id_15daa9d1 FOREIGN KEY (component_id) REFERENCES digipal_component(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: component_id_refs_id_76111977; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graphcomponent
    ADD CONSTRAINT component_id_refs_id_76111977 FOREIGN KEY (component_id) REFERENCES digipal_component(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: component_id_refs_id_bf195524; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scriptcomponent
    ADD CONSTRAINT component_id_refs_id_bf195524 FOREIGN KEY (component_id) REFERENCES digipal_component(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_0a48a334; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_archive
    ADD CONSTRAINT content_type_id_refs_id_0a48a334 FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_1c638e93; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_rating
    ADD CONSTRAINT content_type_id_refs_id_1c638e93 FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_c36d959c; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_assignedkeyword
    ADD CONSTRAINT content_type_id_refs_id_c36d959c FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_d043b34a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_d043b34a FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_f5dce86c; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY reversion_version
    ADD CONSTRAINT content_type_id_refs_id_f5dce86c FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sitepermission_user_id_d964e296aed9970_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY core_sitepermission
    ADD CONSTRAINT core_sitepermission_user_id_d964e296aed9970_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: current_county_id_refs_id_e974f51a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_place
    ADD CONSTRAINT current_county_id_refs_id_e974f51a FOREIGN KEY (current_county_id) REFERENCES digipal_county(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: current_item_id_refs_id_0c135812; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart
    ADD CONSTRAINT current_item_id_refs_id_0c135812 FOREIGN KEY (current_item_id) REFERENCES digipal_currentitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: date_id_refs_id_2452bccb; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitemdate
    ADD CONSTRAINT date_id_refs_id_2452bccb FOREIGN KEY (date_id) REFERENCES digipal_date(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: date_id_refs_id_6278e8c5; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_dateevidence
    ADD CONSTRAINT date_id_refs_id_6278e8c5 FOREIGN KEY (date_id) REFERENCES digipal_date(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digip_currentitem_id_3666c8ecafb6bb97_fk_digipal_currentitem_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_currentitem_owners
    ADD CONSTRAINT digip_currentitem_id_3666c8ecafb6bb97_fk_digipal_currentitem_id FOREIGN KEY (currentitem_id) REFERENCES digipal_currentitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_a_allograph_id_542fa868475bf703_fk_digipal_allograph_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allograph_aspects
    ADD CONSTRAINT digipal_a_allograph_id_542fa868475bf703_fk_digipal_allograph_id FOREIGN KEY (allograph_id) REFERENCES digipal_allograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_a_ontograph_id_1d0cd4ace8644f2e_fk_digipal_ontograph_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_ontographs
    ADD CONSTRAINT digipal_a_ontograph_id_1d0cd4ace8644f2e_fk_digipal_ontograph_id FOREIGN KEY (ontograph_id) REFERENCES digipal_ontograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_allog_feature_id_230c2364d0c73288_fk_digipal_feature_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allographcomponent_features
    ADD CONSTRAINT digipal_allog_feature_id_230c2364d0c73288_fk_digipal_feature_id FOREIGN KEY (feature_id) REFERENCES digipal_feature(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_allogra_aspect_id_5f1bd1c41c2c6dca_fk_digipal_aspect_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_allograph_aspects
    ADD CONSTRAINT digipal_allogra_aspect_id_5f1bd1c41c2c6dca_fk_digipal_aspect_id FOREIGN KEY (aspect_id) REFERENCES digipal_aspect(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_alp_alphabet_id_5556a119f9c15c6e_fk_digipal_alphabet_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_ontographs
    ADD CONSTRAINT digipal_alp_alphabet_id_5556a119f9c15c6e_fk_digipal_alphabet_id FOREIGN KEY (alphabet_id) REFERENCES digipal_alphabet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_alp_alphabet_id_588d04dc3a11a174_fk_digipal_alphabet_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_hands
    ADD CONSTRAINT digipal_alp_alphabet_id_588d04dc3a11a174_fk_digipal_alphabet_id FOREIGN KEY (alphabet_id) REFERENCES digipal_alphabet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_alphabet_ha_hand_id_3f5df15f509bddda_fk_digipal_hand_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_alphabet_hands
    ADD CONSTRAINT digipal_alphabet_ha_hand_id_3f5df15f509bddda_fk_digipal_hand_id FOREIGN KEY (hand_id) REFERENCES digipal_hand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_c_character_id_421a3a206316eea3_fk_digipal_character_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character_components
    ADD CONSTRAINT digipal_c_character_id_421a3a206316eea3_fk_digipal_character_id FOREIGN KEY (character_id) REFERENCES digipal_character(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_c_component_id_5c2b93e63528063d_fk_digipal_component_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character_components
    ADD CONSTRAINT digipal_c_component_id_5c2b93e63528063d_fk_digipal_component_id FOREIGN KEY (component_id) REFERENCES digipal_component(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_currentit_owner_id_18d9e4f9dfde684e_fk_digipal_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_currentitem_owners
    ADD CONSTRAINT digipal_currentit_owner_id_18d9e4f9dfde684e_fk_digipal_owner_id FOREIGN KEY (owner_id) REFERENCES digipal_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_graph_as_aspect_id_d565c199db5dbfa_fk_digipal_aspect_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph_aspects
    ADD CONSTRAINT digipal_graph_as_aspect_id_d565c199db5dbfa_fk_digipal_aspect_id FOREIGN KEY (aspect_id) REFERENCES digipal_aspect(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_graph_asp_graph_id_3cd5a48f03f7908b_fk_digipal_graph_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph_aspects
    ADD CONSTRAINT digipal_graph_asp_graph_id_3cd5a48f03f7908b_fk_digipal_graph_id FOREIGN KEY (graph_id) REFERENCES digipal_graph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_hand_imag_image_id_6c1445fe889c9bf6_fk_digipal_image_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand_images
    ADD CONSTRAINT digipal_hand_imag_image_id_6c1445fe889c9bf6_fk_digipal_image_id FOREIGN KEY (image_id) REFERENCES digipal_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_hand_images_hand_id_671b7cfd266947f5_fk_digipal_hand_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand_images
    ADD CONSTRAINT digipal_hand_images_hand_id_671b7cfd266947f5_fk_digipal_hand_id FOREIGN KEY (hand_id) REFERENCES digipal_hand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_hist_category_id_4194d8a4ba44eaa_fk_digipal_category_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_categories
    ADD CONSTRAINT digipal_hist_category_id_4194d8a4ba44eaa_fk_digipal_category_id FOREIGN KEY (category_id) REFERENCES digipal_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_historica_owner_id_23ce7f02f1badad6_fk_digipal_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_owners
    ADD CONSTRAINT digipal_historica_owner_id_23ce7f02f1badad6_fk_digipal_owner_id FOREIGN KEY (owner_id) REFERENCES digipal_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_i_idiograph_id_2c3215c58c22fe03_fk_digipal_idiograph_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiograph_aspects
    ADD CONSTRAINT digipal_i_idiograph_id_2c3215c58c22fe03_fk_digipal_idiograph_id FOREIGN KEY (idiograph_id) REFERENCES digipal_idiograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_idiogra_aspect_id_45390694190c31a7_fk_digipal_aspect_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiograph_aspects
    ADD CONSTRAINT digipal_idiogra_aspect_id_45390694190c31a7_fk_digipal_aspect_id FOREIGN KEY (aspect_id) REFERENCES digipal_aspect(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_ite_itempart_id_33e6e8354509f8dd_fk_digipal_itempart_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart_owners
    ADD CONSTRAINT digipal_ite_itempart_id_33e6e8354509f8dd_fk_digipal_itempart_id FOREIGN KEY (itempart_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_itempart_ow_owner_id_74969a49036dab_fk_digipal_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart_owners
    ADD CONSTRAINT digipal_itempart_ow_owner_id_74969a49036dab_fk_digipal_owner_id FOREIGN KEY (owner_id) REFERENCES digipal_owner(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_s_reference_id_514ba25d1687703d_fk_digipal_reference_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scribe_reference
    ADD CONSTRAINT digipal_s_reference_id_514ba25d1687703d_fk_digipal_reference_id FOREIGN KEY (reference_id) REFERENCES digipal_reference(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_scribe__scribe_id_57dd0c849aa6521f_fk_digipal_scribe_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scribe_reference
    ADD CONSTRAINT digipal_scribe__scribe_id_57dd0c849aa6521f_fk_digipal_scribe_id FOREIGN KEY (scribe_id) REFERENCES digipal_scribe(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_tex_category_id_52b32d954c6b0918_fk_digipal_category_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_categories
    ADD CONSTRAINT digipal_tex_category_id_52b32d954c6b0918_fk_digipal_category_id FOREIGN KEY (category_id) REFERENCES digipal_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_tex_language_id_70323cef070fdcb3_fk_digipal_language_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent_languages
    ADD CONSTRAINT digipal_tex_language_id_70323cef070fdcb3_fk_digipal_language_id FOREIGN KEY (language_id) REFERENCES digipal_language(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_tex_language_id_73d4dcda2df2edc0_fk_digipal_language_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_languages
    ADD CONSTRAINT digipal_tex_language_id_73d4dcda2df2edc0_fk_digipal_language_id FOREIGN KEY (language_id) REFERENCES digipal_language(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_text_catego_text_id_39cdb86ac033ae6d_fk_digipal_text_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_categories
    ADD CONSTRAINT digipal_text_catego_text_id_39cdb86ac033ae6d_fk_digipal_text_id FOREIGN KEY (text_id) REFERENCES digipal_text(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: digipal_text_langua_text_id_53f058584d7ac0ef_fk_digipal_text_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_languages
    ADD CONSTRAINT digipal_text_langua_text_id_53f058584d7ac0ef_fk_digipal_text_id FOREIGN KEY (text_id) REFERENCES digipal_text(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES django_comments(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comments_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comments_site_id_fkey FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: entry_id_refs_id_e329b086; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_fieldentry
    ADD CONSTRAINT entry_id_refs_id_e329b086 FOREIGN KEY (entry_id) REFERENCES forms_formentry(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feature_id_refs_id_3457eb6a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_component_features
    ADD CONSTRAINT feature_id_refs_id_3457eb6a FOREIGN KEY (feature_id) REFERENCES digipal_feature(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feature_id_refs_id_7248d1b3; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graphcomponent_features
    ADD CONSTRAINT feature_id_refs_id_7248d1b3 FOREIGN KEY (feature_id) REFERENCES digipal_feature(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feature_id_refs_id_755946d3; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_aspect_features
    ADD CONSTRAINT feature_id_refs_id_755946d3 FOREIGN KEY (feature_id) REFERENCES digipal_feature(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feature_id_refs_id_87eb1d7a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scriptcomponent_features
    ADD CONSTRAINT feature_id_refs_id_87eb1d7a FOREIGN KEY (feature_id) REFERENCES digipal_feature(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feature_id_refs_id_e6a54604; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiographcomponent_features
    ADD CONSTRAINT feature_id_refs_id_e6a54604 FOREIGN KEY (feature_id) REFERENCES digipal_feature(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: form_id_refs_id_18bef2f6; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character
    ADD CONSTRAINT form_id_refs_id_18bef2f6 FOREIGN KEY (form_id) REFERENCES digipal_characterform(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: form_id_refs_page_ptr_id_4d605921; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_formentry
    ADD CONSTRAINT form_id_refs_page_ptr_id_4d605921 FOREIGN KEY (form_id) REFERENCES forms_form(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: form_id_refs_page_ptr_id_5a752766; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_field
    ADD CONSTRAINT form_id_refs_page_ptr_id_5a752766 FOREIGN KEY (form_id) REFERENCES forms_form(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: founder_id_refs_id_8c37de08; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_institution
    ADD CONSTRAINT founder_id_refs_id_8c37de08 FOREIGN KEY (founder_id) REFERENCES digipal_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: from_blogpost_id_refs_id_6404941b; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_related_posts
    ADD CONSTRAINT from_blogpost_id_refs_id_6404941b FOREIGN KEY (from_blogpost_id) REFERENCES blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gallery_id_refs_page_ptr_id_d6457fc6; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY galleries_galleryimage
    ADD CONSTRAINT gallery_id_refs_page_ptr_id_d6457fc6 FOREIGN KEY (gallery_id) REFERENCES galleries_gallery(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: glossed_text_id_refs_id_5154f4bc; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT glossed_text_id_refs_id_5154f4bc FOREIGN KEY (glossed_text_id) REFERENCES digipal_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: graph_id_refs_id_2580039d; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graphcomponent
    ADD CONSTRAINT graph_id_refs_id_2580039d FOREIGN KEY (graph_id) REFERENCES digipal_graph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: graph_id_refs_id_97441f79; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_annotation
    ADD CONSTRAINT graph_id_refs_id_97441f79 FOREIGN KEY (graph_id) REFERENCES digipal_graph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: graphcomponent_id_refs_id_515ec053; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graphcomponent_features
    ADD CONSTRAINT graphcomponent_id_refs_id_515ec053 FOREIGN KEY (graphcomponent_id) REFERENCES digipal_graphcomponent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_254c519a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart
    ADD CONSTRAINT group_id_refs_id_254c519a FOREIGN KEY (group_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_44358118; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph
    ADD CONSTRAINT group_id_refs_id_44358118 FOREIGN KEY (group_id) REFERENCES digipal_graph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_f4b32aac; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_f4b32aac FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hair_arrangement_id_refs_id_3df6772a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_layout
    ADD CONSTRAINT hair_arrangement_id_refs_id_3df6772a FOREIGN KEY (hair_arrangement_id) REFERENCES digipal_hair(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hair_id_refs_id_59f229d8; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem
    ADD CONSTRAINT hair_id_refs_id_59f229d8 FOREIGN KEY (hair_id) REFERENCES digipal_hair(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hand_id_refs_id_0b1eb4ea; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_proportion
    ADD CONSTRAINT hand_id_refs_id_0b1eb4ea FOREIGN KEY (hand_id) REFERENCES digipal_hand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hand_id_refs_id_1ec58cd8; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_handdescription
    ADD CONSTRAINT hand_id_refs_id_1ec58cd8 FOREIGN KEY (hand_id) REFERENCES digipal_hand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hand_id_refs_id_2b787667; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_placeevidence
    ADD CONSTRAINT hand_id_refs_id_2b787667 FOREIGN KEY (hand_id) REFERENCES digipal_hand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hand_id_refs_id_74ab93ac; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_dateevidence
    ADD CONSTRAINT hand_id_refs_id_74ab93ac FOREIGN KEY (hand_id) REFERENCES digipal_hand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: hand_id_refs_id_c5becd57; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph
    ADD CONSTRAINT hand_id_refs_id_c5becd57 FOREIGN KEY (hand_id) REFERENCES digipal_hand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_county_id_refs_id_e974f51a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_place
    ADD CONSTRAINT historical_county_id_refs_id_e974f51a FOREIGN KEY (historical_county_id) REFERENCES digipal_county(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_format_id_refs_id_c59b43f2; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem
    ADD CONSTRAINT historical_item_format_id_refs_id_c59b43f2 FOREIGN KEY (historical_item_format_id) REFERENCES digipal_format(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_09daf554; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_cataloguenumber
    ADD CONSTRAINT historical_item_id_refs_id_09daf554 FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_1fd35616; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_layout
    ADD CONSTRAINT historical_item_id_refs_id_1fd35616 FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_2caf0d88; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartitem
    ADD CONSTRAINT historical_item_id_refs_id_2caf0d88 FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_35828167; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_decoration
    ADD CONSTRAINT historical_item_id_refs_id_35828167 FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_702ef28e; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_collation
    ADD CONSTRAINT historical_item_id_refs_id_702ef28e FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_78501f52; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_placeevidence
    ADD CONSTRAINT historical_item_id_refs_id_78501f52 FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_853c259e; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitemdate
    ADD CONSTRAINT historical_item_id_refs_id_853c259e FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_985172ba; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_description
    ADD CONSTRAINT historical_item_id_refs_id_985172ba FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_ea707902; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itemorigin
    ADD CONSTRAINT historical_item_id_refs_id_ea707902 FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_ec058d19; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_dateevidence
    ADD CONSTRAINT historical_item_id_refs_id_ec058d19 FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_id_refs_id_f9e6be89; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_archive
    ADD CONSTRAINT historical_item_id_refs_id_f9e6be89 FOREIGN KEY (historical_item_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historical_item_type_id_refs_id_c252ca51; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem
    ADD CONSTRAINT historical_item_type_id_refs_id_c252ca51 FOREIGN KEY (historical_item_type_id) REFERENCES digipal_historicalitemtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historicalitem_id_2b89ff0d2714727_fk_digipal_historicalitem_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_categories
    ADD CONSTRAINT historicalitem_id_2b89ff0d2714727_fk_digipal_historicalitem_id FOREIGN KEY (historicalitem_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: historicalitem_id_727ffcaab0ea8a5_fk_digipal_historicalitem_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem_owners
    ADD CONSTRAINT historicalitem_id_727ffcaab0ea8a5_fk_digipal_historicalitem_id FOREIGN KEY (historicalitem_id) REFERENCES digipal_historicalitem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: idiograph_id_refs_id_63eed7df; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_graph
    ADD CONSTRAINT idiograph_id_refs_id_63eed7df FOREIGN KEY (idiograph_id) REFERENCES digipal_idiograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: idiograph_id_refs_id_d6a7b061; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiographcomponent
    ADD CONSTRAINT idiograph_id_refs_id_d6a7b061 FOREIGN KEY (idiograph_id) REFERENCES digipal_idiograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: idiographcomponent_id_refs_id_80c117cd; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiographcomponent_features
    ADD CONSTRAINT idiographcomponent_id_refs_id_80c117cd FOREIGN KEY (idiographcomponent_id) REFERENCES digipal_idiographcomponent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: institution_id_refs_id_11d30948; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itemorigin
    ADD CONSTRAINT institution_id_refs_id_11d30948 FOREIGN KEY (institution_id) REFERENCES digipal_institution(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: institution_id_refs_id_aa4fbf78; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_owner
    ADD CONSTRAINT institution_id_refs_id_aa4fbf78 FOREIGN KEY (institution_id) REFERENCES digipal_institution(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: institution_type_id_refs_id_e427ce6d; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_institution
    ADD CONSTRAINT institution_type_id_refs_id_e427ce6d FOREIGN KEY (institution_type_id) REFERENCES digipal_institutiontype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: item_part_id_refs_id_069b1ab1; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_entryhand
    ADD CONSTRAINT item_part_id_refs_id_069b1ab1 FOREIGN KEY (item_part_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: item_part_id_refs_id_46f1b452; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT item_part_id_refs_id_46f1b452 FOREIGN KEY (item_part_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: item_part_id_refs_id_9a800fdb; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_textitempart
    ADD CONSTRAINT item_part_id_refs_id_9a800fdb FOREIGN KEY (item_part_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: item_part_id_refs_id_a78e0a58; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartauthenticity
    ADD CONSTRAINT item_part_id_refs_id_a78e0a58 FOREIGN KEY (item_part_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: item_part_id_refs_id_df31da3a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_layout
    ADD CONSTRAINT item_part_id_refs_id_df31da3a FOREIGN KEY (item_part_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: item_part_id_refs_id_f7500fa8; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent
    ADD CONSTRAINT item_part_id_refs_id_f7500fa8 FOREIGN KEY (item_part_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: item_part_id_refs_id_fbcb2f2a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_image
    ADD CONSTRAINT item_part_id_refs_id_fbcb2f2a FOREIGN KEY (item_part_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: item_part_id_refs_id_fc23f075; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartitem
    ADD CONSTRAINT item_part_id_refs_id_fc23f075 FOREIGN KEY (item_part_id) REFERENCES digipal_itempart(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: keyword_id_refs_id_aa70ce50; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_assignedkeyword
    ADD CONSTRAINT keyword_id_refs_id_aa70ce50 FOREIGN KEY (keyword_id) REFERENCES generic_keyword(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: language_id_refs_id_d9b95295; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_historicalitem
    ADD CONSTRAINT language_id_refs_id_d9b95295 FOREIGN KEY (language_id) REFERENCES digipal_language(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: last_image_id_refs_id_b97ce151; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxml
    ADD CONSTRAINT last_image_id_refs_id_b97ce151 FOREIGN KEY (last_image_id) REFERENCES digipal_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: latin_style_id_refs_id_dc87ffc0; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT latin_style_id_refs_id_dc87ffc0 FOREIGN KEY (latin_style_id) REFERENCES digipal_latinstyle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measurement_id_refs_id_0b86812d; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_proportion
    ADD CONSTRAINT measurement_id_refs_id_0b86812d FOREIGN KEY (measurement_id) REFERENCES digipal_measurement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: media_permission_id_refs_id_63c78590; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_image
    ADD CONSTRAINT media_permission_id_refs_id_63c78590 FOREIGN KEY (media_permission_id) REFERENCES digipal_mediapermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: media_permission_id_refs_id_988b7016; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_repository
    ADD CONSTRAINT media_permission_id_refs_id_988b7016 FOREIGN KEY (media_permission_id) REFERENCES digipal_mediapermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ontograph_id_refs_id_9ff9b479; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_character
    ADD CONSTRAINT ontograph_id_refs_id_9ff9b479 FOREIGN KEY (ontograph_id) REFERENCES digipal_ontograph(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ontograph_type_id_refs_id_f6076036; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_ontograph
    ADD CONSTRAINT ontograph_type_id_refs_id_f6076036 FOREIGN KEY (ontograph_type_id) REFERENCES digipal_ontographtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_id_refs_id_c3112308; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_annotation
    ADD CONSTRAINT page_id_refs_id_c3112308 FOREIGN KEY (image_id) REFERENCES digipal_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_ptr_id_refs_id_2adddb0b; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY pages_link
    ADD CONSTRAINT page_ptr_id_refs_id_2adddb0b FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_ptr_id_refs_id_558d29bc; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY pages_richtextpage
    ADD CONSTRAINT page_ptr_id_refs_id_558d29bc FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_ptr_id_refs_id_75804475; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY galleries_gallery
    ADD CONSTRAINT page_ptr_id_refs_id_75804475 FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: page_ptr_id_refs_id_fe19b67b; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY forms_form
    ADD CONSTRAINT page_ptr_id_refs_id_fe19b67b FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parent_id_refs_id_68963b8e; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY pages_page
    ADD CONSTRAINT parent_id_refs_id_68963b8e FOREIGN KEY (parent_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: part_of_id_refs_id_b3e8a0fd; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_repository
    ADD CONSTRAINT part_of_id_refs_id_b3e8a0fd FOREIGN KEY (part_of_id) REFERENCES digipal_repository(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: patron_id_refs_id_8c37de08; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_institution
    ADD CONSTRAINT patron_id_refs_id_8c37de08 FOREIGN KEY (patron_id) REFERENCES digipal_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: person_id_refs_id_6645bde2; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_owner
    ADD CONSTRAINT person_id_refs_id_6645bde2 FOREIGN KEY (person_id) REFERENCES digipal_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_75faa36d; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_institution
    ADD CONSTRAINT place_id_refs_id_75faa36d FOREIGN KEY (place_id) REFERENCES digipal_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_9fc785e4; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_placeevidence
    ADD CONSTRAINT place_id_refs_id_9fc785e4 FOREIGN KEY (place_id) REFERENCES digipal_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_b2af8090; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itemorigin
    ADD CONSTRAINT place_id_refs_id_b2af8090 FOREIGN KEY (place_id) REFERENCES digipal_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_c93d046c; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_repository
    ADD CONSTRAINT place_id_refs_id_c93d046c FOREIGN KEY (place_id) REFERENCES digipal_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: query_id_refs_id_b81595a6; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY twitter_tweet
    ADD CONSTRAINT query_id_refs_id_b81595a6 FOREIGN KEY (query_id) REFERENCES twitter_query(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reference_id_refs_id_60bd43d2; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_placeevidence
    ADD CONSTRAINT reference_id_refs_id_60bd43d2 FOREIGN KEY (reference_id) REFERENCES digipal_reference(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reference_id_refs_id_92934927; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_dateevidence
    ADD CONSTRAINT reference_id_refs_id_92934927 FOREIGN KEY (reference_id) REFERENCES digipal_reference(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reformer_id_refs_id_8c37de08; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_institution
    ADD CONSTRAINT reformer_id_refs_id_8c37de08 FOREIGN KEY (reformer_id) REFERENCES digipal_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: region_id_refs_id_236ab299; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_place
    ADD CONSTRAINT region_id_refs_id_236ab299 FOREIGN KEY (region_id) REFERENCES digipal_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: replied_to_id_refs_comment_ptr_id_83bd8e31; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_threadedcomment
    ADD CONSTRAINT replied_to_id_refs_comment_ptr_id_83bd8e31 FOREIGN KEY (replied_to_id) REFERENCES generic_threadedcomment(comment_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: repository_id_refs_id_2413f631; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_currentitem
    ADD CONSTRAINT repository_id_refs_id_2413f631 FOREIGN KEY (repository_id) REFERENCES digipal_repository(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: repository_id_refs_id_f008e82f; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_owner
    ADD CONSTRAINT repository_id_refs_id_f008e82f FOREIGN KEY (repository_id) REFERENCES digipal_repository(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: revision_id_refs_id_a685e913; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY reversion_version
    ADD CONSTRAINT revision_id_refs_id_a685e913 FOREIGN KEY (revision_id) REFERENCES reversion_revision(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scribe_id_refs_id_79d30693; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT scribe_id_refs_id_79d30693 FOREIGN KEY (scribe_id) REFERENCES digipal_scribe(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scribe_id_refs_id_f6c56783; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_idiograph
    ADD CONSTRAINT scribe_id_refs_id_f6c56783 FOREIGN KEY (scribe_id) REFERENCES digipal_scribe(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: script_id_refs_id_08f60255; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_script_allographs
    ADD CONSTRAINT script_id_refs_id_08f60255 FOREIGN KEY (script_id) REFERENCES digipal_script(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: script_id_refs_id_47908c8f; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT script_id_refs_id_47908c8f FOREIGN KEY (script_id) REFERENCES digipal_script(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: script_id_refs_id_c361aad4; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scriptcomponent
    ADD CONSTRAINT script_id_refs_id_c361aad4 FOREIGN KEY (script_id) REFERENCES digipal_script(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scriptcomponent_id_refs_id_559cb110; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scriptcomponent_features
    ADD CONSTRAINT scriptcomponent_id_refs_id_559cb110 FOREIGN KEY (scriptcomponent_id) REFERENCES digipal_scriptcomponent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scriptorium_id_refs_id_33a3d7e6; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_scribe
    ADD CONSTRAINT scriptorium_id_refs_id_33a3d7e6 FOREIGN KEY (scriptorium_id) REFERENCES digipal_institution(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_29e7e142; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY conf_setting
    ADD CONSTRAINT site_id_refs_id_29e7e142 FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_390e2add; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY django_redirect
    ADD CONSTRAINT site_id_refs_id_390e2add FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_70c9ac77; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY pages_page
    ADD CONSTRAINT site_id_refs_id_70c9ac77 FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_91a6d9d4; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY core_sitepermission_sites
    ADD CONSTRAINT site_id_refs_id_91a6d9d4 FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_93afc60f; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogcategory
    ADD CONSTRAINT site_id_refs_id_93afc60f FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_ac21095f; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost
    ADD CONSTRAINT site_id_refs_id_ac21095f FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: site_id_refs_id_f6393455; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_keyword
    ADD CONSTRAINT site_id_refs_id_f6393455 FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sitepermission_id_refs_id_7dccdcbd; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY core_sitepermission_sites
    ADD CONSTRAINT sitepermission_id_refs_id_7dccdcbd FOREIGN KEY (sitepermission_id) REFERENCES core_sitepermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: source_id_refs_id_0116674a; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempartauthenticity
    ADD CONSTRAINT source_id_refs_id_0116674a FOREIGN KEY (source_id) REFERENCES digipal_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: source_id_refs_id_055bdab2; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_handdescription
    ADD CONSTRAINT source_id_refs_id_055bdab2 FOREIGN KEY (source_id) REFERENCES digipal_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: source_id_refs_id_5f9dc652; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_description
    ADD CONSTRAINT source_id_refs_id_5f9dc652 FOREIGN KEY (source_id) REFERENCES digipal_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: source_id_refs_id_9b9df92b; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxmlcopy
    ADD CONSTRAINT source_id_refs_id_9b9df92b FOREIGN KEY (source_id) REFERENCES digipal_text_textcontentxml(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: source_id_refs_id_a81c37fa; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_cataloguenumber
    ADD CONSTRAINT source_id_refs_id_a81c37fa FOREIGN KEY (source_id) REFERENCES digipal_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: status_id_refs_id_4ab46c62; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_annotation
    ADD CONSTRAINT status_id_refs_id_4ab46c62 FOREIGN KEY (status_id) REFERENCES digipal_status(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: status_id_refs_id_bf6b5564; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxml
    ADD CONSTRAINT status_id_refs_id_bf6b5564 FOREIGN KEY (status_id) REFERENCES digipal_text_textcontentxmlstatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: stewart_record_id_refs_id_4645050e; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_hand
    ADD CONSTRAINT stewart_record_id_refs_id_4645050e FOREIGN KEY (stewart_record_id) REFERENCES digipal_stewartrecord(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: text_content_id_refs_id_0a2712f3; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontentxml
    ADD CONSTRAINT text_content_id_refs_id_0a2712f3 FOREIGN KEY (text_content_id) REFERENCES digipal_text_textcontent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: text_id_refs_id_14d015c5; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_textitempart
    ADD CONSTRAINT text_id_refs_id_14d015c5 FOREIGN KEY (text_id) REFERENCES digipal_text(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: text_id_refs_id_1647dd70; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_description
    ADD CONSTRAINT text_id_refs_id_1647dd70 FOREIGN KEY (text_id) REFERENCES digipal_text(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: text_id_refs_id_c26c0737; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_cataloguenumber
    ADD CONSTRAINT text_id_refs_id_c26c0737 FOREIGN KEY (text_id) REFERENCES digipal_text(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: text_id_refs_id_fbcfc7e4; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent
    ADD CONSTRAINT text_id_refs_id_fbcfc7e4 FOREIGN KEY (text_id) REFERENCES digipal_text(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: textcontent_id_1918d79e96327ff8_fk_digipal_text_textcontent_id; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent_languages
    ADD CONSTRAINT textcontent_id_1918d79e96327ff8_fk_digipal_text_textcontent_id FOREIGN KEY (textcontent_id) REFERENCES digipal_text_textcontent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: to_blogpost_id_refs_id_6404941b; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost_related_posts
    ADD CONSTRAINT to_blogpost_id_refs_id_6404941b FOREIGN KEY (to_blogpost_id) REFERENCES blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: type_id_refs_id_301eaa90; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_itempart
    ADD CONSTRAINT type_id_refs_id_301eaa90 FOREIGN KEY (type_id) REFERENCES digipal_itemparttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: type_id_refs_id_a5bf2f2b; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_text_textcontent
    ADD CONSTRAINT type_id_refs_id_a5bf2f2b FOREIGN KEY (type_id) REFERENCES digipal_text_textcontenttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: type_id_refs_id_d2523b9f; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_place
    ADD CONSTRAINT type_id_refs_id_d2523b9f FOREIGN KEY (type_id) REFERENCES digipal_placetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: type_id_refs_id_ff4831cd; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY digipal_repository
    ADD CONSTRAINT type_id_refs_id_ff4831cd FOREIGN KEY (type_id) REFERENCES digipal_ownertype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_01a962b8; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY blog_blogpost
    ADD CONSTRAINT user_id_refs_id_01a962b8 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_40c41112; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_40c41112 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_4dc23c39; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_4dc23c39 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_9436ba96; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY generic_rating
    ADD CONSTRAINT user_id_refs_id_9436ba96 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_d4f35b51; Type: FK CONSTRAINT; Schema: public; Owner: app_digipal
--

ALTER TABLE ONLY reversion_revision
    ADD CONSTRAINT user_id_refs_id_d4f35b51 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

